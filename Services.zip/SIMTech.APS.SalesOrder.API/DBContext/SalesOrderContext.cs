﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace SIMTech.APS.SalesOrder.API.DBContext
{

    using SIMTech.APS.SalesOrder.API.Models;
    public partial class SalesOrderContext : DbContext
    {
        public SalesOrderContext()
        {
        }

        public SalesOrderContext(DbContextOptions<SalesOrderContext> options)
            : base(options)
        {
        }

        public virtual DbSet<SalesOrder> SalesOrders { get; set; }
        public virtual DbSet<SalesOrderAdjustment> SalesOrderAdjustments { get; set; }
        public virtual DbSet<SalesOrderDetail> SalesOrderDetails { get; set; }

       
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<SalesOrder>(entity =>
            {
                entity.ToTable("SalesOrder");

                entity.HasIndex(e => e.SalesOrderNumber, "IX_SalesOrderHeader_SalesOrderNumber")
                    .IsUnique();

                entity.HasIndex(e => e.SalesOrderNumber, "IX_WorkOrderHeader_WorkOrderNumber")
                    .IsUnique();

                entity.Property(e => e.BalanceAmount).HasColumnType("money");

                entity.Property(e => e.ContactNo).HasMaxLength(50);

                entity.Property(e => e.ContactPersonName).HasMaxLength(50);

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.CustomerId).HasColumnName("CustomerID");

                entity.Property(e => e.DueDate).HasColumnType("datetime");

                entity.Property(e => e.LocationId).HasColumnName("LocationID");

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn)
                    .HasColumnType("datetime");

                entity.Property(e => e.OrderDate).HasColumnType("datetime");

                entity.Property(e => e.PurchaseOrderNumber).HasMaxLength(50);

                entity.Property(e => e.SalesOrderNumber)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.SalesPersonName).HasMaxLength(50);

                entity.Property(e => e.ShipDate).HasColumnType("datetime");

                entity.Property(e => e.String1).HasMaxLength(50);

                entity.Property(e => e.String2).HasMaxLength(50);

                entity.Property(e => e.String3).HasMaxLength(50);

                entity.Property(e => e.String4).HasMaxLength(50);

                entity.Property(e => e.String5).HasMaxLength(50);

                entity.Property(e => e.TotalAmount).HasColumnType("money");

            });

            modelBuilder.Entity<SalesOrderAdjustment>(entity =>
            {
                entity.ToTable("SalesOrderAdjustment");

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn)
                    .HasColumnType("datetime");

                entity.Property(e => e.Remark).HasMaxLength(250);

                entity.Property(e => e.SalesOrderDetailId).HasColumnName("SalesOrderDetailID");


                entity.HasOne(d => d.SalesOrderDetail)
                    .WithMany(p => p.SalesOrderAdjustments)
                    .HasForeignKey(d => d.SalesOrderDetailId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__SalesOrde__Sales__719CDDE7");
            });

            modelBuilder.Entity<SalesOrderDetail>(entity =>
            {
                entity.ToTable("SalesOrderDetail");

                entity.HasIndex(e => e.ProductId, "IX_SalesOrderDetail_ProductID");

                entity.Property(e => e.Amount).HasColumnType("money");

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Date1).HasColumnType("datetime");

                entity.Property(e => e.Date2).HasColumnType("datetime");

                entity.Property(e => e.Description).HasMaxLength(250);

                entity.Property(e => e.DueDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn)
                    .HasColumnType("datetime");

                entity.Property(e => e.ProductId).HasColumnName("ProductID");

                entity.Property(e => e.SalesOrderId).HasColumnName("SalesOrderID");

                entity.Property(e => e.String1).HasMaxLength(50);

                entity.Property(e => e.String2).HasMaxLength(50);

                entity.Property(e => e.String3).HasMaxLength(50);

                entity.Property(e => e.String4).HasMaxLength(50);

                entity.Property(e => e.String5).HasMaxLength(50);

                entity.Property(e => e.String6).HasMaxLength(50);

                entity.Property(e => e.String7).HasMaxLength(50);

                entity.Property(e => e.String8).HasMaxLength(50);

                entity.Property(e => e.UnitPrice).HasColumnType("money");


                entity.HasOne(d => d.SalesOrder)
                    .WithMany(p => p.SalesOrderDetails)
                    .HasForeignKey(d => d.SalesOrderId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__SalesOrde__Sales__6DCC4D03");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
