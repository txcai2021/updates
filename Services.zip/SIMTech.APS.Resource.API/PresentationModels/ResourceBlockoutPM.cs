﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;

using SIMTech.APS.Resources;

namespace SIMTech.APS.Resource.API.PresentationModels
{

    public class ResourceBlockoutPM
    {
        public ResourceBlockoutPM()
        {

        }

        [Key]
        public int EquipmentBlockOutID { get; set; }

        public int EquipmentID { get; set; }

        public string BlockOutType { get; set; }
        public string EquipmentName { get; set; }
        public string Operator { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Remarks { get; set; }
        public int Value { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedBy { get; set; }


    }
}
