﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace SIMTech.APS.Routing.API.DBContext
{
    using SIMTech.APS.Routing.API.Models;
    public  class RouteContext : DbContext
    {
        public RouteContext()
        {
        }

        public RouteContext(DbContextOptions<RouteContext> options)
            : base(options)
        {
        }

        public virtual DbSet<ProductRoute> ProductRoutes { get; set; }
        public virtual DbSet<ProductRouteStatus> ProductRouteStatuses { get; set; }
        public virtual DbSet<Route> Routes { get; set; }
        public virtual DbSet<RouteOperation> RouteOperations { get; set; }

        

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<ProductRoute>(entity =>
            {
                entity.ToTable("ProductRoute");

                entity.HasIndex(e => new { e.ProductRouteName, e.Type, e.Version }, "IX_ProductRoute_ProductRouteNameTypeVersion")
                    .IsUnique();

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn)
                    .HasColumnType("datetime");


                entity.Property(e => e.ProductRouteName)
                    .IsRequired()
                    .HasMaxLength(250);

                entity.Property(e => e.String1).HasMaxLength(50);

                entity.Property(e => e.String2).HasMaxLength(50);

                entity.Property(e => e.Type).HasDefaultValueSql("((1))");


                entity.HasOne(d => d.Route)
                    .WithMany(p => p.ProductRoutes)
                    .HasForeignKey(d => d.RouteId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ProductRoute_Route");
            });

            modelBuilder.Entity<ProductRouteStatus>(entity =>
            {
                entity.ToTable("ProductRouteStatus");

                entity.Property(e => e.ApprovedBy)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn)
                    .HasColumnType("datetime");



                entity.HasOne(d => d.ProductRoute)
                    .WithMany(p => p.ProductRouteStatuses)
                    .HasForeignKey(d => d.ProductRouteId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ProductRouteStatus_ProductRoute");
            });

            modelBuilder.Entity<Route>(entity =>
            {
                entity.ToTable("Route");

                entity.HasIndex(e => new { e.RouteName, e.Version }, "IX_Route_RouteNameVersion")
                    .IsUnique();

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Description).HasMaxLength(250);

                entity.Property(e => e.LocationId).HasColumnName("LocationID");

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn).HasColumnType("datetime");

                entity.Property(e => e.RouteName)
                    .IsRequired()
                    .HasMaxLength(250);

            });

            modelBuilder.Entity<RouteOperation>(entity =>
            {
                entity.ToTable("RouteOperation");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DefaultResourceId).HasColumnName("DefaultResourceID");

                entity.Property(e => e.ModifiedBy).HasMaxLength(32);

                entity.Property(e => e.ModifiedOn)
                    .HasColumnType("datetime");


                entity.HasOne(d => d.Route)
                    .WithMany(p => p.RouteOperationRoutes)
                    .HasForeignKey(d => d.RouteId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_RouteOperation_Route");

                entity.HasOne(d => d.Subroute)
                    .WithMany(p => p.RouteOperationSubroutes)
                    .HasForeignKey(d => d.SubrouteId)
                    .HasConstraintName("FK_RouteOperation_Route1");
            });


        }

    }
}
