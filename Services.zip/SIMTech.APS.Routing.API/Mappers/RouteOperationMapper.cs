﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SIMTech.APS.Routing.API.Mappers
{
    using SIMTech.APS.Routing.API.Models;
    using SIMTech.APS.Routing.API.PresentationModels;


    /// <summary>
    /// Maps  PMs (Presentation Models) to  BOs (Business Objects) and vice versa.
    /// </summary>
    public static class RouteOperationMapper
    {

        /// <summary>
        /// Transforms list of routeoperation BOs list of routeoperation PMs.
        /// </summary>
        /// <param name="routeoperations">List of routeoperation BOs.</param>
        /// <returns>List of routeoperation PMs.</returns>
        public static IList<RouteOperationPM> ToPresentationModels(IEnumerable<RouteOperation> routeoperations)
        {
            if (routeoperations == null) return null;
            return routeoperations.Select(u => ToPresentationModel(u)).ToList();
        }

        /// <summary>
        /// Transforms routeoperation BO to routeoperation PM.
        /// </summary>
        /// <param name="routeoperation">routeoperation BO.</param>
        /// <returns>routeoperation PM.</returns>
        public static RouteOperationPM ToPresentationModel(RouteOperation routeoperation)
        {
            if (routeoperation == null) return null;

            return new RouteOperationPM
            {
                Id = routeoperation.Id,

                RouteId = routeoperation.RouteId,
                OperationId = routeoperation.OperationId,
                SubRouteId = routeoperation.SubrouteId,

                Sequence = routeoperation.Sequence,
                Instruction = routeoperation.Instruction,

                IsSelected = (routeoperation.DefaultResourceId == 0 ? false: true),

                Remarks = routeoperation.CreatedBy,
                //CreatedBy = routeoperation.CreatedBy,
                //ModifiedBy = routeoperation.ModifiedBy,
                PictureId = (String.IsNullOrWhiteSpace(routeoperation.ModifiedBy) ? 0 : Convert.ToInt32(routeoperation.ModifiedBy)),

                CreatedDate = routeoperation.CreatedOn,
                ModifiedDate = routeoperation.ModifiedOn

                //OperationOperations = ToPresentationModels(routeoperation.OperationOperations),
            };
        }


        /// <summary>
        /// Transforms list of routeoperation PMs list of routeoperation BOs.
        /// </summary>
        /// <param name="resourceoperationPMs">List of routeoperation PMs.</param>
        /// <returns>List of routeoperation BOs.</returns>
        public static IList<RouteOperation> FromPresentationModels(IEnumerable<RouteOperationPM> routeoperationPMs)
        {
            if (routeoperationPMs == null) return null;
            return routeoperationPMs.Select(u => FromPresentationModel(u)).ToList();
        }

        /// <summary>
        /// Transforms routeoperation PM to routeoperation BO.
        /// </summary>
        /// <param name="resourceoperationPM">routeoperation PM.</param>
        /// <returns>routeoperation BO.</returns>
        public static RouteOperation FromPresentationModel(RouteOperationPM routeoperationPM)
        {
            if (routeoperationPM == null) return null;

            return new RouteOperation
            {
                Id = routeoperationPM.Id,
                
                RouteId = routeoperationPM.RouteId,
                OperationId = routeoperationPM.OperationId,
                SubrouteId = routeoperationPM.SubRouteId,
                Instruction = routeoperationPM.Instruction,
               

                Sequence = routeoperationPM.Sequence,
                DefaultResourceId = routeoperationPM.IsSelected?1:0,                

                //CreatedBy = routeoperationPM.CreatedBy,
                CreatedBy = routeoperationPM.Remarks,
                ModifiedBy = routeoperationPM.PictureId!=null ? routeoperationPM.PictureId.ToString():null,

                CreatedOn = routeoperationPM.CreatedDate,
                ModifiedOn = routeoperationPM.ModifiedDate

                //RouteOperation = FromPresentationModels(resourceoperationPM.OperationOperations)
                
            };
        }

      
    }
}
