﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.Operation.API.Models
{
    using SIMTech.APS.Models;
    public partial class OperationResource:BaseEntity
    {
        public int OperationId { get; set; }
        public int? ResourceId { get; set; }
        public string Instruction { get; set; }
        public double? Cost { get; set; }
        public double? Pretime { get; set; }
        public double? Posttime { get; set; }
        public double? Duration { get; set; }
        public double? DurationPer { get; set; }
        public bool? IsDefault { get; set; }
     

        public virtual Operation Operation { get; set; }
    }
}
