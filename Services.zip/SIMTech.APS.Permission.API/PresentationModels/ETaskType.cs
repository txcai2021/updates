﻿namespace SIMTech.APS.Permission.API.Enums
{
    public enum ETaskType
    {
        MenuItem,
        ToolbarAction
    }

    
}
