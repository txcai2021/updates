﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

#nullable disable

namespace SIMTech.APS.DeliveryOrder.API.Models
{
    using SIMTech.APS.Models;

    [Table("DeliveryOrderDetail")]
    public  class DeliveryOrderDetail : BaseEntity
    {

        [Column("DeliveryOrderID")]
        public int DeliveryOrderId { get; set; }
        [Column("WorkOrderID")]
        public int? WorkOrderId { get; set; }
        [Column("SalesOrderLineID")]
        public int? SalesOrderLineId { get; set; }
        [Column(TypeName = "decimal(18, 2)")]
        public decimal? UnitPrice { get; set; }
        public double Quantity { get; set; }
        public string Comment { get; set; }
        [StringLength(50)]
        public string String1 { get; set; }
        [StringLength(50)]
        public string String2 { get; set; }
        [StringLength(50)]
        public string String3 { get; set; }
        [StringLength(250)]
        public string String4 { get; set; }
        [StringLength(50)]
        public string String5 { get; set; }
        [StringLength(50)]
        public string String6 { get; set; }
        [StringLength(50)]
        public string String7 { get; set; }
        [StringLength(50)]
        public string String8 { get; set; }
        [StringLength(50)]
        public string String9 { get; set; }
        [StringLength(50)]
        public string String10 { get; set; }
        [StringLength(250)]
        public string String11 { get; set; }
        [StringLength(250)]
        public string String12 { get; set; }
        [StringLength(250)]
        public string String13 { get; set; }
        [StringLength(250)]
        public string String14 { get; set; }
        [StringLength(250)]
        public string String15 { get; set; }
        [StringLength(250)]
        public string String16 { get; set; }
        [StringLength(250)]
        public string String17 { get; set; }
        [StringLength(250)]
        public string String18 { get; set; }
        [StringLength(250)]
        public string String19 { get; set; }
        [StringLength(250)]
        public string String20 { get; set; }
        [StringLength(250)]
        public string String21 { get; set; }
        [StringLength(250)]
        public string String22 { get; set; }
        [StringLength(250)]
        public string String23 { get; set; }
        [StringLength(250)]
        public string String24 { get; set; }
        [StringLength(250)]
        public string String25 { get; set; }
        [StringLength(250)]
        public string String26 { get; set; }
        [StringLength(250)]
        public string String27 { get; set; }
        [StringLength(250)]
        public string String28 { get; set; }
        [StringLength(250)]
        public string String29 { get; set; }
        [StringLength(250)]
        public string String30 { get; set; }
        [StringLength(250)]
        public string String31 { get; set; }
        [StringLength(250)]
        public string String32 { get; set; }
        [StringLength(250)]
        public string String33 { get; set; }
        [StringLength(250)]
        public string String34 { get; set; }
        [StringLength(250)]
        public string String35 { get; set; }
        [StringLength(250)]
        public string String36 { get; set; }
        [StringLength(250)]
        public string String37 { get; set; }
        [StringLength(250)]
        public string String38 { get; set; }
        [StringLength(250)]
        public string String39 { get; set; }
        [StringLength(250)]
        public string String40 { get; set; }
        [StringLength(250)]
        public string String41 { get; set; }
        [StringLength(250)]
        public string String42 { get; set; }
        [StringLength(250)]
        public string String43 { get; set; }
        [StringLength(250)]
        public string String44 { get; set; }
        [StringLength(250)]
        public string String45 { get; set; }
        [StringLength(250)]
        public string String46 { get; set; }
        [StringLength(250)]
        public string String47 { get; set; }
        [StringLength(250)]
        public string String48 { get; set; }
        [StringLength(250)]
        public string String49 { get; set; }
        [StringLength(250)]
        public string String50 { get; set; }
        public string MaxString1 { get; set; }
        public string MaxString2 { get; set; }
        public bool? Flag1 { get; set; }
        public bool? Flag2 { get; set; }
        public bool? Flag3 { get; set; }
        public bool? Flag4 { get; set; }
        public bool? Flag5 { get; set; }
        public bool? Flag6 { get; set; }
        public bool? Flag7 { get; set; }
        public bool? Flag8 { get; set; }
        public bool? Flag9 { get; set; }
        public bool? Flag10 { get; set; }
        public bool? Flag11 { get; set; }
        public bool? Flag12 { get; set; }
        public bool? Flag13 { get; set; }
        public bool? Flag14 { get; set; }
        public bool? Flag15 { get; set; }
        public bool? Flag16 { get; set; }
        public bool? Flag17 { get; set; }
        public bool? Flag18 { get; set; }
        public bool? Flag19 { get; set; }
        public bool? Flag20 { get; set; }
        public bool? Flag21 { get; set; }
        public bool? Flag22 { get; set; }
        public bool? Flag23 { get; set; }
        public bool? Flag24 { get; set; }
        public bool? Flag25 { get; set; }
        public bool? Flag26 { get; set; }
        public bool? Flag27 { get; set; }
        public bool? Flag28 { get; set; }
        public bool? Flag29 { get; set; }
        public bool? Flag30 { get; set; }
        public bool? Flag31 { get; set; }
        public bool? Flag32 { get; set; }
        public bool? Flag33 { get; set; }
        public bool? Flag34 { get; set; }
        public bool? Flag35 { get; set; }
        public bool? Flag36 { get; set; }
        public bool? Flag37 { get; set; }
        public bool? Flag38 { get; set; }
        public bool? Flag39 { get; set; }
        public bool? Flag40 { get; set; }
        public bool? Flag41 { get; set; }
        public bool? Flag42 { get; set; }
        public bool? Flag43 { get; set; }
        public bool? Flag44 { get; set; }
        public bool? Flag45 { get; set; }
        public bool? Flag46 { get; set; }
        public bool? Flag47 { get; set; }
        public bool? Flag48 { get; set; }
        public bool? Flag49 { get; set; }
        public bool? Flag50 { get; set; }
        public int? Int1 { get; set; }
        public int? Int2 { get; set; }
        public int? Int3 { get; set; }
        public int? Int4 { get; set; }
        public int? Int5 { get; set; }
        public int? Int6 { get; set; }
        public double? Float1 { get; set; }
        public double? Float2 { get; set; }
        public double? Float3 { get; set; }
        public double? Float4 { get; set; }      

        [ForeignKey(nameof(DeliveryOrderId))]
        [InverseProperty("DeliveryOrderDetails")]
        public virtual DeliveryOrder DeliveryOrder { get; set; }
    }
}
