﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SIMTech.APS.Routing.API.Repository
{
    using SIMTech.APS.Routing.API.Models;
    using SIMTech.APS.Routing.API.DBContext;
    using SIMTech.APS.Repository;

    public class ProductRouteRepository : Repository<ProductRoute>,  IProductRouteRepository
    {
        private readonly RouteContext _dbContext;
        public ProductRouteRepository(RouteContext context) : base(context) { _dbContext = context; }

        public async Task<IEnumerable<ProductRoute>> GetProductRoutes(int productId)
        {
            var productRoutes = _dbContext.ProductRoutes.Include(o => o.Route).Where(x=>x.Id >0);

            if (productId > 0)
                productRoutes = productRoutes.Where(x => x.ProductId==productId);

            return await productRoutes.ToListAsync();
        }

    }
}
