﻿using System.Collections.Generic;

namespace SIMTech.APS.Setting.API.Repository
{
    using SIMTech.APS.Setting.API.Models;
    using SIMTech.APS.Repository;
    public interface ICodeRepository : IRepository<CodeType>
    {
        IEnumerable<CodeType> GetCodes(int codeId = 0);
        IEnumerable<CodeType> GetCodesbyName(string codeName = "");

    }
}
