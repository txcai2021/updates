﻿namespace SIMTech.APS.SalesOrder.API.Enums
{
    public enum ERoutingStatus
    {
        Initial,
        New,
        S1_Rejected,
        S1_Approved,
        S2_Rejected,
        S2_Approved,
        S3_Rejected,
        S3_Approved,
        S4_Rejected,
        S4_Approved,
        S5_Rejected,
        S5_Approved
    }
}
