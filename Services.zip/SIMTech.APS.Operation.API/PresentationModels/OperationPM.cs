﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;

using SIMTech.APS.Resources;

namespace SIMTech.APS.Operation.API.PresentationModels
{
    /// <summary>
    /// Operation class exposes the following data members to the client:
    /// UserName, FirstName, LastName, Mobile, Email, IsLockedOut, Comment, 
    /// LastLoginDate, LastPasswordChangedDate, LastLockoutDate, FailedPasswordAttemptCount,
    /// and CreatedDate
    /// </summary>
    public class OperationPM
    {
        public OperationPM()
        {
            operationResourcePMs = new List<OperationResourcePM>();
            rpIdNameList = new List<string>();
          //  operationParameterPMs = new List<OperationParameterPM>();
          //  operationSParameterPMs = new List<OperationSParameterPM>();
          //  operationDataCollectionPMs = new List<OperationDataCollectionPM>();

            if (string.IsNullOrEmpty(Category))
            {
                //Category = "INHOUSE";
                Category = ""; //used to store list of raw material id
            }
        }

        [Key]
        //[Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
        public int Id { get; set; }

        [StringLength(50)]
        [Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
      //  [Display(ShortName = "Name", ResourceType = typeof(SharedResources), Name = "Name", Order = 0)]
        //[RegularExpression("^[a-zA-Z0-9_]*$", ErrorMessageResourceName = "ValidationErrorInvalidName", ErrorMessageResourceType = typeof(ErrorResources))]
        public string Name { get; set; }

      //  [Display(ShortName = "Type", ResourceType = typeof(SharedResources), Name = "Type", Order = 1)]
        //[CustomValidation(typeof(UserRules), "IsValidEmail")]
        public byte Type { get; set; }

       // [Display(ShortName = "LocationId", ResourceType = typeof(SharedResources), Name = "LocationId", Order = 2)]
        public int? LocationId { get; set; }

        public string LocationName { get; set; }

        //[Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
      //  [Display(ShortName = "Active", ResourceType = typeof(SharedResources), Name = "Active", Order = 3)]
        public Boolean Active { get; set; }

     //   [Display(ShortName = "Description", ResourceType = typeof(SharedResources), Name = "Description", Order = 4)]
        public string Description { get; set; }

      //  [Display(ShortName = "Comment", ResourceType = typeof(SharedResources), Name = "Comment", Order = 5)]
        public string Comment { get; set; }

        [Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
        [Display(ShortName = "CreatedDate", ResourceType = typeof(SharedResources), Name = "CreatedDate", Order = 6)]
        public DateTime CreatedDate { get; set; }

        [Display(ShortName = "Min Size",  Name = "Min Size")]
        public double? MinSize { get; set; }

        [Display(ShortName = "Max Size", Name = "Max Size")]
        public double? MaxSize { get; set; }

        [Display(ShortName = "Size Multiple", Name = "Size Multiple")]
        public double? SizeMultiple { get; set; }

        public int Routes { get; set; }

        public int Resources { get; set; }

        public string Remarks { get; set; }

       
        
        public List<OperationResourcePM> operationResourcePMs { get; set; }

        public string ResourceNames { get; set; }

        public string ResourceName { get; set; }

        public string RouteNames { get; set; }
        //[Include]
        //[Composition]
        //[Association("FK_Operation_RoutingOperations", "Id", "OperationId")]
        //public IEnumerable<RoutingOperationPM> routingOperationPMs { get; set; }

        public int Parameters { get; set; }

       
     //   public List<OperationParameterPM> operationParameterPMs { get; set; }

        public string ParameterNames { get; set; }

        public string OperationParameterReport { get; set; }

        public Boolean IsParameter { get; set; }

        public int DataCollections { get; set; }

        
       // public List<OperationDataCollectionPM> operationDataCollectionPMs { get; set; }

        public string DataCollectionNames { get; set; }

        public Boolean IsLargeImage { get; set; }
        public Boolean IsThumbNailImage { get; set; }

        public string LargeImageFileName { get; set; }
        public string ThumbNailImageFileName { get; set; }

        public byte[] ThumbNailImage { get; set; }
        public byte[] LargeImage { get; set; }

        public int? PictureId { get; set; }

        public int OperationDataCollectionId { get; set; }
        public string OperationDataCollectionName { get; set; }
        public string OperationDataCollectionReport { get; set; }
        public string OperationDataCollectionUOM { get; set; }
        public string OperationDataCollectionCriteria { get; set; }

        public Boolean IsDataCollection { get; set; }

        public int SParameters { get; set; }


      //  public List<OperationSParameterPM> operationSParameterPMs { get; set; }

        public string SParameterNames { get; set; }

        public string OperationSParameterReport { get; set; }

        public Boolean IsSParameter { get; set; }

        public string OK { get; set; }
        public string NG { get; set; }

        public string Category { get; set; }

        public string Instruction { get; set; }

        public int? Version { get; set; }

        public DateTime ModifiedDate { get; set; }

        public short? NoofReading { get; set; }

        public List<string> rpIdNameList { get; set; }

        public byte[] PdfFile { get; set; }
        public byte[] ImageFile { get; set; }
        public bool IsPdfFile { get; set; }
         
    }
}
