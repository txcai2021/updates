﻿using System.Collections.Generic;

namespace SIMTech.APS.DeliveryOrder.API.Repository
{
    using SIMTech.APS.DeliveryOrder.API.Models;
    using SIMTech.APS.Repository;
    public interface IDeliveryOrderRepository : IRepository<DeliveryOrder>
    {     
                   
    }
}
