﻿using System.Collections.Generic;
using System.Linq;


namespace SIMTech.APS.Permission.API.Mappers
{
    using SIMTech.APS.Permission.API.Models;
    using SIMTech.APS.Permission.API.PresentationModels;
    public class RoleTaskMapper
    {
        public static IEnumerable<RoleTaskPM> ToPresentationModels(IEnumerable<RoleTask> roleTasks)
        {
            if (roleTasks == null) return null;
            return roleTasks.Select(ToPresentationModel);
        }

        public static RoleTaskPM ToPresentationModel(RoleTask roleTask)
        {
            if (roleTask == null) return null;

            return new RoleTaskPM
            {
                Id = roleTask.Id,
                RoleId = roleTask.RoleId,
                TaskId = roleTask.TaskId,
                AccessMode = string.IsNullOrEmpty(roleTask.AccessMode) ? string.Empty : roleTask.AccessMode.Trim(),
            };
        }

        public static RoleTask FromPresentationModel(RoleTaskPM roleTaskPM)
        {
            if (roleTaskPM == null) return null;

            return new RoleTask
            {
                Id = roleTaskPM.Id,
                RoleId = roleTaskPM.RoleId,
                TaskId = roleTaskPM.TaskId,
                AccessMode = roleTaskPM.AccessMode
            };
        }

        public static void UpdatePresentationModel(RoleTaskPM roleTaskPM, RoleTask roleTask)
        {
            if (roleTaskPM == null || roleTask == null) return;

            roleTaskPM.Id = roleTask.Id;
            roleTaskPM.RoleId = roleTask.RoleId;
            roleTaskPM.TaskId = roleTask.TaskId;
            roleTaskPM.AccessMode = string.IsNullOrEmpty(roleTask.AccessMode) ? string.Empty : roleTask.AccessMode.Trim();
        }
    }
}
