﻿using System.Collections.Generic;

namespace SIMTech.APS.Resource.API.Repository
{
    using SIMTech.APS.Resource.API.Models;
    using SIMTech.APS.Repository;
    public interface IFixtureSettingRepository : IRepository<FixtureSetting>
    {     
                   
    }
}
