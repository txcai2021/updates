﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SIMTech.APS.Operation.API.Mappers
{
    using SIMTech.APS.Operation.API.Models;
    using SIMTech.APS.Operation.API.PresentationModels;

    /// <summary>
    /// Maps  PMs (Presentation Models) to  BOs (Business Objects) and vice versa.
    /// </summary>
    public static class OperationDataCollectionMapper
    {

        /// <summary>
        /// Transforms list of operationParameter BOs list of operationParameter PMs.
        /// </summary>
        /// <param name="resourceparameters">List of operationParameter BOs.</param>
        /// <returns>List of operationParameter PMs.</returns>
        public static IList<OperationDataCollectionPM> ToPresentationModels(IEnumerable<OperationParameter> operationParameters)
        {
            if (operationParameters == null) return null;
            return operationParameters.Select(u => ToPresentationModel(u)).ToList();
        }

        /// <summary>
        /// Transforms operationParameter BO to operationParameter PM.
        /// </summary>
        /// <param name="operationParameter">operationParameter BO.</param>
        /// <returns>operationParameter PM.</returns>
        public static OperationDataCollectionPM ToPresentationModel(OperationParameter operationParameter)
        {
            if (operationParameter == null) return null;

            return new OperationDataCollectionPM
            {
                Id = operationParameter.Id,

                OperationId = operationParameter.OperationId,
                DataCollectionId = operationParameter.ParamterId,

                DataCollectionDefaultValue = operationParameter.Value,
                MinSign = operationParameter.Int2,
                DataCollectionMinValue = operationParameter.MinValue,
                MaxSign = operationParameter.Int3,
                DataCollectionMaxValue = operationParameter.MaxValue,

                NoofReading = operationParameter.NoofReading,
                PictureId = operationParameter.Int1,
                Criteria = operationParameter.Int4,

                DataCollectionExtMinValue = operationParameter.MaxString1,
                DataCollectionExtMaxValue = operationParameter.MaxString2,

                DataCollectionUoM = operationParameter.Uom,

                CreatedDate = operationParameter.CreatedOn,
                ModifiedDate = operationParameter.ModifiedOn.Value

                //OperationOperations = ToPresentationModels(operationParameter.OperationOperations),
            };
        }


        /// <summary>
        /// Transforms list of operationParameter PMs list of operationParameter BOs.
        /// </summary>
        /// <param name="operationDataCollectionPMs">List of operationParameter PMs.</param>
        /// <returns>List of operationParameter BOs.</returns>
        public static IList<OperationParameter> FromPresentationModels(IEnumerable<OperationDataCollectionPM> operationDataCollectionPMs)
        {
            if (operationDataCollectionPMs == null) return null;
            return operationDataCollectionPMs.Select(u => FromPresentationModel(u)).ToList();
        }

        /// <summary>
        /// Transforms operationParameter PM to operationParameter BO.
        /// </summary>
        /// <param name="resourceoperationPM">operationParameter PM.</param>
        /// <returns>operationParameter BO.</returns>
        public static OperationParameter FromPresentationModel(OperationDataCollectionPM operationDataCollectionPM)
        {
            if (operationDataCollectionPM == null) return null;

            return new OperationParameter
            {
                Id = operationDataCollectionPM.Id,

                ParamterId = operationDataCollectionPM.DataCollectionId,
                OperationId = operationDataCollectionPM.OperationId,

                Value = operationDataCollectionPM.DataCollectionDefaultValue,
                
                Int2 = operationDataCollectionPM.MinSign,
                MinValue = operationDataCollectionPM.DataCollectionMinValue,
                Int3 = operationDataCollectionPM.MaxSign,
                MaxValue = operationDataCollectionPM.DataCollectionMaxValue,

                NoofReading = operationDataCollectionPM.NoofReading,
                Int1 = operationDataCollectionPM.PictureId,
                Int4 = operationDataCollectionPM.Criteria,

                MaxString1 = operationDataCollectionPM.DataCollectionExtMinValue,
                MaxString2 = operationDataCollectionPM.DataCollectionExtMaxValue,
                Uom = operationDataCollectionPM.DataCollectionUoM,

                CreatedOn = operationDataCollectionPM.CreatedDate,
                ModifiedOn = operationDataCollectionPM.ModifiedDate

                //OperationParameter = FromPresentationModels(resourceoperationPM.OperationOperations)
                
            };
        }

      
    }
}
