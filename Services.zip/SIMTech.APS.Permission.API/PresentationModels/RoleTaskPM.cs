﻿using System.ComponentModel.DataAnnotations;

namespace SIMTech.APS.Permission.API.PresentationModels
{
    public class RoleTaskPM
    {
        [Key]
        public int Id { get; set; }

        public int RoleId { get; set; }

        public int TaskId { get; set; }

        public string AccessMode { get; set; }
    }
}
