﻿//namespace SIMTech.APS.Order.Services.Web.Enums
namespace SIMTech.APS.SalesOrder.API.Enums
{
    public enum ERawMaterialType : byte
    {
        //RoundRod = 0,
        //FlatBar = 1,
        //Plate = 2,
        //Pipe = 3,
        //SquareBar = 4,
        //AF = 5,
        
        FlatBar = 0,
        SquareBar = 1,
        Pipe = 2,
        RoundRod = 3,
        Plate = 4,
        AF = 5,
    }
}
