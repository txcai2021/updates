﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;

namespace SIMTech.APS.Calendar.API.Mappers
{

    using SIMTech.APS.Calendar.API.PresentationModels;
    using SIMTech.APS.Calendar.API.Models;

    public static class CalendarMapper
    {
        public static IList<CalendarPM> ToPresentationModels(IEnumerable<Calendar> resources)
        {
            if (resources == null) return null;
            return resources.Select(u => ToPresentationModel(u)).ToList();
        }

        public static CalendarPM ToPresentationModel(Calendar calendar)
        {
            if (calendar == null) return null;

            return new CalendarPM
            {
                Id = calendar.Id,
                Name = calendar.CalendarName,
                Type = calendar.Type,
                Category = calendar.Category,
                Description = calendar.Description,
                DefaultValue = calendar.DefaultValue,
                StartTime = calendar.StartTime != null ? ((int)calendar.StartTime).ToString("D4").Insert(2, ":") : "",
                EndTime = calendar.EndTime != null ? ((int)calendar.EndTime).ToString("D4").Insert(2, ":") : "",
                StartDate = calendar.StartDate,
                EndDate = calendar.EndDate,
                CreatedDate = calendar.CreatedOn,
                ModifiedDate = calendar.ModifiedOn != null ? calendar.ModifiedOn.Value : DateTime.Now,
                CalendarDetails = CalendarDetailMapper.ToPresentationModels(calendar.CalendarDetailCalendars),
                CalendarChilds = CalendarDetailMapper.ToPresentationModels(calendar.CalendarDetailParentCalendars)
            };
        }

        public static IList<Calendar> FromPresentationModels(IEnumerable<CalendarPM> calendarPMs)
        {
            if (calendarPMs == null) return null;
            return calendarPMs.Select(u => FromPresentationModel(u)).ToList();
        }

        public static Calendar FromPresentationModel(CalendarPM calendarPM)
        {
            if (calendarPM == null) return null;

            return new Calendar
            {
                Id = calendarPM.Id,
                CalendarName = calendarPM.Name,
                Type = calendarPM.Type,
                Category = calendarPM.Category,
                Description = calendarPM.Description,
                DefaultValue = calendarPM.DefaultValue,
                StartTime = calendarPM.StartTime != null && !string.IsNullOrWhiteSpace(calendarPM.StartTime) ? Convert.ToInt32(calendarPM.StartTime.Replace(":", "")) : new Nullable<int>(),
                EndTime = calendarPM.EndTime != null && !string.IsNullOrWhiteSpace(calendarPM.EndTime) ? Convert.ToInt32(calendarPM.EndTime.Replace(":", "")) : new Nullable<int>(),
                StartDate = calendarPM.StartDate,
                EndDate = calendarPM.EndDate,
                CreatedOn = calendarPM.CreatedDate,
                ModifiedOn = calendarPM.ModifiedDate

            };
        }

        public static void UpdatePresentationModel(CalendarPM calendarpm, Calendar dbCalendar)
        {
            if (calendarpm == null || dbCalendar == null) return;

            calendarpm.Description = dbCalendar.Description;
            calendarpm.Name = dbCalendar.CalendarName;
            calendarpm.Type = dbCalendar.Type;
            calendarpm.Id = dbCalendar.Id;
            calendarpm.StartDate = dbCalendar.StartDate;
            calendarpm.EndDate = dbCalendar.EndDate;
            // calendarpm.StartTime = dbCalendar.StartTime;
            // calendarpm.EndTime = dbCalendar.EndTime;
        }
    }
}
