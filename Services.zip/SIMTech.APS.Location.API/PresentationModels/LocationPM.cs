﻿using System.ComponentModel.DataAnnotations;
using SIMTech.APS.Resources;
using System;
using System.Collections;
using System.Collections.Generic;

namespace SIMTech.APS.Location.API.PresentationModels
{
    using SIMTech.APS.Customer.API.PresentationModels;
    public class LocationPM
    {
        [Key]
        public int Id { get; set; }

      //  [Display(ShortName = "LocationName", ResourceType = typeof(SharedResources), Name = "LocationName")]
        public string Name { get; set; }

      //  [Display(ShortName = "LocationCategory", ResourceType = typeof(SharedResources), Name = "LocationCategory")]
        public string Category { get; set; }

       // [Display(ShortName = "LocationSubCategory", ResourceType = typeof(SharedResources), Name = "LocationSubCategory")]
        public string SubCategory { get; set; }

      //  [Display(ShortName = "LocationDescription", ResourceType = typeof(SharedResources), Name = "LocationDescription")]
        public string Description { get; set; }

        public int? CalenderID { get; set; }

        public int NoOfProductionLines { get; set; }

        public int? CompanyLogoId { get; set; }

       
        public int CustomerId { get; set; }


        //public IEnumerable<BasePM> Operations { get; set; }

        public int[] OperationIds { get; set; }

        public CustomerPM Customer { get; set; }

        public DateTime? CreatedOn { get; set; }
    }
}
