﻿using System.Collections.ObjectModel;

namespace SIMTech.APS.Permission.API.PresentationModels
{
    public class MenuItemPM : TaskPM
    {
        public ObservableCollection<MenuItemPM> SubMenuItems { get; set; }

        public ObservableCollection<ToolbarActionPM> ToolbarActions { get; set; }
    }
}
