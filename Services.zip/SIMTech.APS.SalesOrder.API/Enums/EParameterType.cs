
namespace SIMTech.APS.SalesOrder.API.Enums
{
    public enum EParameterType
    {
        PARAMETER,
        DATACOLLECTION,
	    CONTROLPARAMETER,
        STATUSPARAMETER,
        MEASUREPARAMETER
    }
}
