﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.Permission.API.Models
{
    using SIMTech.APS.Models;
    public partial class RoleTask :BaseEntity
    {

        public int RoleId { get; set; }
        public int TaskId { get; set; }
        public string AccessMode { get; set; }

        public virtual Role Role { get; set; }
        public virtual Task Task { get; set; }
    }
}
