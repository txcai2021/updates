﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace SIMTech.APS.User.API.Repository
{
    using SIMTech.APS.User.API.Models;
    using SIMTech.APS.User.API.DBContext;
    using SIMTech.APS.Repository;

    public class UserRepository : Repository<User>,  IUserRepository
    {
        private readonly UserContext _dbContext;
        public UserRepository(UserContext context) : base(context) { _dbContext = context; }
        public User GetUserByName(string UserName)
        {
           
            return _dbContext.Users.FirstOrDefault(user => user.LoginId.Equals(UserName));
        }

               
        public int CountConcurrentUser(string userName)
        {
            return _dbContext.Users.Count(u => u.IsLockedOut != null && u.IsLockedOut == true && u.LoginId != userName);
                
        }     
    }
}
