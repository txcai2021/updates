﻿using System.Collections.Generic;

namespace SIMTech.APS.Scheduling.API.Repository
{
    using SIMTech.APS.Scheduling.API.Models;
    using SIMTech.APS.Repository;
    public interface IScheduleDetailRepository : IRepository<ScheduleDetail>
    {     
                   
    }
}
