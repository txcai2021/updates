﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.ServiceModel.DomainServices.Hosting;
using System.ServiceModel.DomainServices.Server;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using SIMTech.APS.Order.Business;
using SIMTech.APS.Product.Business;
using SIMTech.APS.Product.Web.Mappers;
using SIMTech.APS.Product.Web.PresentationModel;
using SIMTech.APS.Repository;
using SIMTech.APS.Utility;
using System.Diagnostics;
using SIMTech.APS.DLR.Web.Services;
using SIMTech.APS.DLR.Web.PresentationModel;
using SIMTech.APS.Product.Web.Enums;
using SIMTech.APS.DLR.Business;
using SIMTech.APS.Setting.Business;

namespace SIMTech.APS.Product.Web.Services
{
    [EnableClientAccess]
    public class ItemDomainService : DomainService
    {
        private static ExceptionManager _exceptionManager;
        private readonly IRepository _productRepository;
        private readonly IRepository _orderRepository;
        private readonly IRepository _processRepository;
        private readonly IRepository _inventoryRepository;
        private readonly IRepository _settingRepository;


        public ItemDomainService()
        {
            _exceptionManager = EnterpriseLibraryContainer.Current.GetInstance<ExceptionManager>();
            _productRepository = _exceptionManager.Process(() => IoCWorker.Resolve<IRepository>("Product"), "ExceptionShielding");
            _orderRepository = _exceptionManager.Process(() => IoCWorker.Resolve<IRepository>("Order"), "ExceptionShielding");
            _processRepository = _exceptionManager.Process(() => IoCWorker.Resolve<IRepository>("Process"), "ExceptionShielding");
            _inventoryRepository = _exceptionManager.Process(() => IoCWorker.Resolve<IRepository>("DLR"), "ExceptionShielding");
            _settingRepository = _exceptionManager.Process(() => IoCWorker.Resolve<IRepository>("Setting"), "ExceptionShielding");
        }

        #region KitType Services


        public KitTypePM GetKitType(int kitTypeId)
        {
            Item kitType = _exceptionManager.Process(() => _productRepository.GetByKey<Item>(kitTypeId), "ExceptionShielding");
            //return KitTypeMapper.ToPresentationModel(kitType);
            return GetCustomersForKitType(kitType);

        }


        public IQueryable<KitTypePM> GetKitTypes()
        {
            IEnumerable<Item> kitTypes = _exceptionManager.Process(() => _productRepository.GetQuery<Item>(i => i.Category.Equals("ProductHierarchyLevelR")), "ExceptionShielding");
            //return KitTypeMapper.ToPresentationModels(kitTypes).OrderBy(kt => kt.Name).AsQueryable();
            return kitTypes.Select(GetCustomersForKitType).OrderBy(kt => kt.Name).AsQueryable();
        }



        public IQueryable<KitTypePM> GetKitTypesByCustomer(int customerId)
        {
            IEnumerable<CustomerItem> customerItems = _exceptionManager.Process(() => _productRepository.GetQuery<CustomerItem>(ci => ci.CustomerID == customerId && ci.Item.Category.Equals("ProductHierarchyLevelR") && ci.Float2 == null), "ExceptionShielding");
            IEnumerable<Item> kitTypes = customerItems.Select(ci => ci.Item);
            //return KitTypeMapper.ToPresentationModels(kitTypes).OrderBy(kt => kt.Name).AsQueryable();
            return kitTypes.Select(GetCustomersForKitType).OrderBy(kt => kt.Name).AsQueryable();
        }

        public IEnumerable<KitTypePM> GetKitTypesByPage(int pageNumber, int pageSize)
        {
            IEnumerable<Item> kitTypes = _exceptionManager.Process(() => _productRepository.GetByPage<Item>(i => i.Category.Equals("ProductHierarchyLevelR"), i => i.ItemName, pageNumber, pageSize), "ExceptionShielding");

            //return KitTypeMapper.ToPresentationModels(kitTypes).AsQueryable();
            return kitTypes.Select(GetCustomersForKitType).OrderBy(kt => kt.Name).AsQueryable();
        }

        public IEnumerable<KitTypePM> SearchKitTypesByName(int pageNumber, int pageSize, string kitTypeName)
        {

            List<int> customerIds = _orderRepository.GetQuery<Customer>(c => c.Category == "Customer" && c.CustomerName.Contains(kitTypeName)).Select(x => x.CustomerID).ToList();
            
            IEnumerable<Item> kitTypes = _exceptionManager.Process(() => _productRepository.GetByPage<Item>(item => item.Category.Equals("ProductHierarchyLevelR") && (item.ItemName.ToLower().Contains(kitTypeName.ToLower()) || item.Description.ToLower().Contains(kitTypeName.ToLower()) || item.Group1.ToLower().Contains(kitTypeName.ToLower()) || customerIds.Contains(item.CustomerItems.FirstOrDefault().CustomerID)), item => item.ItemName, pageNumber, pageSize), "ExceptionShielding");
            //return KitTypeMapper.ToPresentationModels(kitTypes).AsQueryable();
            return kitTypes.Select(GetCustomersForKitType).OrderBy(kt => kt.Name).AsQueryable();
        }

        public int GetKitTypeCount()
        {
            return _exceptionManager.Process(() => _productRepository.GetQuery<Item>(i => i.Category.Equals("ProductHierarchyLevelR")).Count(), "ExceptionShielding");
        }

        public int SearchKitTypeCountByName(string kitTypeName)
        {
            List<int> customerIds = _orderRepository.GetQuery<Customer>(c => c.Category == "Customer" && c.CustomerName.Contains(kitTypeName)).Select(x => x.CustomerID).ToList();
            
            return _exceptionManager.Process(() => _productRepository.GetQuery<Item>(i => i.Category.Equals("ProductHierarchyLevelR") && (i.ItemName.ToLower().Contains(kitTypeName.ToLower()) || i.Group1.ToLower().Contains(kitTypeName.ToLower()) || i.Description.ToLower().Contains(kitTypeName.ToLower()) || customerIds.Contains(i.CustomerItems.FirstOrDefault().CustomerID))).Count(), "ExceptionShielding");

            //return _exceptionManager.Process(() => _productRepository.GetQuery<Item>(i => i.Category.Equals("ProductHierarchyLevelB") && (i.ItemName.ToLower().Contains(partTypeName.ToLower()) || i.Group1.ToLower().Contains(partTypeName.ToLower()) || i.Description.ToLower().Contains(partTypeName.ToLower()) || customerIds.Contains(i.Int10 ?? 0))).Count(), "ExceptionShielding");
        }

        public void AddKitType(KitTypePM kitTypePM)
        {
            Item existingKitType = _productRepository.Single<Item>(it => it.ItemName.Equals(kitTypePM.Name) && it.Category.Equals("ProductHierarchyLevelR"));
            if (existingKitType != null)
                throw new DomainException("Duplicated part name");
            else
            {
                Item kitType = KitTypeMapper.FromPresentationModel(kitTypePM);
                kitType.Category = "ProductHierarchyLevelR";
                kitType.CreatedOn = DateTime.Today;

                if (kitTypePM.ThumbnailImage != null && kitTypePM.ThumbnailImage.Length > 0)
                {
                    Picture picture = new Picture
                    {
                        ThumbNailImage = kitTypePM.ThumbnailImage,
                        ThumbnailImageFileName = kitTypePM.ThumbnailImageFileName,
                        CreatedOn = DateTime.Today
                    };

                    _exceptionManager.Process(() =>
                    {
                        _productRepository.Add(picture);
                        _productRepository.UnitOfWork.SaveChanges();
                    }, "ExceptionShielding");

                    kitType.PictureID = picture.PictureID;
                }

                _exceptionManager.Process(() =>
                {
                    _productRepository.Add(kitType);
                    _productRepository.UnitOfWork.SaveChanges();
                }, "ExceptionShielding");

                KitTypeMapper.UpdatePresentationModel(kitTypePM, kitType);
            }
        }


        public void UpdateKitType(KitTypePM kitTypePM)
        {
            //var items = _exceptionManager.Process(() => _productRepository.GetQuery<Item>(x=>x.BillOfMaterials.SelectMany(y=>y.Item1.BillOfMaterials) )), "ExceptionShielding");

            //Item kitType = KitTypeMapper.FromPresentationModel(kitTypePM);
            //Item existingKitType = _exceptionManager.Process(() => _productRepository.GetByKey<Item>(kitType.ItemID), "ExceptionShielding");

           
            //foreach (var item in existingKitType.Item1)
            //{
            //    Debug.WriteLine("               @~@" + item.ItemName);
            //}

            //Debug.WriteLine(" Last              @~@" + existingKitType.Item2.ItemName);




            Item kitType = KitTypeMapper.FromPresentationModel(kitTypePM);
            Item existingKitType = _exceptionManager.Process(() => _productRepository.GetByKey<Item>(kitType.ItemID), "ExceptionShielding");

            existingKitType.Category = kitType.Category;
            existingKitType.Description = kitType.Description;
            existingKitType.ItemName = kitType.ItemName;
            existingKitType.UnitPrice = kitType.UnitPrice;
          
            existingKitType.Group1 = kitType.Group1;
            existingKitType.Group2 = kitType.Group2;
            existingKitType.Group3 = kitType.Group3;

            existingKitType.Int6 = kitType.Int6;
            existingKitType.Int7 = kitType.Int7;
            //existingKitType.Int8 = kitType.Int8;
            //existingKitType.Int9 = kitType.Int9;

            //existingKitType.Int5 = kitType.Int5;
            //existingKitType.Int6 = kitType.Int6;            
            existingKitType.String4 = kitType.String4;  
            existingKitType.String9 = kitType.String9;            
            existingKitType.MaxString1 = kitType.MaxString1;

            existingKitType.Flag2 = kitType.Flag2;
            existingKitType.Float1 = kitType.Float1;

            if (existingKitType.PictureID != null && kitTypePM.ThumbnailImage != null && kitTypePM.ThumbnailImage.Length > 0)
            {
                Picture existingPicture = _exceptionManager.Process(() => _productRepository.GetByKey<Picture>(existingKitType.PictureID), "ExceptionShielding");
                existingPicture.ThumbNailImage = kitTypePM.ThumbnailImage;
                existingPicture.ThumbnailImageFileName = kitTypePM.ThumbnailImageFileName;

                _exceptionManager.Process(() =>
                {
                    _productRepository.Update(existingPicture);
                    _productRepository.UnitOfWork.SaveChanges();
                }, "ExceptionShielding");
            }
            else if (existingKitType.PictureID == null && kitTypePM.ThumbnailImage != null && kitTypePM.ThumbnailImage.Length > 0)
            {
                Picture picture = new Picture
                {
                    ThumbNailImage = kitTypePM.ThumbnailImage,
                    ThumbnailImageFileName = kitTypePM.ThumbnailImageFileName,
                    CreatedOn = DateTime.Today
                };

                _exceptionManager.Process(() =>
                {
                    _productRepository.Add(picture);
                    _productRepository.UnitOfWork.SaveChanges();
                }, "ExceptionShielding");

                existingKitType.PictureID = picture.PictureID;
            }

            

            _exceptionManager.Process(() =>
            {
                _productRepository.Update(existingKitType);
                _productRepository.UnitOfWork.SaveChanges();
            }, "ExceptionShielding");
        }

        public void DeleteKitType(KitTypePM kitTypePM)
        {
            try
            {
                _exceptionManager.Process(() => _productRepository.Delete<CustomerItem>(ci=>ci.ItemID == kitTypePM.Id) , "ExceptionShielding");
                _exceptionManager.Process(() => _productRepository.Delete<BillOfMaterial>(bom =>bom.ProductAssemblyId  == kitTypePM.Id), "ExceptionShielding");
                _exceptionManager.Process(() => _productRepository.Delete<Item>(task => task.ItemID == kitTypePM.Id), "ExceptionShielding");
                _productRepository.UnitOfWork.SaveChanges();
            }
            catch (UpdateException exception)
            {
                if (exception.InnerException == null) throw;
                SqlException sqlException = exception.InnerException as SqlException;
                if (sqlException == null) throw;

                if (sqlException.Number != 547) throw;
                throw new DomainException("Record cannot be deleted due related records.", 547);
            }

        }

        #endregion

        #region PartType Services

        public PartTypePM GetPartType(int partTypeId)
        {
            Item partType = _exceptionManager.Process(() => _productRepository.GetByKey<Item>(partTypeId), "ExceptionShielding");
            //return PartTypeMapper.ToPresentationModel(partType);
            return GetCustomersForPartType(partType);
        }

        public IQueryable<PartTypePM> GetPartTypes()
        {
            IEnumerable<Item> partTypes = _exceptionManager.Process(() => _productRepository.GetQuery<Item>(i => i.Category.Equals("ProductHierarchyLevelB")), "ExceptionShielding");
            //return PartTypeMapper.ToPresentationModels(partTypes).OrderBy(pt => pt.Name).AsQueryable();
            return partTypes.Select(GetCustomersForPartType).OrderBy(kt => kt.Name).AsQueryable();
        }

        public IQueryable<PartTypePM> GetAllPartTypes(int kitTypeId)
        {
            IEnumerable<Item> partTypes = null;

            if (kitTypeId ==0)
            {
                partTypes = _exceptionManager.Process(() => _productRepository.GetAll<Item>(), "ExceptionShielding");
            }
            else
            {
                List<int> itemIDs = new List<int>();
                List<int> pendingItems = new List<int>();
                itemIDs.Add(kitTypeId);
                pendingItems.Add(kitTypeId);

                while (pendingItems.Count > 0)
                {
                    var itemId = pendingItems.First();
                    var componentIds = _productRepository.GetQuery<BillOfMaterial>(x => x.ProductAssemblyId == itemId).Select(x => x.ComponentId).ToList();

                    foreach (var componentId in componentIds)
                    {
                        itemIDs.Add(componentId);
                        pendingItems.Add(componentId);
                    }
                    pendingItems.Remove(itemId);
                }

                partTypes = _exceptionManager.Process(() => _productRepository.GetQuery<Item>(x => itemIDs.Contains(x.ItemID)), "ExceptionShielding");
            }

            return partTypes.Select(GetCustomersForPartType).OrderBy(kt => kt.Name).AsQueryable();
        }        


        public IEnumerable<PartTypePM> GetPartTypesByKitType(int kitTypeId)
        {
            Item kitType = _exceptionManager.Process(() => _productRepository.GetByKey<Item>(kitTypeId), "ExceptionShielding");

            if (kitType == null || kitType.Category != "ProductHierarchyLevelR") return null;

            //List<PartTypePM> partTypes = PartTypeMapper.ToPresentationModels(kitType.BillOfMaterials1.Select(bom => bom.Item)).ToList();
            //return partTypes.OrderBy(pt => pt.Name);
            //return kitType.BillOfMaterials1.Select(bom => bom.Item).ToList().Select(GetCustomersForPartType).OrderBy(kt => kt.Name).AsQueryable();
            return kitType.BillOfMaterials1.Where (bom=>bom.Item.Category!="RawMaterial").Select(bom => bom.Item).ToList().Select(GetCustomersForPartType).OrderBy(kt => kt.Name).AsQueryable();
            
        }

        [Query(HasSideEffects = true)]
        public IEnumerable<PartTypePM> GetPartTypesByKitTypes(int[] kitTypeIds)
        {
            List<Item> kitTypes = _exceptionManager.Process(() => _productRepository.GetQuery<Item>(item => kitTypeIds.Contains(item.ItemID)).ToList(), "ExceptionShielding");
            //List<PartTypePM> partTypes = PartTypeMapper.ToPresentationModels(kitTypes.SelectMany(kt => kt.BillOfMaterials1).Select(bom => bom.Item).Distinct()).ToList();
            //return partTypes.OrderBy(pt => pt.Name);
            List<Item> partTypes = kitTypes.SelectMany(kt => kt.BillOfMaterials1).Select(bom => bom.Item).Distinct().ToList();
            return partTypes.Select(GetCustomersForPartType).OrderBy(kt => kt.Name).AsQueryable();
        }

        public IEnumerable<PartTypePM> GetPartTypesByPage(int pageNumber, int pageSize)
        {
            IEnumerable<Item> partTypes = _exceptionManager.Process(() => _productRepository.GetByPage<Item>(i => i.Category.Equals("ProductHierarchyLevelB"), i => i.ItemName, pageNumber, pageSize), "ExceptionShielding");
            return partTypes.Select(GetCustomersForPartType).OrderBy(kt => kt.Name).AsQueryable();

            //foreach (var parttype in partTypes)
            //{
            //    var bom = _productRepository.GetQuery<BillOfMaterial>(k => k.ComponentId == parttype.ItemID);

            //    List<string> cusstr = new List<string>();
            //    List<string> assstr = new List<string>();

            //    foreach (var item in bom)
            //    {
            //        var cusitems = _productRepository.GetQuery<CustomerItem>(i => i.ItemID == item.ProductAssemblyId);

            //        foreach (var cusitem in cusitems)
            //        {
            //            var customer = _orderRepository.GetByKey<Customer>(cusitem.CustomerID);
            //            cusstr.Add(customer.CustomerName);
            //        }

            //        var assembly = _productRepository.GetByKey<Item>(item.ProductAssemblyId);
            //        assstr.Add(assembly.ItemName);

            //    }
            //    foreach (var item in cusstr.Distinct().OrderBy(x => x))
            //    {
            //        parttype.String9 += item + "; ";
            //    }
            //    parttype.String9 = string.IsNullOrEmpty(parttype.String9) ? string.Empty : parttype.String9.Remove(parttype.String9.Length - 2);

            //    foreach (var item in assstr.Distinct().OrderBy(x => x))
            //    {
            //        parttype.String8 += item + "; ";
            //    }
            //    parttype.String8 = string.IsNullOrEmpty(parttype.String8) ? string.Empty : parttype.String8.Remove(parttype.String8.Length - 2);

            //}


            //return PartTypeMapper.ToPresentationModels(partTypes).AsQueryable();
        }

        public IEnumerable<PartTypePM> SearchPartTypesByName(int pageNumber, int pageSize, string partTypeName)
        {
            List<int> customerIds = _orderRepository.GetQuery<Customer>(c => c.Category == "Customer" && c.CustomerName.Contains(partTypeName)).Select(x => x.CustomerID).ToList();

          
            IEnumerable<Item> partTypes = _exceptionManager.Process(() => _productRepository.GetByPage<Item>(item => item.Category.Equals("ProductHierarchyLevelB") && (item.ItemName.ToLower().Contains(partTypeName.ToLower()) || item.Description.ToLower().Contains(partTypeName.ToLower()) || item.Group1.ToLower().Contains(partTypeName.ToLower())  || customerIds.Contains(item.Int10 ?? 0)), item => item.ItemName, pageNumber, pageSize).ToList(), "ExceptionShielding");

            //IEnumerable<Item> partTypes = _exceptionManager.Process(() => _productRepository.GetByPage<Item>(item => item.Category.Equals("ProductHierarchyLevelB") && (item.ItemName.ToLower().Contains(partTypeName.ToLower()) || item.Description.ToLower().Contains(partTypeName.ToLower())), item => item.ItemName, pageNumber, pageSize).ToList(), "ExceptionShielding");
            return partTypes.Select(GetCustomersForPartType).AsQueryable();

            //foreach (var parttype in partTypes)
            //{
            //    var bom = _productRepository.GetQuery<BillOfMaterial>(k => k.ComponentId == parttype.ItemID);

            //    List<string> cusstr = new List<string>();
            //    List<string> assstr = new List<string>();

            //    foreach (var item in bom)
            //    {
            //        var cusitems = _productRepository.GetQuery<CustomerItem>(i => i.ItemID == item.ProductAssemblyId);

            //        foreach (var cusitem in cusitems)
            //        {
            //            var customer = _orderRepository.GetByKey<Customer>(cusitem.CustomerID);
            //            cusstr.Add(customer.CustomerName);
            //        }

            //        var assembly = _productRepository.GetByKey<Item>(item.ProductAssemblyId);
            //        assstr.Add(assembly.ItemName);

            //    }
            //    foreach (var item in cusstr.Distinct().OrderBy(x => x))
            //    {
            //        parttype.String9 += item + "; ";
            //    }
            //    parttype.String9 = string.IsNullOrEmpty(parttype.String9) ? string.Empty : parttype.String9.Remove(parttype.String9.Length - 2);

            //    foreach (var item in assstr.Distinct().OrderBy(x => x))
            //    {
            //        parttype.String8 += item + "; ";
            //    }
            //    parttype.String8 = string.IsNullOrEmpty(parttype.String8) ? string.Empty : parttype.String8.Remove(parttype.String8.Length - 2);
            //}


            //return PartTypeMapper.ToPresentationModels(partTypes).AsQueryable();
        }

        // Nitharshan
        public IEnumerable<PartTypePM> SearchPartTypesByName2(string partTypeName, int customerID)
        {
            IEnumerable<Item> partTypes;
            IEnumerable<Item> partTypes1;
            int customerID1 = 0;

            Option option = _exceptionManager.Process(() => _settingRepository.GetQuery<Option>(op => op.OptionName.Trim().Equals("Customer_Stock")).FirstOrDefault(), "ExceptionShielding");
            if (option != null)
            {
                 Customer customer = _exceptionManager.Process(() => _orderRepository.GetQuery<Customer>(c => c.CustomerName.Trim().Equals(option.DefaultSetting)).FirstOrDefault(), "ExceptionShielding");

                 if (customer != null) customerID1 = customer.CustomerID;
            }


            if (String.IsNullOrEmpty(partTypeName))
            {                
                partTypes = _exceptionManager.Process(() => _productRepository.GetQuery<Item>(item => item.Category.Equals("ProductHierarchyLevelB") || item.Category.Equals("ProductHierarchyLevelR")), "ExceptionShielding");
            }
            else
            {
                partTypes = _exceptionManager.Process(() => _productRepository.GetQuery<Item>(item => (item.Category.Equals("ProductHierarchyLevelB") || item.Category.Equals("ProductHierarchyLevelR")) && (item.ItemName.ToLower().Contains(partTypeName.ToLower())||item.Description.ToLower().Contains(partTypeName.ToLower()))), "ExceptionShielding");
            }


            if (customerID != 0)               
            {
                //partTypes1 = partTypes.Where(pt => !(pt.Group3 != null && pt.Group3 == "T") && pt.CustomerItems.Any(ci => ci.CustomerID == customerID || ci.CustomerID == customerID1)).ToList();                                       

                var partTypes2 = partTypes.Where(pt => !(pt.Group3 != null && pt.Group3 == "T") && (pt.Int10 == customerID || pt.Int10 == customerID1 || pt.Int10 == null)).ToList();
                partTypes1 = partTypes2.Where(pt => pt.Int10 != null || (pt.Int10 == null && pt.CustomerItems.Any(ci => ci.CustomerID == customerID || ci.CustomerID == customerID1))).ToList();
                //var partTypes2 = partTypes.Where(pt => pt.Int10 == customerID || pt.Int10 == customerID1 || pt.Int10 == null).ToList();
                //partTypes1 = partTypes2.Where(pt => !(pt.Group3 != null && pt.Group3 == "T") && pt.CustomerItems.Any(ci => ci.CustomerID == customerID || ci.CustomerID == customerID1)).ToList();                                       
            }                
            else
            {
                partTypes1 = partTypes.Where(pt => !(pt.Group3 != null && pt.Group3 == "T")).ToList();
            }
                

            //return PartTypeMapper.ToPresentationModels(partTypes).AsQueryable();
            //return partTypes1.Select(GetCustomersForPartType).OrderBy(kt => kt.Name).AsQueryable();
            //return PartTypeMapper.ToPresentationModels (partTypes1 ).OrderBy(kt => kt.Name).AsQueryable()
                return PartTypeMapper.ToPresentationModels1 (partTypes1 ).AsQueryable();

        }

        [Invoke]
        public int GetPartTypeCount()
        {
            return _exceptionManager.Process(() => _productRepository.GetQuery<Item>(i => i.Category.Equals("ProductHierarchyLevelB")).Count(), "ExceptionShielding");

        }

        public int SearchPartTypeCountByName(string partTypeName)
        {

            List<int> customerIds = _orderRepository.GetQuery<Customer>(c => c.Category == "Customer" && c.CustomerName.Contains(partTypeName)).Select(x => x.CustomerID).ToList();

            return _exceptionManager.Process(() => _productRepository.GetQuery<Item>(i => i.Category.Equals("ProductHierarchyLevelB") && (i.ItemName.ToLower().Contains(partTypeName.ToLower()) || i.Group1.ToLower().Contains(partTypeName.ToLower()) || i.Description.ToLower().Contains(partTypeName.ToLower())  || customerIds.Contains(i.Int10 ?? 0))).Count(), "ExceptionShielding");

            //return _exceptionManager.Process(() => _productRepository.GetQuery<Item>(i => i.Category.Equals("ProductHierarchyLevelB") && (i.ItemName.ToLower().Contains(partTypeName.ToLower()) || i.Description.ToLower().Contains(partTypeName.ToLower()))).Count(), "ExceptionShielding");
        }

        public IEnumerable<string> GetPartFamilies()
        {
            var result = _exceptionManager.Process(() => _productRepository.GetQuery<Item>(item => item.Category.Equals("ProductHierarchyLevelB")).Select(i => i.Group1).Distinct(), "ExceptionShielding");

            //return result.Select(r => r.Group1).Distinct();
            return result;
        }

        public IEnumerable<string> GetAssemblyFamilies()
        {
            var result = _exceptionManager.Process(() => _productRepository.GetQuery<Item>(item => item.Category.Equals("ProductHierarchyLevelR")).Select(i => i.Group1).Distinct(), "ExceptionShielding");

            //return result.Select(r => r.Group1).Distinct();
            return result;
        }

        public IEnumerable<string> GetFGDimensions()
        {
            var result = _exceptionManager.Process(() => _productRepository.GetQuery<Item>(item => item.Category.Equals("ProductHierarchyLevelB")).Select(i => i.String4).Distinct(), "ExceptionShielding");

            //return result.Select(r => r.Group1).Distinct();
            return result;
        }

        

        public void AddPartType(PartTypePM partTypePM)
        {
            Item existingPart = _productRepository.Single<Item>(it => it.ItemName.Equals(partTypePM.Name) && it.Category.Equals("ProductHierarchyLevelB"));
            if (existingPart != null)
                throw new DomainException("Duplicated part name");
            else
            {
                Item parType = PartTypeMapper.FromPresentationModel(partTypePM);
                parType.Category = "ProductHierarchyLevelB";
                parType.CreatedOn = DateTime.Today;

                if (partTypePM.ThumbnailImage != null && partTypePM.ThumbnailImage.Length > 0)
                {
                    Picture picture = new Picture
                    {
                        ThumbNailImage = partTypePM.ThumbnailImage,
                        ThumbnailImageFileName = partTypePM.ThumbnailImageFileName,
                        CreatedOn = DateTime.Today
                    };

                    _exceptionManager.Process(() =>
                    {
                        _productRepository.Add(picture);
                        _productRepository.UnitOfWork.SaveChanges();
                    }, "ExceptionShielding");

                    parType.PictureID = picture.PictureID;
                }

                _exceptionManager.Process(() =>
                {
                    _productRepository.Add(parType);
                    _productRepository.UnitOfWork.SaveChanges();
                }, "ExceptionShielding");

                if (partTypePM.CustomerId != null && partTypePM.CustomerId != 0)
                {
                    CustomerItem customerItem = new CustomerItem() { CustomerID = (int)partTypePM.CustomerId, ItemID = parType.ItemID };

                    _exceptionManager.Process(() =>
                    {
                        _productRepository.Add(customerItem);
                        _productRepository.UnitOfWork.SaveChanges();
                    }, "ExceptionShielding");
                }

                PartTypeMapper.UpdatePresentationModel(partTypePM, parType);


                //// For creating Assembly automatically using part family

                //KitTypePM kitTypePM = new KitTypePM
                //{
                //    Name = partTypePM.PartFamily,
                //    Description = partTypePM.PartFamily,
                //    PartGrpType = true,
                //    Category = "ProductHierarchyLevelR",
                //};

                //AddKitType(kitTypePM);

                //BillOfMaterialPM billOfMaterialPM = new BillOfMaterialPM
                //{
                //    ComponentId = partTypePM.Id,
                //    ProductAssemblyId = kitTypePM.Id,
                //    PerAssemblyQuantity = 1,
                //    BomLevel = 1,
                //    UomCode = "1"
                //};

                //BillOfMaterial billOfMaterial = BillOfMaterialMapper.FromPresentationModel(billOfMaterialPM);
                //billOfMaterial.CreatedOn = DateTime.Today;

                //_exceptionManager.Process(() =>
                //{
                //    _productRepository.Add(billOfMaterial);
                //    _productRepository.UnitOfWork.SaveChanges();
                //}, "ExceptionShielding");

                //BillOfMaterialMapper.UpdatePresentationModel(billOfMaterialPM, billOfMaterial);


                //Debug.WriteLine(partTypePM.Id + "   ---   " + kitTypePM.Id);
            }
        }


        public void UpdatePartType(PartTypePM partTypePM)
        {
            Item partType = PartTypeMapper.FromPresentationModel(partTypePM);
            Item existingPartType = _exceptionManager.Process(() => _productRepository.GetByKey<Item>(partType.ItemID), "ExceptionShielding");

            existingPartType.Category = partType.Category;
            existingPartType.Description = partType.Description;
            existingPartType.ItemName = partType.ItemName;
            existingPartType.UnitPrice = partType.UnitPrice;

          
            //existingPartType.String1 = partType.String1;
            //existingPartType.Int1 = partType.Int1;
            //existingPartType.Int2 = partType.Int2;
            //existingPartType.Int3 = partType.Int3;
            //existingPartType.Int4 = partType.Int4;            
            //existingPartType.Flag1 = partType.Flag1;

            existingPartType.String4 = partType.String4;
            existingPartType.String9 = partType.String9;
            existingPartType.MaxString1 = partType.MaxString1;
            existingPartType.String8 = partType.String8;


            existingPartType.Int6 = partType.Int6;
            existingPartType.Int7 = partType.Int7;
            existingPartType.Int8 = partType.Int8;
            existingPartType.Int9 = partType.Int9;
            existingPartType.Int10 = partType.Int10;

            existingPartType.Group1 = partType.Group1;
            existingPartType.Group2 = partType.Group2;
            existingPartType.Group3 = partType.Group3;

            existingPartType.Float1 = partType.Float1;
            existingPartType.Group5 = partType.Group5;

            


            if (existingPartType.PictureID != null && partTypePM.ThumbnailImage != null && partTypePM.ThumbnailImage.Length > 0)
            {
                Picture existingPicture = _exceptionManager.Process(() => _productRepository.GetByKey<Picture>(existingPartType.PictureID), "ExceptionShielding");
                existingPicture.ThumbNailImage = partTypePM.ThumbnailImage;
                existingPicture.ThumbnailImageFileName = partTypePM.ThumbnailImageFileName;

                _exceptionManager.Process(() =>
                {
                    _productRepository.Update(existingPicture);
                    _productRepository.UnitOfWork.SaveChanges();
                }, "ExceptionShielding");
            }
            else if (existingPartType.PictureID == null && partTypePM.ThumbnailImage != null && partTypePM.ThumbnailImage.Length > 0)
            {
                Picture picture = new Picture
                {
                    ThumbNailImage = partTypePM.ThumbnailImage,
                    ThumbnailImageFileName = partTypePM.ThumbnailImageFileName,
                    CreatedOn = DateTime.Today
                };

                _exceptionManager.Process(() =>
                {
                    _productRepository.Add(picture);
                    _productRepository.UnitOfWork.SaveChanges();
                }, "ExceptionShielding");

                existingPartType.PictureID = picture.PictureID;
            }

            _exceptionManager.Process(() =>
            {
                _productRepository.Update(existingPartType);
                _productRepository.UnitOfWork.SaveChanges();
            }, "ExceptionShielding");

            if (partTypePM.CustomerId != null && partTypePM.CustomerId != 0)
            {

                CustomerItem customerItem = _exceptionManager.Process(() => _productRepository.GetQuery<CustomerItem>(ci => ci.CustomerID == partTypePM.CustomerId && ci.ItemID == partTypePM.Id).FirstOrDefault(), "ExceptionShielding"); ;

                if (customerItem == null)
                {
                    customerItem = new CustomerItem() { CustomerID = (int)partTypePM.CustomerId, ItemID = partTypePM.Id };

                    _exceptionManager.Process(() =>
                    {
                        _productRepository.Delete<CustomerItem>(ci => ci.ItemID == existingPartType.ItemID);
                        _productRepository.Add(customerItem);
                        _productRepository.UnitOfWork.SaveChanges();
                    }, "ExceptionShielding");
                }


                partTypePM.Customers = _exceptionManager.Process(() => _orderRepository.GetByKey<Customer>(customerItem.CustomerID).CustomerName, "ExceptionShielding");
            }
                
        }

        public void DeletePartType(PartTypePM partTypePM)
        {
            try
            {
                _exceptionManager.Process(() => _productRepository.Delete<CustomerItem>(ci => ci.ItemID == partTypePM.Id), "ExceptionShielding");                 
                _exceptionManager.Process(() => _productRepository.Delete<BillOfMaterial>(bom => bom.ProductAssemblyId == partTypePM.Id), "ExceptionShielding");
                _exceptionManager.Process(() => _productRepository.Delete<Item>(task => task.ItemID == partTypePM.Id), "ExceptionShielding");
                _productRepository.UnitOfWork.SaveChanges();
            }
            catch (UpdateException exception)
            {
                if (exception.InnerException == null) throw;
                SqlException sqlException = exception.InnerException as SqlException;
                if (sqlException == null) throw;

                if (sqlException.Number != 547) throw;
                throw new DomainException("Record cannot be deleted due related records.", 547);
            }

        }

        [Invoke]
        public void UpdateProductRawMaterial(int partId, int[] rawMatIds, decimal[] ratios, int[] rawMatUoMTypes, string[] remarks)
        {

            Dictionary<int, decimal> ratioDictionary = new Dictionary<int, decimal>();
            Dictionary<int, int> uoMTypeDictionary = new Dictionary<int, int>();
           

            for (int i = 0; i < rawMatIds.Count(); i++)
                ratioDictionary.Add(rawMatIds[i], ratios[i]);

            for (int i = 0; i < rawMatIds.Count(); i++)
                uoMTypeDictionary.Add(rawMatIds[i], rawMatUoMTypes[i]);

            var existingRawMats = _productRepository.GetQuery<BillOfMaterial>(bom => bom.ProductAssemblyId == partId && bom.Item.Category.Equals("RawMaterial")).Select (x=>x.ComponentId ).ToList();
            
            //var result = _exceptionManager.Process(() => _productRepository.GetQuery<BillOfMaterial>(bom => bom.ProductAssemblyId == partId && bom.Item.Category.Equals ("RawMaterial") ), "ExceptionShielding");

            //var existingRawMats = result.Select(x => x.ComponentId);

            var removedRawMats = existingRawMats.Except(rawMatIds);

            var newRawMats = rawMatIds.Except(existingRawMats);

            foreach (var item in removedRawMats)
            {
                _productRepository.Delete<BillOfMaterial>(bom => bom.ProductAssemblyId == partId && bom.ComponentId == item);
            }

           
            foreach (var item in newRawMats)
            {
                _productRepository.Add<BillOfMaterial>(new BillOfMaterial
                {
                    ProductAssemblyId = partId,
                    ComponentId = item,
                    PerAssemblyQty = (double)ratioDictionary[item],
                    //UOMCode ="1",
                    UOMCode = Array.IndexOf(rawMatIds, item).ToString("000"),                    
                    BOMLevel = (short)uoMTypeDictionary[item],
                    ModifiedBy= remarks[Array.IndexOf(rawMatIds, item)],
                });
                Debug.WriteLine("Material ##### " + item);
            }

            foreach (var item in existingRawMats.Except(removedRawMats))
            {
                var a = _productRepository.GetQuery<BillOfMaterial>(bom => bom.ProductAssemblyId == partId && bom.ComponentId == item).FirstOrDefault();
                if (a!=null)
                {
                    a.PerAssemblyQty = (double)ratioDictionary[item];
                    a.BOMLevel = (short)uoMTypeDictionary[item];
                    a.UOMCode = Array.IndexOf(rawMatIds, item).ToString("000");
                    a.ModifiedBy = remarks[Array.IndexOf(rawMatIds, item)];
                    _productRepository.Update<BillOfMaterial>(a);
                }
                
            }

            _exceptionManager.Process(() =>
            {
                _productRepository.UnitOfWork.SaveChanges();
            }, "ExceptionShielding");
        }

        #endregion

        #region Kit Services

        public KitPM GetKit(int kitId)
        {
            Item kit = _exceptionManager.Process(() => _productRepository.GetByKey<Item>(kitId), "ExceptionShielding");
            KitPM kitPm = KitMapper.ToPresentationModel(kit);

            kitPm.CustomerCode = _exceptionManager.Process(() => _orderRepository.GetByKey<Customer>(kitPm.CustomerId).CustomerName, "ExceptionShielding");


            //if(kit.CustomerItems != null && kit.CustomerItems.Count > 0)
            //{
            //    kitPm.CustomerId = kit.CustomerItems.ElementAt(0).CustomerID;
            //    kitPm.CustomerCode = _exceptionManager.Process(() => _orderRepository.GetByKey<Customer>(kit.CustomerItems.ElementAt(0).CustomerID).CustomerName, "ExceptionShielding");
            //}

            return kitPm;
        }

        public IEnumerable<KitPM> GetKits()
        {
            List<Item> kits = _exceptionManager.Process(() => _productRepository.GetQuery<Item>(i => i.Category.Equals("ProductHierarchyLevelA") && (i.Flag2 == true || i.Flag2 == null)).ToList(), "ExceptionShielding");
            List<KitPM> kitPms = KitMapper.ToPresentationModels(kits).ToList();

            foreach (KitPM kitPM in kitPms)
            {
                if (kitPM.IsActive == false)
                {
                    // For debugging purposes
                }
                kitPM.CustomerCode = _exceptionManager.Process(() => _orderRepository.GetByKey<Customer>(kitPM.CustomerId).CustomerName, "ExceptionShielding");
            }

            //foreach (Item kit in kits.Where(kit => kit.CustomerItems != null && kit.CustomerItems.Count > 0))
            //{
            //    KitPM kitPM = kitPms.Single(kitPm => kitPm.Id == kit.ItemID);

            //    kitPM.CustomerId = kit.CustomerItems.ElementAt(0).CustomerID;
            //    kitPM.CustomerCode = _exceptionManager.Process(() => _orderRepository.GetByKey<Customer>(kit.CustomerItems.ElementAt(0).CustomerID).CustomerName, "ExceptionShielding");
            //}

            return kitPms.OrderBy(k => k.Name);
        }

        public IEnumerable<KitPM> GetKitsByKitType(int kitTypeId)
        {
            List<Item> kits = _exceptionManager.Process(() => _productRepository.GetQuery<Item>(i => i.Category.Equals("ProductHierarchyLevelA") && i.ParentItemID == kitTypeId).ToList(), "ExceptionShielding");
            List<KitPM> kitPms = KitMapper.ToPresentationModels(kits).ToList();

            foreach (KitPM kitPM in kitPms)
            {
                kitPM.CustomerCode = _exceptionManager.Process(() => _orderRepository.GetByKey<Customer>(kitPM.CustomerId).CustomerName, "ExceptionShielding");
            }

            //foreach (Item kit in kits.Where(kit => kit.CustomerItems != null && kit.CustomerItems.Count > 0))
            //{
            //    KitPM kitPM = kitPms.Single(kitPm => kitPm.Id == kit.ItemID);
            //    kitPM.CustomerId = kit.CustomerItems.ElementAt(0).CustomerID;
            //    kitPM.CustomerCode = _exceptionManager.Process(() => _orderRepository.GetByKey<Customer>(kit.CustomerItems.ElementAt(0).CustomerID).CustomerName, "ExceptionShielding");
            //}

            return kitPms.OrderBy(k => k.Name);
        }

        public IEnumerable<KitPM> GetKitsByPage(int pageNumber, int pageSize)
        {
            List<Item> kits = _exceptionManager.Process(() => _productRepository.GetByPage<Item>(i => i.Category.Equals("ProductHierarchyLevelA") && (i.Flag2 == true || i.Flag2 == null), i => i.ItemName, pageNumber, pageSize).ToList(), "ExceptionShielding");
            List<KitPM> kitPms = KitMapper.ToPresentationModels(kits).ToList();

            foreach (KitPM kitPM in kitPms)
            {
                if (kitPM.IsActive == false)
                {
                    // For debugging purposes
                }
                kitPM.CustomerCode = _exceptionManager.Process(() => _orderRepository.GetByKey<Customer>(kitPM.CustomerId).CustomerName, "ExceptionShielding");
            }

            //foreach (Item kit in kits.Where(kit => kit.CustomerItems != null && kit.CustomerItems.Count > 0))
            //{
            //    KitPM kitPM = kitPms.Single(kitPm => kitPm.Id == kit.ItemID);
            //    kitPM.CustomerId = kit.CustomerItems.ElementAt(0).CustomerID;
            //    kitPM.CustomerCode = _exceptionManager.Process(() => _orderRepository.GetByKey<Customer>(kit.CustomerItems.ElementAt(0).CustomerID).CustomerName, "ExceptionShielding");
            //}

            return kitPms;
        }

        public IEnumerable<KitPM> SearchKitsByName(int pageNumber, int pageSize, string kitName)
        {
            List<Item> kits = _exceptionManager.Process(() => _productRepository.GetByPage<Item>(item => item.Category.Equals("ProductHierarchyLevelA") && (item.Flag2 == true || item.Flag2 == null) && item.ItemName.ToLower().Contains(kitName.ToLower()), item => item.ItemName, pageNumber, pageSize).ToList(), "ExceptionShielding");
            List<KitPM> kitPms = KitMapper.ToPresentationModels(kits).ToList();

            foreach (KitPM kitPM in kitPms)
            {
                if (kitPM.IsActive == false)
                {
                    // For debugging purposes
                }
                kitPM.CustomerCode = _exceptionManager.Process(() => _orderRepository.GetByKey<Customer>(kitPM.CustomerId).CustomerName, "ExceptionShielding");
            }

            //foreach (Item kit in kits.Where(kit => kit.CustomerItems != null && kit.CustomerItems.Count > 0))
            //{
            //    KitPM kitPM = kitPms.Single(kitPm => kitPm.Id == kit.ItemID);
            //    kitPM.CustomerId = kit.CustomerItems.ElementAt(0).CustomerID;
            //    kitPM.CustomerCode = _exceptionManager.Process(() => _orderRepository.GetByKey<Customer>(kit.CustomerItems.ElementAt(0).CustomerID).CustomerName, "ExceptionShielding");
            //}

            return kitPms;
        }

        public int GetKitCount()
        {
            return _exceptionManager.Process(() => _productRepository.GetQuery<Item>(i => i.Category.Equals("ProductHierarchyLevelA")).Count(), "ExceptionShielding");
        }

        public int SearchKitCountByName(string kitName)
        {
            return _exceptionManager.Process(() => _productRepository.GetQuery<Item>(i => i.Category.Equals("ProductHierarchyLevelA") && i.ItemName.ToLower().Contains(kitName.ToLower())).Count(), "ExceptionShielding");
        }

        public void AddKit(KitPM kitPM)
        {
            Item kit = KitMapper.FromPresentationModel(kitPM);
            kit.Category = "ProductHierarchyLevelA";
            kit.CreatedOn = DateTime.Today;

            _exceptionManager.Process(() =>
            {
                _productRepository.Add(kit);
                _productRepository.UnitOfWork.SaveChanges();
            }, "ExceptionShielding");

            KitMapper.UpdatePresentationModel(kitPM, kit);

            /*Customer ID is stored in int1, no need create extra record in customerItem table*/
            //CustomerItem customerItem = new CustomerItem
            //{
            //    CustomerID = kitPM.CustomerId,
            //    ItemID = kitPM.Id
            //};

            //_exceptionManager.Process(() =>
            //{
            //    _productRepository.Add(customerItem);
            //    _productRepository.UnitOfWork.SaveChanges();
            //}, "ExceptionShielding");
        }

        public void UpdateKit(KitPM kitPM)
        {
            Item kit = KitMapper.FromPresentationModel(kitPM);
            Item existingKit = _exceptionManager.Process(() => _productRepository.GetByKey<Item>(kit.ItemID), "ExceptionShielding");

            existingKit.Category = kit.Category;
            existingKit.Description = kit.Description;
            existingKit.ItemName = kit.ItemName;
            existingKit.String1 = kit.String1;
            existingKit.Flag2 = kit.Flag2;

            _exceptionManager.Process(() =>
            {
                _productRepository.Update(existingKit);
                _productRepository.UnitOfWork.SaveChanges();
            }, "ExceptionShielding");
        }

        ///*
        [Update(UsingCustomMethod = true)]
        public void UpdateKitToInactivate(KitPM kitPM)
        {
            Item kit = KitMapper.FromPresentationModel(kitPM);
            //Item existingKit = _exceptionManager.Process(() => _productRepository.GetByKey<Item>(kit.ItemID), "ExceptionShielding");

            //existingKit.Category = kit.Category;
            //existingKit.Description = kit.Description;
            //existingKit.ItemName = kit.ItemName;
            //existingKit.String1 = kit.String1;
            //existingKit.Flag2 = false;

            _exceptionManager.Process(() =>
            {
                _productRepository.Update(kit);
                _productRepository.UnitOfWork.SaveChanges();
            }, "ExceptionShielding");
        }
        // */

        public void DeleteKit(KitPM kitPM)
        {
            try
            {
                _productRepository.UnitOfWork.BeginTransaction();

                _exceptionManager.Process(() => _productRepository.Delete<BillOfMaterial>(bom => bom.ProductAssemblyId == kitPM.Id), "ExceptionShielding");
                _exceptionManager.Process(() => _productRepository.Delete<CustomerItem>(ci => ci.ItemID == kitPM.Id), "ExceptionShielding");
                _exceptionManager.Process(() => _productRepository.Delete<Item>(item => item.ItemID == kitPM.Id), "ExceptionShielding");

                //_productRepository.UnitOfWork.SaveChanges();
                _productRepository.UnitOfWork.CommitTransaction();
            }
            catch (UpdateException exception)
            {
                if (exception.InnerException == null) throw;
                SqlException sqlException = exception.InnerException as SqlException;
                if (sqlException == null) throw;

                if (sqlException.Number != 547) throw;
                throw new DomainException("Record cannot be deleted due related records.", 547);
            }
        }

        // Nitharshan
        public bool IsWorkOrderExistOnKitId(int KitId)
        {
            WorkOrderDetail workorderdetail = _exceptionManager.Process(() => _orderRepository.GetAll<WorkOrderDetail>().Where(wod => wod.ItemID == KitId).FirstOrDefault(), "ExceptionShielding");

            if (workorderdetail != null)
            {
                WorkOrder workorder = _exceptionManager.Process(() => _orderRepository.GetAll<WorkOrder>().Where(wo => workorderdetail.WorkOrderID == wo.WorkOrderID && wo.Status > 100).FirstOrDefault(), "ExceptionShielding");
                return (workorder != null);
            }

            return false;
        }


        #endregion

        #region Item Services

        public ItemPM GetItem(int itemId)
        {
            Item item = _exceptionManager.Process(() => _productRepository.GetByKey<Item>(itemId), "ExceptionShielding");
            ItemPM itemPM = ItemMapper.ToPresentationModel(item);

            if (item.BillOfMaterials != null && item.BillOfMaterials.Count > 0)
            {
                itemPM.KitId = item.BillOfMaterials.ElementAt(0).ProductAssemblyId;
                itemPM.PerAssemblyQuantity = item.BillOfMaterials.ElementAt(0).PerAssemblyQty;

                Item kit = _exceptionManager.Process(() => _productRepository.GetByKey<Item>(item.BillOfMaterials.ElementAt(0).ProductAssemblyId), "ExceptionShielding");
                itemPM.KitTypeId = kit.ParentItemID ?? 0;
                itemPM.KitTypeName = kit.Item2.ItemName;
                itemPM.KitName = kit.ItemName;
                itemPM.CustomerId = kit.Int10 ?? 0;
                itemPM.CustomerCode = _exceptionManager.Process(() => _orderRepository.GetByKey<Customer>(itemPM.CustomerId).CustomerName, "ExceptionShielding");


                //if (kit.CustomerItems != null && kit.CustomerItems.Count > 0)
                //{
                //    itemPM.CustomerId = kit.CustomerItems.ElementAt(0).CustomerID;
                //    itemPM.CustomerCode = _exceptionManager.Process(() => _orderRepository.GetByKey<Customer>(kit.CustomerItems.ElementAt(0).CustomerID).CustomerName, "ExceptionShielding");
                //}
            }

            return itemPM;
        }

        public IEnumerable<ItemPM> GetItems()
        {
            List<Item> items = _exceptionManager.Process(() => _productRepository.GetQuery<Item>(i => i.Category.Equals("ProductHierarchyLevelC")).ToList(), "ExceptionShielding");
            List<ItemPM> itemPms = ItemMapper.ToPresentationModels(items).ToList();

            foreach (Item item in items.Where(item => item.BillOfMaterials != null && item.BillOfMaterials.Count > 0))
            {
                ItemPM itemPM = itemPms.Single(itemPm => itemPm.Id == item.ItemID);
                itemPM.KitId = item.BillOfMaterials.ElementAt(0).ProductAssemblyId;
                itemPM.PerAssemblyQuantity = item.BillOfMaterials.ElementAt(0).PerAssemblyQty;

                Item kit = _exceptionManager.Process(() => _productRepository.GetByKey<Item>(item.BillOfMaterials.ElementAt(0).ProductAssemblyId), "ExceptionShielding");
                itemPM.KitTypeId = kit.ParentItemID ?? 0;
                itemPM.KitTypeName = kit.Item2.ItemName;
                itemPM.KitName = kit.ItemName;
                itemPM.CustomerId = kit.Int10 ?? 0;
                itemPM.CustomerCode = _exceptionManager.Process(() => _orderRepository.GetByKey<Customer>(itemPM.CustomerId).CustomerName, "ExceptionShielding");



                //if (kit.CustomerItems != null && kit.CustomerItems.Count > 0)
                //{
                //    itemPM.CustomerId = kit.CustomerItems.ElementAt(0).CustomerID;
                //    itemPM.CustomerCode = _exceptionManager.Process(() => _orderRepository.GetByKey<Customer>(kit.CustomerItems.ElementAt(0).CustomerID).CustomerName, "ExceptionShielding");
                //}
            }

            return itemPms.OrderBy(i => i.Name);
        }

        public IEnumerable<ItemPM> GetItemsByPartType(int partTypeId)
        {
            List<Item> items = _exceptionManager.Process(() => _productRepository.GetQuery<Item>(i => i.Category.Equals("ProductHierarchyLevelC") && i.ParentItemID == partTypeId).ToList(), "ExceptionShielding");
            List<ItemPM> itemPms = ItemMapper.ToPresentationModels(items).ToList();

            foreach (Item item in items.Where(item => item.BillOfMaterials != null && item.BillOfMaterials.Count > 0))
            {
                ItemPM itemPM = itemPms.Single(itemPm => itemPm.Id == item.ItemID);
                itemPM.KitId = item.BillOfMaterials.ElementAt(0).ProductAssemblyId;
                itemPM.PerAssemblyQuantity = item.BillOfMaterials.ElementAt(0).PerAssemblyQty;

                Item kit = _exceptionManager.Process(() => _productRepository.GetByKey<Item>(item.BillOfMaterials.ElementAt(0).ProductAssemblyId), "ExceptionShielding");
                itemPM.KitTypeId = kit.ParentItemID ?? 0;
                itemPM.KitTypeName = kit.Item2.ItemName;
                itemPM.KitName = kit.ItemName;
                itemPM.CustomerId = kit.Int10 ?? 0;
                itemPM.CustomerCode = _exceptionManager.Process(() => _orderRepository.GetByKey<Customer>(itemPM.CustomerId).CustomerName, "ExceptionShielding");

                //if (kit.CustomerItems != null && kit.CustomerItems.Count > 0)
                //{
                //    itemPM.CustomerId = kit.CustomerItems.ElementAt(0).CustomerID;
                //    itemPM.CustomerCode = _exceptionManager.Process(() => _orderRepository.GetByKey<Customer>(kit.CustomerItems.ElementAt(0).CustomerID).CustomerName, "ExceptionShielding");
                //}
            }

            return itemPms.OrderBy(i => i.Name);
        }

        public IEnumerable<ItemPM> GetItemsByKit(int kitId)
        {
            Item kit = _exceptionManager.Process(() => _productRepository.GetByKey<Item>(kitId), "ExceptionShielding");
            List<Item> items = kit.BillOfMaterials1.Select(bom => bom.Item).ToList();
            List<ItemPM> itemPms = ItemMapper.ToPresentationModels(items).ToList();

            foreach (Item item in items.Where(item => item.BillOfMaterials != null && item.BillOfMaterials.Count > 0))
            {
                ItemPM itemPM = itemPms.Single(itemPm => itemPm.Id == item.ItemID);
                itemPM.KitId = item.BillOfMaterials.ElementAt(0).ProductAssemblyId;
                itemPM.PerAssemblyQuantity = item.BillOfMaterials.ElementAt(0).PerAssemblyQty;
                itemPM.KitTypeId = kit.ParentItemID ?? 0;
                itemPM.KitTypeName = kit.Item2.ItemName;
                itemPM.KitName = kit.ItemName;
                itemPM.CustomerId = kit.Int10 ?? 0;
                itemPM.CustomerCode = _exceptionManager.Process(() => _orderRepository.GetByKey<Customer>(itemPM.CustomerId).CustomerName, "ExceptionShielding");

                //if (kit.CustomerItems != null && kit.CustomerItems.Count > 0)
                //{
                //    itemPM.CustomerId = kit.CustomerItems.ElementAt(0).CustomerID;
                //    itemPM.CustomerCode = _exceptionManager.Process(() => _orderRepository.GetByKey<Customer>(kit.CustomerItems.ElementAt(0).CustomerID).CustomerName, "ExceptionShielding");
                //}
            }

            return itemPms.OrderBy(i => i.Name);
        }

        public IEnumerable<ItemPM> GetItemsByPage(int pageNumber, int pageSize)
        {
            List<Item> items = _exceptionManager.Process(() => _productRepository.GetByPage<Item>(i => i.Category.Equals("ProductHierarchyLevelC"), i => i.ItemName, pageNumber, pageSize).ToList(), "ExceptionShielding");
            List<ItemPM> itemPms = ItemMapper.ToPresentationModels(items).ToList();

            foreach (Item item in items.Where(item => item.BillOfMaterials != null && item.BillOfMaterials.Count > 0))
            {
                ItemPM itemPM = itemPms.Single(itemPm => itemPm.Id == item.ItemID);
                itemPM.KitId = item.BillOfMaterials.ElementAt(0).ProductAssemblyId;
                itemPM.PerAssemblyQuantity = item.BillOfMaterials.ElementAt(0).PerAssemblyQty;

                Item kit = _exceptionManager.Process(() => _productRepository.GetByKey<Item>(item.BillOfMaterials.ElementAt(0).ProductAssemblyId), "ExceptionShielding");
                itemPM.KitTypeId = kit.ParentItemID ?? 0;
                if (kit.Item2 != null)
                    itemPM.KitTypeName = kit.Item2.ItemName;
                else
                    itemPM.KitTypeName = "";
                itemPM.KitName = kit.ItemName;
                itemPM.CustomerId = kit.Int10 ?? 0;
                itemPM.CustomerCode = _exceptionManager.Process(() => _orderRepository.GetByKey<Customer>(itemPM.CustomerId).CustomerName, "ExceptionShielding");

                //if (kit.CustomerItems != null && kit.CustomerItems.Count > 0)
                //{
                //    itemPM.CustomerId = kit.CustomerItems.ElementAt(0).CustomerID;
                //    itemPM.CustomerCode = _exceptionManager.Process(() => _orderRepository.GetByKey<Customer>(kit.CustomerItems.ElementAt(0).CustomerID).CustomerName, "ExceptionShielding");
                //}
            }

            return itemPms;
        }

        public IEnumerable<ItemPM> SearchItemsByName(int pageNumber, int pageSize, string itemName)
        {
            //List<Item> items = _exceptionManager.Process(() => _productRepository.GetByPage<Item>(item => item.Category.Equals("ProductHierarchyLevelC") && item.ItemName.ToLower().Contains(itemName.ToLower()), item => item.ItemName, pageNumber, pageSize).ToList(), "ExceptionShielding");
            List<Item> items = _exceptionManager.Process(() => _productRepository.GetByPage<Item>(item => item.Category.Equals("ProductHierarchyLevelC") && item.String2.ToLower().Contains(itemName.ToLower()), item => item.ItemName, pageNumber, pageSize).ToList(), "ExceptionShielding");
            List<ItemPM> itemPms = ItemMapper.ToPresentationModels(items).ToList();

            foreach (Item item in items.Where(item => item.BillOfMaterials != null && item.BillOfMaterials.Count > 0))
            {
                ItemPM itemPM = itemPms.Single(itemPm => itemPm.Id == item.ItemID);
                itemPM.KitId = item.BillOfMaterials.ElementAt(0).ProductAssemblyId;
                itemPM.PerAssemblyQuantity = item.BillOfMaterials.ElementAt(0).PerAssemblyQty;

                Item kit = _exceptionManager.Process(() => _productRepository.GetByKey<Item>(item.BillOfMaterials.ElementAt(0).ProductAssemblyId), "ExceptionShielding");
                itemPM.KitTypeId = kit.ParentItemID ?? 0;
                itemPM.KitTypeName = kit.Item2.ItemName;
                itemPM.KitName = kit.ItemName;
                itemPM.CustomerId = kit.Int10 ?? 0;
                itemPM.CustomerCode = _exceptionManager.Process(() => _orderRepository.GetByKey<Customer>(itemPM.CustomerId).CustomerName, "ExceptionShielding");

                //if (kit.CustomerItems != null && kit.CustomerItems.Count > 0)
                //{
                //    itemPM.CustomerId = kit.CustomerItems.ElementAt(0).CustomerID;
                //    itemPM.CustomerCode = _exceptionManager.Process(() => _orderRepository.GetByKey<Customer>(kit.CustomerItems.ElementAt(0).CustomerID).CustomerName, "ExceptionShielding");
                //}
            }

            return itemPms;
        }

        public IEnumerable<string> GetPartIdsByPartType(int partTypeId)
        {
            IEnumerable<Item> items = _exceptionManager.Process(() => _productRepository.GetQuery<Item>(item => item.Category.Trim().Equals("ProductHierarchyLevelC") && item.ParentItemID == partTypeId), "ExceptionShielding");
            return items.Select(item => item.Group1).Distinct().AsQueryable();
        }

        public int GetItemCount()
        {
            return _exceptionManager.Process(() => _productRepository.GetQuery<Item>(i => i.Category.Equals("ProductHierarchyLevelC")).Count(), "ExceptionShielding");
        }

        public int SearchItemCountByName(string itemName)
        {
            //return _exceptionManager.Process(() => _productRepository.GetQuery<Item>(i => i.Category.Equals("ProductHierarchyLevelC") && i.ItemName.ToLower().Contains(itemName.ToLower())).Count(), "ExceptionShielding");

            return _exceptionManager.Process(() => _productRepository.GetQuery<Item>(i => i.Category.Equals("ProductHierarchyLevelC") && i.String2.ToLower().Contains(itemName.ToLower())).Count(), "ExceptionShielding");
        }

        // Original AddItem Method
        public void AddItem(ItemPM itemPM)
        {
            Item item = ItemMapper.FromPresentationModel(itemPM);
            item.ItemName = !string.IsNullOrEmpty(itemPM.ExternalSerial) ? itemPM.PartId + "||" + itemPM.ExternalSerial : itemPM.PartId + "||" + itemPM.InternalSerial;
            item.Category = "ProductHierarchyLevelC";
            item.CreatedOn = DateTime.Today;

            _exceptionManager.Process(() =>
            {
                _productRepository.Add(item);
                _productRepository.UnitOfWork.SaveChanges();
            }, "ExceptionShielding");

            ItemMapper.UpdatePresentationModel(itemPM, item);

            BillOfMaterial billOfMaterial = new BillOfMaterial
            {
                ProductAssemblyId = itemPM.KitId,
                ComponentId = itemPM.Id,
                PerAssemblyQty = itemPM.PerAssemblyQuantity ?? 1,
                UOMCode = "1"
            };

            _exceptionManager.Process(() =>
            {
                _productRepository.Add(billOfMaterial);
                _productRepository.UnitOfWork.SaveChanges();
            }, "ExceptionShielding");
        }


        public void UpdateItem(ItemPM itemPM)
        {
            Item item = ItemMapper.FromPresentationModel(itemPM);
            Item existingItem = _exceptionManager.Process(() => _productRepository.GetByKey<Item>(item.ItemID), "ExceptionShielding");

            existingItem.Category = item.Category;
            existingItem.Description = item.Description;
            existingItem.Int1 = item.Int1;
            existingItem.Int2 = item.Int2;
            existingItem.Int3 = item.Int3;
            existingItem.Int4 = item.Int4;
            existingItem.ItemName = item.ItemName;
            existingItem.String2 = item.String2;
            existingItem.String3 = item.String3;
            existingItem.Group1 = item.Group1;
            existingItem.Flag1 = item.Flag1;
            existingItem.ParentItemID = item.ParentItemID;

            _exceptionManager.Process(() =>
            {
                _productRepository.Update(existingItem);
                _productRepository.UnitOfWork.SaveChanges();
            }, "ExceptionShielding");

            BillOfMaterial existingBillOfMaterial = _exceptionManager.Process(() => _productRepository.Single<BillOfMaterial>(bom => bom.ComponentId == itemPM.Id && bom.ProductAssemblyId == itemPM.KitId), "ExceptionShielding");

            existingBillOfMaterial.ProductAssemblyId = itemPM.KitId;
            existingBillOfMaterial.PerAssemblyQty = itemPM.PerAssemblyQuantity ?? 1;

            _exceptionManager.Process(() =>
            {
                _productRepository.Update(existingBillOfMaterial);
                _productRepository.UnitOfWork.SaveChanges();
            }, "ExceptionShielding");
        }

        public void DeleteItem(ItemPM itemPM)
        {
            try
            {
                _exceptionManager.Process(() => _productRepository.Delete<Item>(task => task.ItemID == itemPM.Id), "ExceptionShielding");
                _productRepository.UnitOfWork.SaveChanges();
            }
            catch (UpdateException exception)
            {
                if (exception.InnerException == null) throw;
                SqlException sqlException = exception.InnerException as SqlException;
                if (sqlException == null) throw;

                if (sqlException.Number != 547) throw;
                throw new DomainException("Record cannot be deleted due to related records.", 547);
            }
        }

        #endregion

        #region Raw Material

        public RawMaterialPM GetRawMaterial(int rawMaterialId)
        {
            Item kitType = _exceptionManager.Process(() => _productRepository.GetByKey<Item>(rawMaterialId), "ExceptionShielding");
            return RawMaterialMapper.ToPresentationModel(kitType);
        }

        public IEnumerable<string> GetGrades()
        {
            //var result = _exceptionManager.Process(() => _productRepository.GetQuery<Item>(item => item.Category.Equals("RawMaterial")), "ExceptionShielding");
            //return result.Select(r => r.String8).Distinct();

            //return _exceptionManager.Process(() => _productRepository.GetQuery<Item>(item => item.Category.Equals("RawMaterial")).Select(i => i.String8).Distinct(), "ExceptionShielding");
            return _exceptionManager.Process(() => _productRepository.GetQuery<Item>(item => item.Category.Equals("RawMaterial")).Where(a => !a.String8.Equals(string.Empty)).Select(i => i.String8).Distinct(), "ExceptionShielding");
        }

        public IEnumerable<string> GetRawMaterialTypes()
        {           
            return _exceptionManager.Process(() => _productRepository.GetQuery<Item>(item => item.Category.Equals("RawMaterial")).Where(a => !a.String9.Equals(string.Empty)).Select(i => i.String9).Distinct(), "ExceptionShielding");
        }

        public IEnumerable<string> GetUoMs()
        {
            return _exceptionManager.Process(() => _productRepository.GetQuery<Item>(item => item.Category.Equals("RawMaterial")).Where(a => !a.Group1.Equals(string.Empty)).Select(i => i.Group1).Distinct(), "ExceptionShielding");
        }


        

        public IEnumerable<RawMaterialPM> GetRawMaterialByPage(int pageNumber, int pageSize)
        {
            var timer = System.Diagnostics.Stopwatch.StartNew();

            IEnumerable<Item> rm = _exceptionManager.Process(() => _productRepository.GetByPage<Item>(i => i.Category.Equals("RawMaterial"), i => i.ItemName, pageNumber, pageSize), "ExceptionShielding");
            //Debug.WriteLine("GetRawMaterialByPage => PageNumber: " + pageNumber);
            //Debug.WriteLine("GetRawMaterialByPage => PageSize: " + pageSize);

            var returnable = RawMaterialMapper.ToPresentationModels(rm).ToList();

            foreach (var item in returnable)
            {
                var rawMaterial = rm.FirstOrDefault(x => x.ItemID == item.Id);
                item.NoofParts = rawMaterial.BillOfMaterials.Count();
                GetRawMaterialBalanceQuantity(item);
            }
 
            Debug.WriteLine("ItemDomainService.GetRawMaterialByPage : " + timer.ElapsedMilliseconds + " ms");
            timer.Reset();

            //Debug.WriteLine("ItemDomainService.GetRawMaterialByPage => RawMaterial Count : " + returnable.Count<RawMaterialPM>());
            return returnable;
        }

        public int GetRawMaterialCount()
        {
            var returnable = _exceptionManager.Process(() => _productRepository.Count<Item>(i => i.Category.Equals("RawMaterial")), "ExceptionShielding");
            //Debug.WriteLine("ItemDomainService.GetRawMaterialCount => RawMaterial Count : " + returnable.ToString());
            return returnable;
        }

        public int SearchRawMaterialCountByName(string itemName)
        {
            //return _exceptionManager.Process(() => _productRepository.Count<Item>(i => i.Category.Equals("RawMaterial") && i.ItemName.ToLower().Contains(itemName.ToLower())), "ExceptionShielding");
            //return _exceptionManager.Process(() => _productRepository.Count<Item>(i => i.Category.Equals("RawMaterial") && (i.ItemName.ToLower().Contains(itemName.ToLower())||i.String8.ToLower().Contains(itemName.ToLower()))), "ExceptionShielding");
            //return _exceptionManager.Process(() => _productRepository.Count<Item>(item => item.Category.Equals("RawMaterial") && (item.ItemName.ToLower().Contains(itemName.ToLower()) || item.String7.ToLower().Contains(itemName.ToLower()) || item.String8.ToLower().Contains(itemName.ToLower()) || item.String9.ToLower().Contains(itemName.ToLower()) || item.Description.ToLower().Contains(itemName.ToLower()))), "ExceptionShielding");
            
            List<int> supplierIds = _orderRepository.GetQuery<Customer>(c => c.Category == "Supplier" && c.CustomerName.Contains(itemName)).Select(x => x.CustomerID).ToList();

            List<int> itemIds = _inventoryRepository.GetQuery<Inventory>(c => c.Type == "RM1" && c.Remarks.Contains(itemName)).Select(x => x.ProductID).ToList();


            return _exceptionManager.Process(() => _productRepository.Count<Item>(item => item.Category.Equals("RawMaterial") && (item.ItemName.ToLower().Contains(itemName.ToLower()) || item.String7.ToLower().Contains(itemName.ToLower()) || item.String8.ToLower().Contains(itemName.ToLower()) || item.String9.ToLower().Contains(itemName.ToLower()) || itemIds.Contains(item.ItemID) || supplierIds.Contains(item.Int1 ?? 0) || item.Description.ToLower().Contains(itemName.ToLower()))), "ExceptionShielding");
        }

        public IEnumerable<RawMaterialPM> SearchRawMaterialsByName(int pageNumber, int pageSize, string rawMaterialName)
        {
            IEnumerable<Item> rawMaterials;

            
            List<int> supplierIds = _orderRepository.GetQuery<Customer>(c => c.Category == "Supplier" && c.CustomerName.Contains(rawMaterialName)).Select(x => x.CustomerID).ToList();

            List<int> itemIds = _inventoryRepository.GetQuery<Inventory>(c => c.Type == "RM1" && c.Remarks.Contains(rawMaterialName)).Select(x => x.ProductID).ToList();


            if (rawMaterialName=="") 
                rawMaterials = _exceptionManager.Process(() => _productRepository.GetByPage<Item>(item => item.Category.Equals("RawMaterial"), item => item.ItemName, pageNumber, pageSize), "ExceptionShielding");
            else
                //rawMaterials = _exceptionManager.Process(() => _productRepository.GetByPage<Item>(item => item.Category.Equals("RawMaterial") && item.ItemName.ToLower().Contains(rawMaterialName.ToLower()), item => item.ItemName, pageNumber, pageSize), "ExceptionShielding");
                //rawMaterials = _exceptionManager.Process(() => _productRepository.GetByPage<Item>(item => item.Category.Equals("RawMaterial") && (item.ItemName.ToLower().Contains(rawMaterialName.ToLower()) || item.String8.ToLower().Contains(rawMaterialName.ToLower())), item => item.ItemName, pageNumber, pageSize), "ExceptionShielding");
                //rawMaterials = _exceptionManager.Process(() => _productRepository.GetByPage<Item>(item => item.Category.Equals("RawMaterial") && (item.ItemName.ToLower().Contains(rawMaterialName.ToLower()) || item.String7.ToLower().Contains(rawMaterialName.ToLower()) || item.String8.ToLower().Contains(rawMaterialName.ToLower()) || item.String9.ToLower().Contains(rawMaterialName.ToLower()) || item.Description.ToLower().Contains(rawMaterialName.ToLower())), item => item.ItemName, pageNumber, pageSize), "ExceptionShielding");
                rawMaterials = _exceptionManager.Process(() => _productRepository.GetByPage<Item>(item => item.Category.Equals("RawMaterial") && (item.ItemName.ToLower().Contains(rawMaterialName.ToLower()) || item.String7.ToLower().Contains(rawMaterialName.ToLower()) || item.String8.ToLower().Contains(rawMaterialName.ToLower()) || item.String9.ToLower().Contains(rawMaterialName.ToLower()) || itemIds.Contains(item.ItemID) || supplierIds.Contains(item.Int1??0) || item.Description.ToLower().Contains(rawMaterialName.ToLower())), item => item.ItemName, pageNumber, pageSize), "ExceptionShielding");
            
            var returnable = RawMaterialMapper.ToPresentationModels(rawMaterials).ToList();
            foreach (var item in returnable)
            {
                GetRawMaterialBalanceQuantity(item);
                var rawMaterial = rawMaterials.FirstOrDefault(x => x.ItemID == item.Id);
                item.NoofParts = rawMaterial.BillOfMaterials.Count();
            }

            return returnable;
        }

        public IEnumerable<RawMaterialPM> SearchRawMaterialsByName1(string rawMaterialName, int partId)
        {
            IEnumerable<Item> rawMaterials;

            var part = _exceptionManager.Process(() => _productRepository.GetByKey<Item>(partId), "ExceptionShielding");

            var partMatIds = part.BillOfMaterials1.Where (x=>x.Item.Category =="RawMaterial").Select(x => x.Item.ItemID).ToList();
          
            
            if (rawMaterialName == "")
                //rawMaterials = _exceptionManager.Process(() => _productRepository.GetQuery<Item>(item => item.Category.Equals("RawMaterial")), "ExceptionShielding");
                rawMaterials = _exceptionManager.Process(() => _productRepository.GetQuery<Item>(item => item.Category.Equals("RawMaterial") && !partMatIds.Contains(item.ItemID)), "ExceptionShielding");
            else
                //rawMaterials = _exceptionManager.Process(() => _productRepository.GetQuery<Item>(item => item.Category.Equals("RawMaterial") && (item.ItemName.ToLower().Contains(rawMaterialName.ToLower())||item.Description.ToLower().Contains(rawMaterialName.ToLower()))), "ExceptionShielding");
                rawMaterials = _exceptionManager.Process(() => _productRepository.GetQuery<Item>(item => item.Category.Equals("RawMaterial") && !partMatIds.Contains(item.ItemID) && (item.ItemName.ToLower().Contains(rawMaterialName.ToLower()) || item.Description.ToLower().Contains(rawMaterialName.ToLower()) || item.String7.ToLower().Contains(rawMaterialName.ToLower()))), "ExceptionShielding");


            Option option = _exceptionManager.Process(() => _settingRepository.GetQuery<Option>(op => op.OptionName.Trim().Equals("MaterialAssignment")).SingleOrDefault(), "ExceptionShielding");
          
            if (option != null && option.DefaultSetting == "1")
            {
                rawMaterials = rawMaterials.Where(rm => rm.BillOfMaterials.Count() == 0 || rm.BillOfMaterials.Count(bom => bom.ProductAssemblyId == partId) > 0).ToList();
            }

            //filter out inactive material
            rawMaterials = rawMaterials.Where(pt=>!(pt.Group3 != null && pt.Group3 == "T"));
       
            var returnable = RawMaterialMapper.ToPresentationModels(rawMaterials).ToList();

            var customers = _exceptionManager.Process(() => _orderRepository.GetAll<Customer>(), "ExceptionShielding").ToList();

            foreach (var item in returnable)
            {
                //Customer c = _exceptionManager.Process(() => _orderRepository.GetByKey<Customer>(item.SupplierId), "ExceptionShielding");
                Customer c =  customers.FirstOrDefault (x=>x.CustomerID ==item.SupplierId);
                
                //Customer c = _orderRepository.GetByKey<Customer>(item.SupplierId);

                if (c != null)
                {
                    item.SupplierName = c.CustomerName;
                }
            }

           
            return returnable;
        }

        public void AddRawMaterial(RawMaterialPM rawMaterialPM)
        {
            Item item = RawMaterialMapper.FromPresentationModel(rawMaterialPM);
            //item.ItemName = !string.IsNullOrEmpty(rawMaterialPM.ExternalSerial) ? rawMaterialPM.PartId + "||" + rawMaterialPM.ExternalSerial : rawMaterialPM.PartId + "||" + rawMaterialPM.InternalSerial;
            item.Category = "RawMaterial";
            item.Type = 0;
            item.CreatedOn = DateTime.Today;

            _exceptionManager.Process(() =>
            {
                _productRepository.Add(item);
                _productRepository.UnitOfWork.SaveChanges();
            }, "ExceptionShielding");

            RawMaterialMapper.UpdatePresentationModel(rawMaterialPM, item);
        }

        public void UpdateRawMaterial(RawMaterialPM rawMaterialPM)
        {
            Item item = RawMaterialMapper.FromPresentationModel(rawMaterialPM);
            Item existingItem = _exceptionManager.Process(() => _productRepository.GetByKey<Item>(item.ItemID), "ExceptionShielding");

            existingItem.ItemName = item.ItemName;
            //existingItem.Category = item.Category;           
            existingItem.Description = item.Description;
            existingItem.UnitPrice = item.UnitPrice;

            existingItem.Int1 = item.Int1;
            existingItem.Int2 = item.Int2;
            //existingItem.Type = item.Type;

            existingItem.String1 = item.String1;
            existingItem.String2 = item.String2;
            existingItem.String3 = item.String3;
            existingItem.String4 = item.String4;
            existingItem.String5 = item.String5;
            existingItem.String6 = item.String6;
            existingItem.String7 = item.String7;
            existingItem.String8 = item.String8;
            existingItem.String9 = item.String9;
            
            existingItem.Group1 = item.Group1 ;
            existingItem.Group2 = item.Group2;
            existingItem.Group3 = item.Group3;
            existingItem.Flag1 = item.Flag1;


            existingItem.Float1 = item.Float1;

            _exceptionManager.Process(() =>
            {
                _productRepository.Update(existingItem);
                _productRepository.UnitOfWork.SaveChanges();
            }, "ExceptionShielding");


        }

        public void DeleteRawMaterial(RawMaterialPM rawMaterialPM)
        {
            try
            {
                _exceptionManager.Process(() => _productRepository.Delete<Item>(task => task.ItemID == rawMaterialPM.Id), "ExceptionShielding");
                _productRepository.UnitOfWork.SaveChanges();
            }
            catch (UpdateException exception)
            {
                if (exception.InnerException == null) throw;
                SqlException sqlException = exception.InnerException as SqlException;
                if (sqlException == null) throw;

                if (sqlException.Number != 547) throw;
                throw new DomainException("Record cannot be deleted due to related records.", 547);
            }
        }

        public IEnumerable<ItemPM> GetLinkedParts(int rawMaterialId)
        {
            Item rawMaterial = _exceptionManager.Process(() => _productRepository.GetByKey<Item>(rawMaterialId), "ExceptionShielding");

            var items = new List<Item>();

            foreach (var bom in rawMaterial.BillOfMaterials )
            {
                items.Add(bom.Item1);
            }

            return ItemMapper.ToPresentationModels(items).ToList ();
        }

        [Invoke]
        public int CheckPartName(int partId, string partName, string revision)
        {
            int count = 0;

            if (partId==0) //check part name
            {
                //count = _exceptionManager.Process(() => _productRepository.GetQuery<Item>(r => r.ItemName == partName.Trim()).Count(), "ExceptionShielding");
                // revision --> category
                count = _exceptionManager.Process(() => _productRepository.GetQuery<Item>(r => r.ItemName == partName.Trim() && r.Category ==revision ).Count(), "ExceptionShielding");
            }
            else //check revision, revision-->string9
            {
                var part = _exceptionManager.Process(() => _productRepository.GetByKey<Item>(partId), "ExceptionShielding");
                count = _exceptionManager.Process(() => _productRepository.GetQuery<Item>(r => r.ItemName == part.ItemName && r.String9 == revision).Count(), "ExceptionShielding");
            }


            return count;

        }

        [Invoke]
        public void ImportDataFromERP(bool isCustomer, bool isFG, bool isMateial, bool isMaterialCost, bool isSalesOrder)
        {            
            if (isCustomer) _productRepository.ExecuteSQLQuery<int>(@"EXEC sp_IAddCustomer ''");
            if (isFG) _productRepository.ExecuteSQLQuery<int>(@"EXEC sp_IAddItem ''");
            if (isMateial) _productRepository.ExecuteSQLQuery<int>(@"EXEC sp_IAddMaterial ''");
            if (isMaterialCost)  _productRepository.ExecuteSQLQuery<int>(@"EXEC sp_IAddMaterialInventory ''");
            if (isSalesOrder)  _productRepository.ExecuteSQLQuery<int>(@"EXEC sp_IAddSalesOrder ''");

        }

        [Invoke]
        public int CopyPart(int partId, string partName, string revision)
        {
           
            //var item = _exceptionManager.Process(() => _productRepository.GetByKey<Item>(partId), "ExceptionShielding");
            //var newPart = new Item();
     
            //newPart.Category = item.Category;
            //newPart.Description = item.Description;
            //newPart.UnitPrice = item.UnitPrice;

            //newPart.Int1 = item.Int1;
            //newPart.Int2 = item.Int2;
            //newPart.Int3 = item.Int3;
            //newPart.Int4 = item.Int4;
            //newPart.Int5 = item.Int5;
            //newPart.Int6 = item.Int6;
            //newPart.Int7 = item.Int7;
            //newPart.Int8 = item.Int8;
            //newPart.Int9 = item.Int9;
            //newPart.Int10 = item.Int10;

            //newPart.String1 = item.String1;
            //newPart.String2 = item.String2;
            //newPart.String3 = item.String3;
            //newPart.String4 = item.String4;
            //newPart.String5 = item.String5;
            //newPart.String6 = item.String6;
            //newPart.String7 = item.String7;
            //newPart.String8 = item.String8;


            //newPart.MaxString1 = newPart.MaxString1;
            //newPart.MaxString2 = newPart.MaxString2;
            //newPart.MaxString3 = newPart.MaxString3;
            //newPart.MaxString4 = newPart.MaxString4;
            //newPart.MaxString5 = newPart.MaxString5;
           

            //newPart.Group1 = item.Group1;
            //newPart.Group2 = item.Group2;
            //newPart.Group3 = item.Group3;
            //newPart.Group4 = item.Group4;
            //newPart.Group5 = item.Group5;
            //newPart.Group6 = item.Group6;

            //newPart.Flag1 = item.Flag1;
            //newPart.Flag2 = item.Flag2;
            //newPart.Flag3 = item.Flag3;
            //newPart.Flag4 = item.Flag4;
            //newPart.Flag5 = item.Flag5;
            
          
            //newPart.Float1 = item.Float1;
            //newPart.Float2 = item.Float2;
            //newPart.Float3 = item.Float3;
            //newPart.Float4 = item.Float4;
            //newPart.Float5 = item.Float5;

            //newPart.ParentItemID = item.ParentItemID;

            //newPart.ItemName = partName;
            //newPart.String9 = revision;

            
            ////deactive the old revision
            //if (newPart.ItemName ==item.ItemName )
            //{
            //    item.Group3 = "T";
            //}
                

            //_exceptionManager.Process(() =>
            //{
            //    _productRepository.Add(newPart);
            //    _productRepository.UnitOfWork.SaveChanges();
            //}, "ExceptionShielding");

            

            //newPart.BillOfMaterials1 = new List<BillOfMaterial>();
            //foreach (var bom in item.BillOfMaterials1)
            //{
            //    var bom1 = new BillOfMaterial();
            //    bom1.BOMLevel = bom.BOMLevel;
            //    bom1.ComponentId = bom.ComponentId;
            //    bom1.ProductAssemblyId = newPart.ItemID ;
            //    bom1.ModifiedBy = bom.ModifiedBy;
            //    bom1.UOMCode = bom.UOMCode;
            //    bom1.StartDate = bom.StartDate;
            //    bom1.EndDate = bom.EndDate;
            //    bom1.PerAssemblyQty = bom.PerAssemblyQty;

            //    newPart.BillOfMaterials1.Add(bom1);
            //}

            //newPart.CustomerItems = new List<CustomerItem>();
            //foreach (var customerItem in item.CustomerItems)
            //{
            //    var customerItem1 = new CustomerItem();
            //    customerItem1.CustomerID = customerItem.CustomerID;
            //    customerItem1.ItemID = newPart.ItemID;

            //    newPart.CustomerItems.Add(customerItem1);
            //}



            //_exceptionManager.Process(() =>
            //{
            //    _productRepository.Update(newPart);
            //    _productRepository.UnitOfWork.SaveChanges();
            //}, "ExceptionShielding");


            CopyPart(partId, partName, revision, true);
            return 1;
        }


        private Item CopyPart(int partId, string partName, string revision, bool disableOldRevison)
        {

            var item = _exceptionManager.Process(() => _productRepository.GetByKey<Item>(partId), "ExceptionShielding");
            var newPart = new Item();

            newPart.Category = item.Category;
            newPart.Description = item.Description;
            newPart.UnitPrice = item.UnitPrice;

            newPart.Int1 = item.Int1;
            newPart.Int2 = item.Int2;
            newPart.Int3 = item.Int3;
            newPart.Int4 = item.Int4;
            newPart.Int5 = item.Int5;
            newPart.Int6 = item.Int6;
            newPart.Int7 = item.Int7;
            newPart.Int8 = item.Int8;
            newPart.Int9 = item.Int9;
            newPart.Int10 = item.Int10;

            newPart.String1 = item.String1;
            newPart.String2 = item.String2;
            newPart.String3 = item.String3;
            newPart.String4 = item.String4;
            newPart.String5 = item.String5;
            newPart.String6 = item.String6;
            newPart.String7 = item.String7;
            newPart.String8 = item.String8;


            newPart.MaxString1 = item.MaxString1;
            newPart.MaxString2 = item.MaxString2;
            newPart.MaxString3 = item.MaxString3;
            newPart.MaxString4 = item.MaxString4;
            newPart.MaxString5 = item.MaxString5;


            newPart.Group1 = item.Group1;
            newPart.Group2 = item.Group2;
            newPart.Group3 = item.Group3;
            newPart.Group4 = item.Group4;
            newPart.Group5 = item.Group5;
            newPart.Group6 = item.Group6;

            newPart.Flag1 = item.Flag1;
            newPart.Flag2 = item.Flag2;
            newPart.Flag3 = item.Flag3;
            newPart.Flag4 = item.Flag4;
            newPart.Flag5 = item.Flag5;


            newPart.Float1 = item.Float1;
            newPart.Float2 = item.Float2;
            newPart.Float3 = item.Float3;
            newPart.Float4 = item.Float4;
            newPart.Float5 = item.Float5;

            newPart.ParentItemID = item.ParentItemID;

            newPart.ItemName = partName;
            newPart.String9 = revision;


            //deactive the old revision
            if (newPart.ItemName == item.ItemName && disableOldRevison)
            {
                item.Group3 = "T";
            }


            _exceptionManager.Process(() =>
            {
                _productRepository.Add(newPart);
                _productRepository.UnitOfWork.SaveChanges();
            }, "ExceptionShielding");



            newPart.BillOfMaterials1 = new List<BillOfMaterial>();
            foreach (var bom in item.BillOfMaterials1)
            {
                var bom1 = new BillOfMaterial();
                bom1.BOMLevel = bom.BOMLevel;
                bom1.ComponentId = bom.ComponentId;
                bom1.ProductAssemblyId = newPart.ItemID;
                bom1.ModifiedBy = bom.ModifiedBy;
                bom1.UOMCode = bom.UOMCode;
                bom1.StartDate = bom.StartDate;
                bom1.EndDate = bom.EndDate;
                bom1.PerAssemblyQty = bom.PerAssemblyQty;

                newPart.BillOfMaterials1.Add(bom1);
            }

            newPart.CustomerItems = new List<CustomerItem>();
            foreach (var customerItem in item.CustomerItems)
            {
                var customerItem1 = new CustomerItem();
                customerItem1.CustomerID = customerItem.CustomerID;
                customerItem1.ItemID = newPart.ItemID;

                newPart.CustomerItems.Add(customerItem1);
            }



            _exceptionManager.Process(() =>
            {
                _productRepository.Update(newPart);
                _productRepository.UnitOfWork.SaveChanges();
            }, "ExceptionShielding");

            return newPart;
        }


        #endregion

        #region Auxiliary methods

        private KitTypePM GetCustomersForKitType(Item item)
        {

            KitTypePM kitTypePM = KitTypeMapper.ToPresentationModel(item);


            foreach (CustomerItem customerItem in item.CustomerItems)
            {
                kitTypePM.Customers += ";" + _exceptionManager.Process(() => _orderRepository.GetByKey<Customer>(customerItem.CustomerID).CustomerName, "ExceptionShielding");
            }

            if (!string.IsNullOrEmpty(kitTypePM.Customers))
                kitTypePM.Customers = kitTypePM.Customers.Remove(0, 1);

            //var products = _productRepository.GetQuery<BillOfMaterial>(k => k.ProductAssemblyId == item.ItemID && !k.Item.Category.Equals("RawMaterial"));

            var materials = _productRepository.GetQuery<BillOfMaterial>(k => k.ProductAssemblyId == item.ItemID && k.Item.Category.Equals ("RawMaterial"));
            kitTypePM.Materials = "";
            foreach (var bom in materials)
            {
                kitTypePM.Materials += ";" + bom.Item.ItemName;
            }
            if (!string.IsNullOrEmpty(kitTypePM.Materials))
                kitTypePM.Materials = kitTypePM.Materials.Remove(0, 1);

            if (kitTypePM.RouteId == null || kitTypePM.RouteId==0)
            {
                var familyRoute=_processRepository.GetQuery<SIMTech.APS.Process.Business.Route>(x => x.Comment == kitTypePM.PartFamily && x.Version == 1).FirstOrDefault();

                if (familyRoute != null)
                    kitTypePM.RouteId = familyRoute.RouteId;
            }

            if (kitTypePM.RouteId != null || kitTypePM.RouteId > 0)
            {
                var route=_processRepository.GetQuery<SIMTech.APS.Process.Business.Route>(x => x.RouteId ==kitTypePM.RouteId).FirstOrDefault();

                if (route != null)
                    kitTypePM.RouteName = route.RouteName;
            }

            return kitTypePM;
        }


      
        public IEnumerable<RouteOperationPM> GetOperationsBasedOnRouteId( int routeId)
        {
            var route = _processRepository.GetQuery<SIMTech.APS.Process.Business.RouteOperation>(x => x.RouteId == routeId).ToList();


            var ros = new List<RouteOperationPM>();
            foreach (var a in route)
            {
                var ro = new RouteOperationPM();

                ro.Id = a.RouteOperationId;
                ro.RouteId = a.RouteId;
                ro.Sequence = a.Sequence ?? 0;
                ro.OperationId = a.OperationId ?? 0;
                ro.OperationName = a.Operation.OperationName;
                ros.Add(ro);
            }

            return ros;
        }


        private PartTypePM GetCustomersForPartType(Item item)
        {

            PartTypePM partTypePM = PartTypeMapper.ToPresentationModel(item);

            partTypePM.Customers = "";

            foreach (CustomerItem customerItem in item.CustomerItems)
            {
                partTypePM.Customers += ";" + _exceptionManager.Process(() => _orderRepository.GetByKey<Customer>(customerItem.CustomerID).CustomerName, "ExceptionShielding");
            }

            if (!string.IsNullOrEmpty(partTypePM.Customers))
                partTypePM.Customers = partTypePM.Customers.Remove(0, 1);

            var BOMs = _productRepository.GetQuery<BillOfMaterial>(k => k.ComponentId == item.ItemID);
            foreach (var bom in BOMs)
            {
                partTypePM.Assemblies += ";" + bom.Item1.ItemName;
            }

            if (!string.IsNullOrEmpty(partTypePM.Assemblies))
                partTypePM.Assemblies = partTypePM.Assemblies.Remove(0, 1);


          
            var materials = _productRepository.GetQuery<BillOfMaterial>(k => k.ProductAssemblyId == item.ItemID);
            partTypePM.Materials = "";
            foreach (var bom in materials)
            {
                partTypePM.Materials += ";" + bom.Item.ItemName;
            }
            


            if (!string.IsNullOrEmpty(partTypePM.Materials))
                partTypePM.Materials = partTypePM.Materials.Remove(0, 1);



            return partTypePM;
        }

        private string GetWorkOrderStatus(int value)
        {
            EWorkOrderStatus workOrderStatus = (EWorkOrderStatus)value;
            switch (workOrderStatus)
            {
                case EWorkOrderStatus.ReturnUnclean:
                    return "Return Unclean";
                case EWorkOrderStatus.Completed:
                    return "Completed";
                case EWorkOrderStatus.Charged:
                    return "Completed";
                case EWorkOrderStatus.Dispatched:
                    return "Dispatched";
                case EWorkOrderStatus.Pending:
                    return "Pending";
                case EWorkOrderStatus.Processing:
                    return "Processing";
                case EWorkOrderStatus.Queuing:
                    return "Queuing";
                case EWorkOrderStatus.Released:
                    return "Released";
                case EWorkOrderStatus.Scrapped:
                    return "Scrapped";
                case EWorkOrderStatus.SCRGenerated:
                    return "DO Generated";
                case EWorkOrderStatus.Discard:
                    return "Discard";
            }
            return string.Empty;
        }

        private void GetRawMaterialBalanceQuantity( RawMaterialPM item)
        {
            item.Supplier = SupplierMapper.ToPresentationModel(_exceptionManager.Process(() => _orderRepository.GetByKey<Customer>(item.SupplierId), "ExceptionShielding"));
            if (item.Supplier != null)
            {
                item.SupplierName = item.Supplier.Name;
                if (string.IsNullOrEmpty (item.Currency) )
                    item.Currency = item.Supplier.SupplierCode;
            }

            var rawMatls = GetInventoryForRawMaterial(item.Id,true).Where (a=>a.Type.Trim()=="RM" || a.PartId==(item.LinkedPartId??0));
            decimal? balanceQty = 0;
            decimal? cost = 0;
            foreach (var rawMatl in rawMatls)
            {
                balanceQty += rawMatl.CompletedQty - rawMatl.InventoryUsages.Sum(x => x.Quantity);
                cost += rawMatl.Cost - rawMatl.InventoryUsages.Sum(x => x.Cost??0);
            }
            item.BalanceQuantity = (double?)balanceQty;
            item.Cost = cost;
            if (item.BalanceQuantity == 0) item.BalanceQuantity = null;
            if (item.Cost == 0) item.Cost = null;


            //item.RequiredQuantity = _orderRepository.GetQuery<WorkOrderMaterial>(x => x.MaterialId == item.Id && x.Ratio != null && (x.Availability == null || x.Availability == false)).Sum(x => x.Ratio * x.WorkOrder.Quantity);
            item.RequiredQuantity = _orderRepository.GetQuery<WorkOrderMaterial>(x => x.MaterialId == item.Id && x.Quantity !=null && (x.Availability == null || x.Availability == false)).Sum(x=>x.Quantity);
            if (item.RequiredQuantity == 0) item.RequiredQuantity = null;
        }

        #endregion

        #region Inventory Services Wrapper

       
       

        public IEnumerable<InventoryPM> GetInventoryForRawMaterial(int rawMaterialId, bool hasBalanceQty)
        {
            var inventoryService = new InventoryDomainService();

            return inventoryService.GetInventoryByCustomer(0, rawMaterialId, hasBalanceQty);          
        }




        [Invoke]
        public int UpdateRawMaterialInventory(InventoryPM rawMaterialInventory)
        {
            var inventoryService = new InventoryDomainService();
            
            if (rawMaterialInventory.Id ==0)
            {
                inventoryService.AddInventory (rawMaterialInventory);               
            }
            else
            {
                inventoryService.UpdateInventory(rawMaterialInventory);                
            }

            //auto allocation raw material to work order based on the creation day
            AllocateRawMaterial(rawMaterialInventory.Id);

            return rawMaterialInventory.Id;
        }

        [Invoke]
        public void UpdateRawMaterialInventoryUsage(int inventoryId, List<InventoryUsagePM> InventoryUsages)
        {
            if (inventoryId == 0) return;

            var inventoryService = new InventoryDomainService();

            var existingUsageIds = inventoryService.GetInventoryUsageId(inventoryId);
            var usageIds = InventoryUsages.Select(a => a.Id);

            var removedUsageIds = existingUsageIds.Except(usageIds);

            foreach (var item in removedUsageIds)
            {
                inventoryService.DeleteInventoryUsageById(item);                
            }

            foreach (var item in InventoryUsages.Where(a => a.Id == 0))
            {
                item.InventoryId = inventoryId;
                inventoryService.AddInventoryUsage(item);
            }


            //update locked info using status field

            var inventory =_inventoryRepository.GetByKey<Inventory>(inventoryId);
          
            foreach (var item in InventoryUsages)
            {
                var a=inventory.InventoryUsages.FirstOrDefault(x => x.InventoryUsageID == item.Id);
                if (a!=null)
                {      
                
                    if (a.Status !=item.Status )
                    {
                        a.Status = item.Status;
                    }
                }                
            }
            _inventoryRepository.UnitOfWork.SaveChanges();

        }

        [Invoke]
        public List<RawMaterialPM> GetWorkOrderRawMaterialAllocation(int rawMaterialId)
        {
            var inventoryService = new InventoryDomainService();

            var workOrderMaterials = _orderRepository.GetQuery<WorkOrderMaterial>(x => x.MaterialId == rawMaterialId).ToList();
            var rawMaterials = new List<RawMaterialPM>();

            foreach (var workOrderMaterial in workOrderMaterials)
            {

                var inventoryUsages = inventoryService.GetInventoryUsageByWorkOrder(workOrderMaterial.WorkOrderId, rawMaterialId);

                var inventoryUsageId = 0;
                bool isLocked = false;
                if (inventoryUsages.FirstOrDefault() != null)
                {
                    inventoryUsageId = inventoryUsages.FirstOrDefault().Id;
                    isLocked = !string.IsNullOrEmpty(inventoryUsages.FirstOrDefault().Status); 
                }
                  
                var allocatedQty = inventoryUsages.Sum(x => x.Quantity);

                var allocatedQty1 = inventoryService.GetInventoryUsageByWorkOrderFIFO(workOrderMaterial.WorkOrderId, rawMaterialId).Sum(x => x.Quantity);
                

                var uom = workOrderMaterial.UnitMeasureID;
                double? matlQty = workOrderMaterial.WorkOrder.Quantity * workOrderMaterial.Ratio;
                var matlQty1 = System.Math.Ceiling(matlQty ?? 0);

                var wod = workOrderMaterial.WorkOrder.WorkOrderDetails.FirstOrDefault();
                var poNumber = "";

                if (wod!=null)
                {
                    poNumber = wod.SalesOrderDetail.SalesOrder.SalesOrderNumber.Trim();
                }
                else
                {
                    var wo = workOrderMaterial.WorkOrder;
                    while (wo!=null)
                    {        
                        if ( wo.ParentWorkOrderID==null || wo.ParentWorkOrderID == 0) break;
                        wo = _orderRepository.GetByKey<WorkOrder>(wo.ParentWorkOrderID);                         
                    }
                    wod = wo.WorkOrderDetails.FirstOrDefault();
                    if (wod!=null)
                        poNumber = wod.SalesOrderDetail.SalesOrder.SalesOrderNumber.Trim();
                }


                //decimal allocatedQty=0;
                //if (materialUsages != null && materialUsages.Count >0)
                //    allocatedQty = materialUsages.Where(x => x.Inventory.PartId == rawMaterialId).Sum(x => x.Quantity);

                //if (allocatedQty>0)
                //rawMaterials.Add(new RawMaterialPM() { Id = workOrderMaterial.WorkOrderId, RawMaterialName = workOrderMaterial.WorkOrder.WorkOrderNumber, Ratio = (decimal)(workOrderMaterial.Ratio ?? 0), Quantity = workOrderMaterial.WorkOrder.Quantity, RequiredQuantity = uom == 0 ? matlQty : (uom == 1 ? workOrderMaterial.Ratio : matlQty1), AllocatedQuantity = (double?)allocatedQty, IsSelected = (allocatedQty > 0), Status = GetWorkOrderStatus(workOrderMaterial.WorkOrder.Status) });
                //rawMaterials.Add(new RawMaterialPM() { Id = workOrderMaterial.WorkOrderId , RawMaterialName = workOrderMaterial.WorkOrder.WorkOrderNumber, CreatedDate =workOrderMaterial.WorkOrder.CreatedOn , Ratio = (decimal)(workOrderMaterial.Ratio ?? 0), Quantity = workOrderMaterial.WorkOrder.Quantity, RequiredQuantity = workOrderMaterial.Quantity  , AllocatedQuantity = (double?)allocatedQty, IsSelected = (allocatedQty > 0), Status = GetWorkOrderStatus(workOrderMaterial.WorkOrder.Status) });
                rawMaterials.Add(new RawMaterialPM() { Id = workOrderMaterial.WorkOrderId, RawMaterialName = workOrderMaterial.WorkOrder.WorkOrderNumber, RawMaterialType ="WO", PONumber = poNumber, CreatedDate = workOrderMaterial.WorkOrder.CreatedOn, Ratio = (decimal)(workOrderMaterial.Ratio ?? 0), Quantity = workOrderMaterial.WorkOrder.Quantity, RequiredQuantity = workOrderMaterial.Quantity, AllocatedQuantity = (double?)allocatedQty, AllocatedQuantity1 = (double?)allocatedQty1, IsSelected = (allocatedQty > 0), Status = GetWorkOrderStatus(workOrderMaterial.WorkOrder.Status), LinkedPartId =inventoryUsageId, IsLocked =isLocked  });

            }

            return rawMaterials;
        }

        //[Insert]
        //public void AddInventoryUsage(InventoryUsagePM inventoryUsagePM)
        //{
        //    var inventoryService = new InventoryDomainService();
        //    inventoryService.AddInventoryUsage(inventoryUsagePM);
        //}

        //[Delete]
        //public void DeleteInventoryUsage(InventoryUsagePM inventoryUsagePM)
        //{
        //    var inventoryService = new InventoryDomainService();
        //    inventoryService.DeleteInventoryUsage(inventoryUsagePM);
        //}

        //[Update]
        //public void UpdateInventoryUsage(InventoryUsagePM inventoryUsagePM)
        //{
        //    var inventoryService = new InventoryDomainService();
        //    inventoryService.UpdateInventoryUsage(inventoryUsagePM);
        //}

        [Invoke]
        public int AddInventory(InventoryPM inventoryPM)
        {
            var inventoryService = new InventoryDomainService();

            inventoryService.AddInventory(inventoryPM);

            return inventoryPM.Id;

           
        }

        [Update]
        public void UpdateInventory1(InventoryPM inventoryPM)
        {

            //To support edit mode

            //var inventoryService = new InventoryDomainService();

            //inventoryService.UpdateInventory(inventoryPM);
        }

        [Invoke]
        public void UpdateInventory(InventoryPM inventoryPM)
        {
            var inventoryService = new InventoryDomainService();

            inventoryService.UpdateInventory(inventoryPM);
        }

        [Invoke]
        public void DeleteInventory(InventoryPM inventoryPM)
        {
            var inventoryService = new InventoryDomainService();

            inventoryService.DeleteInventory(inventoryPM);


        }

        public IEnumerable<InventoryPM> GetAvaliableInventory(int customerId, int productId)
        {
            var inventoryService = new InventoryDomainService();

            return inventoryService.GetInventoryByCustomer(customerId, productId, true);
        }

        public IEnumerable<InventoryPM> GetDOInventory(int deliveryOrderLineId)
        {
            var inventoryService = new InventoryDomainService();

            return inventoryService.GetInventoryByDeliveryOrder(deliveryOrderLineId);
        }

        public IEnumerable<InventoryMasPM> GetInventoryMas()
        {
            var inventoryService = new InventoryDomainService();

            return inventoryService.GetAllInventoryMas();
        }


        [Invoke]
        public List<InventoryPM> GetInventoryForWorkOrderNumber(string workOrderNumber)
        {

            var inventoryPMs = new List<InventoryPM>();

            //var workOrder = _orderRepository.GetQuery<WorkOrder>(a => a.WorkOrderNumber == workOrderNumber).FirstOrDefault ();

            var workOrders = _orderRepository.GetQuery<WorkOrder>(a => workOrderNumber.Contains(a.WorkOrderNumber));


            if (workOrders != null)
            {
                var inventoryService = new InventoryDomainService();

                inventoryPMs = inventoryService.GetInventoryByWorkOrder(workOrders.Select(a => a.WorkOrderID).ToList(), true).ToList();
            }


            return inventoryPMs;
        }


        private void GetInventoryAllocation(int workOrderId)
        {
            var inventoryService = new InventoryDomainService();

                //deliverOrderLine.InventoryAllocations = inventoryService.GetInventoryUsageByDeliveryOrder(workOrderId);
                //deliverOrderLine.ChangeQuantity = deliverOrderLine.InventoryAllocations.Sum(a => (double)a.Quantity);
            



        }

        private void DeleteInventoryAllocation(int workOrderId)
        {
            var inventoryService = new InventoryDomainService();

            inventoryService.DeleteInventoryUsageByDeliveryOrder(workOrderId);
        }


        [Invoke]
        public double CheckRequiredRawMaterial(int materialId)
        {
            double requiredQty=0;
            
            var requiredWorkOrders = _orderRepository.GetQuery<WorkOrderMaterial>(a => a.MaterialId == materialId && !(a.Availability ?? false));

            if (requiredWorkOrders.Count() >0)
              requiredQty = requiredWorkOrders.Sum(a => a.Quantity ?? 0);

            //var requiredQty = _orderRepository.GetQuery<WorkOrderMaterial>(a => a.MaterialId == materialId && a.Quantity !=null && (a.Availability==null || a.Availability ==false)).Sum(a => a.Quantity);
           
         
                      
            return requiredQty;
        }

        [Invoke]
        public void AllocateRawMaterial(int inventoryId)
        {

            if (inventoryId == 0) return;

            var workOrderMaterialIds = new List<int>();

            var rawMaterial = _inventoryRepository.GetQuery<Inventory>(a => a.InventoryID == inventoryId && a.Type == "RM").FirstOrDefault();

            if (rawMaterial != null)
            {
                var balanceQuantity = rawMaterial.Quantity - rawMaterial.InventoryUsages.Sum(a => (decimal?)a.Quantity);
                if (balanceQuantity > 0)
                {
                    var workOrderRawmaterials = _orderRepository.GetQuery<WorkOrderMaterial>(a => a.MaterialId == rawMaterial.ProductID  && !(a.Availability ?? false) && (byte)a.WorkOrder.Status <= (byte)EWorkOrderStatus.Queuing).OrderBy(a => a.WorkOrder.WorkOrderID);
                  
                    foreach (var workOrderMaterial in workOrderRawmaterials)
                    {
                        if (balanceQuantity >= (decimal?)workOrderMaterial.Quantity)
                        {
                            InventoryUsage inventoryUsage = new InventoryUsage() { InventoryID = inventoryId, UsageType = 1, UsedByOrderID = workOrderMaterial.WorkOrderId, Quantity = (decimal)workOrderMaterial.Quantity };
                            inventoryUsage.DateOut = DateTime.Now;

                            _inventoryRepository.Add(inventoryUsage);

                           
                            // update allocation flag via trigger
                             //workOrderMaterial.Availability = true;
                             //_orderRepository.Update(workOrderMaterial);

                            workOrderMaterialIds.Add(workOrderMaterial.WorkOrderMaterialId);
                           

                            balanceQuantity -= (decimal?)workOrderMaterial.Quantity;
                        }
                    }

                    foreach (var id in workOrderMaterialIds)
                    {
                        workOrderRawmaterials.First(x => x.WorkOrderMaterialId == id).Availability = true;
                        //_orderRepository.Update(workOrderMaterial);
                    }

                    _exceptionManager.Process(() =>
                    {

                        _inventoryRepository.UnitOfWork.SaveChanges();
                        _orderRepository.UnitOfWork.SaveChanges();
                    }, "ExceptionShielding");


                }

            }

        }

        [Invoke]
        public string GetSettingValue(string optionName)
        {
            Option option = _exceptionManager.Process(() => _settingRepository.GetQuery<Option>(op => op.OptionName.Trim().Equals(optionName)).FirstOrDefault(), "ExceptionShielding");
            return option == null ? "" : option.DefaultSetting;
        }

        // Ravi Nov-13-2017 Get workorders by receipt

          [Invoke]
        public IEnumerable<WorkOrderInventoryPM> GetAllocatedWorkorderbyReceipt(int invId, int productId)
        {
            List<WorkOrderInventoryPM> woreslist = new List<WorkOrderInventoryPM>();
            WorkOrderInventoryPM objUI = null;

            var receiptInvlist = _inventoryRepository.GetQuery<InventoryUsage>(i => i.InventoryID == invId && i.UsageType == 3).ToList();
            List<int> invusagelist = receiptInvlist.Select(r => r.UsedByOrderID).ToList<int>();
            var receiptWOlist = _inventoryRepository.GetQuery<InventoryUsage>(i => i.UsageType == 1 && invusagelist.Contains(i.InventoryUsageID)).ToList();
            List<int> woidlist = receiptWOlist.Select(r => r.UsedByOrderID).ToList<int>();

            var womatlist = _orderRepository.GetQuery<WorkOrderMaterial>(w => w.MaterialId == productId && woidlist.Contains(w.WorkOrderId)).ToList();
         
            var wolist = _orderRepository.GetQuery<WorkOrder>(w => woidlist.Contains(w.WorkOrderID)).ToList();

           
              Double dcost=0;
              string sremark =string.Empty;
            foreach (var obj in wolist)
            {
                objUI = new WorkOrderInventoryPM();
                objUI.Id = obj.WorkOrderID;
                objUI.WorkOrderNumber = obj.WorkOrderNumber;
                objUI.val1 = obj.Quantity;
                objUI.Status = GetWorkOrderStatus(obj.Status);
                objUI.Createdon = obj.CreatedOn;
              
                //allocated qty
               // objUI.Quantity 
                var findwo = receiptWOlist.Where(i => i.UsedByOrderID == obj.WorkOrderID).ToList();
                if(findwo != null && findwo.Count > 0)
                {
                    int usageid = findwo.FirstOrDefault().InventoryUsageID;
                    var findInv = receiptInvlist.Where(i => i.UsedByOrderID == usageid).ToList();
                    if(findInv != null && findInv.Count > 0)
                    {
                        var invmain  = findInv.FirstOrDefault();
                        objUI.Quantity = invmain.Quantity;
                        objUI.DateOut = invmain.DateOut;
                        if(invmain.Remarks != null && invmain.Remarks.Trim() != "")
                        {
                            sremark = invmain.Remarks;
                            dcost = 0;
                            if (sremark != string.Empty && Double.TryParse(sremark, out dcost))
                            {
                                //allocated cost
                                objUI.Cost = dcost;
                            }
                        }
                    }
                }
            
               
                
                var womat1 = womatlist.Where(w => w.WorkOrderId == obj.WorkOrderID).ToList();
                if (womat1 != null && womat1.Count > 0)
                {
                    var objmatfind= womat1.FirstOrDefault();
                    //Required Mat Qty
                    if(objmatfind.Quantity != null)
                    {
                        objUI.AllocQty = Math.Round(objmatfind.Quantity ?? 0,3);
                    }
                   
                    if (objmatfind.Ratio != null)
                    {
                        objUI.Ratio = Math.Round(objmatfind.Ratio ?? 0, 3);
                    }

                    
                   
                }

                //customer
                var custlist = _orderRepository.GetQuery<Customer>(w => w.CustomerID == obj.CustomerID).ToList();
                if (custlist != null && custlist.Count > 0)
                {
                    objUI.Customer = custlist.FirstOrDefault().CompanyName;
                }
                woreslist.Add(objUI);
            }

            return woreslist.OrderBy(w => w.Createdon).ToList();
        }


        [Invoke]
        public int UpdateAssembly(int customerId,int parentId, int productId, string revision, string buyFlag)
        {
            var item = _productRepository.GetByKey<Item>(productId );
            var newPartId = 0;

            //group2
            if (item.String9!=revision ) //new revision
            {                 
                var newPart=CopyPart(productId,item.ItemName ,revision,false );

                newPart.Group2 = buyFlag;

                if (newPart.Int10 != customerId)
                {
                    newPart.Int10 = customerId;
                    foreach(var custitem in newPart.CustomerItems)
                    {
                        custitem.CustomerID = customerId;
                    }
                }
                newPartId = newPart.ItemID;
                _productRepository.Update(newPart);
             
            }
            else
            {
                item.Group2 = buyFlag;
                _productRepository.Update(item);
            }

            if (parentId>0 && newPartId>0)
            {
                var bom = _productRepository.GetQuery<BillOfMaterial>(x => x.ProductAssemblyId == parentId && x.ComponentId ==productId  ).FirstOrDefault();

                if (bom != null) bom.ComponentId = newPartId;
                _productRepository.Update(bom);
            }
          

            _exceptionManager.Process(() =>
            {            
                _productRepository.UnitOfWork.SaveChanges();
            }, "ExceptionShielding");

            return newPartId;
        }

        
        #endregion
    }
}
