﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Transactions;
using System.Threading.Tasks;

namespace SIMTech.APS.Permission.API.Controllers
{
    using SIMTech.APS.Permission.API.Repository;
    using SIMTech.APS.Permission.API.Models;
    using SIMTech.APS.Permission.API.PresentationModels;

    [Route("api/[controller]")]
    [ApiController]
    public class MenuController : ControllerBase
    {
        private readonly IMenuRepository _menuRepository;

        public MenuController(IMenuRepository menuRepository)
        {
            _menuRepository = menuRepository;
        }


        //GET: api/Role
        [HttpGet]
        public async Task<IEnumerable<Menu>> GetAllMenus() => await _menuRepository.GetAll();

        [HttpGet]
        [Route("{id}")]
        public Menu GetMenuById(int id) => _menuRepository.GetById(id);


        [HttpPost]
        public void AddMenu([FromBody] Menu menu) => _menuRepository.Insert(menu);

        [HttpPut]
        public void UpdateMenu([FromBody] Menu menu) => _menuRepository.Update(menu);



        // DELETE api/<RoleController>/5
        [HttpDelete("{id}")]
        public void DeleteMenu(int id) => _menuRepository.Delete(id);

    }
}
