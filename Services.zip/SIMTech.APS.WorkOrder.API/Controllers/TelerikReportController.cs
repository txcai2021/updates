﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System;

namespace SIMTech.APS.WorkOrder.API.Controllers
{
    using SIMTech.APS.PresentationModels;
    using SIMTech.APS.Product.API.PresentationModels;
    using SIMTech.APS.SalesOrder.API.PresentationModels;
    using SIMTech.APS.WorkOrder.API.Helper;
    using SIMTech.APS.WorkOrder.API.Mappers;
    using SIMTech.APS.WorkOrder.API.Models;
    using SIMTech.APS.WorkOrder.API.PresentationModels;
    using SIMTech.APS.WorkOrder.API.Repository;

    using Telerik.Reporting.Services;
    using Telerik.Reporting.Services.AspNetCore;

    [Route("api/[controller]")]
    [ApiController]
    public class TelerikReportController : ReportsControllerBase
    {
        private readonly IWorkOrderRepository _workOrderRepository;

        private List<IdNamePM> _items;
        private List<BasePM> _customers;
        private List<RoutePM> _routings;
        private List<BasePM> _locations;
        private List<SalesOrderPM> _salesOrder;

        private Dictionary<int, RawMaterialPM> rawMaterialDict;

        public TelerikReportController(IReportServiceConfiguration reportServiceConfiguration, IWorkOrderRepository workOrderRepository): base(reportServiceConfiguration)
        {
            _workOrderRepository = workOrderRepository;
        }

        [HttpGet("{id}")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<ActionResult<IEnumerable<TelerikReportWorkOrder>>> GetAllWorkOrdersUnderParentWorkOrderId(int id)
        {
            List<WorkOrder> allWorkOrdersUnderParentWorkOrder = await GetWorkOrdersAndItsChilds(id);

            Dictionary<int, List<WorkOrder>> childWorkOrdersByParentId = 
                SortChildWorkOrdersParentId(allWorkOrdersUnderParentWorkOrder);

            GetAllRequiredWorkOrderDataForReport(allWorkOrdersUnderParentWorkOrder);

            List<WorkOrderPM> workOrderPMs =
                WorkOrderMapper.ToPresentationModels(allWorkOrdersUnderParentWorkOrder).ToList();

            rawMaterialDict = ApiHelper.ApiGetRawMaterialAsDictionary();

            foreach (var workOrderPm in workOrderPMs)
            {
                AssignChildWorkOrderInfoIfWorkOrderIsAParent(workOrderPm, childWorkOrdersByParentId);
                AssignAdditionalInformationForWorkOrder(workOrderPm);
                AssignRawMaterialInfoToWorkOrderPm(workOrderPm, rawMaterialDict);
                AssignPONumberToWorkOrder(workOrderPm);
            }

            AssignPOnumberForChildWorkOrders(workOrderPMs);

            var telerikReports = workOrderPMs.Select(workOrderPM => CreateTelerikReportWorkOrder(workOrderPM)).ToList();

            return telerikReports;

        }

        private async Task<List<WorkOrder>> GetWorkOrdersAndItsChilds(int parentId)
        {
            List<WorkOrder> allWorkOrdersUnderParentWorkOrder = new List<WorkOrder>();

            Stack<WorkOrder> stack = new Stack<WorkOrder>();

            var parentWorkOrder = (await _workOrderRepository.GetWorkOrders(parentId))?.FirstOrDefault();

            if (parentWorkOrder == null) return null;

            allWorkOrdersUnderParentWorkOrder.Add(parentWorkOrder);
            stack.Push(parentWorkOrder);

            while (stack.Count > 0)
            {
                var workOrder = stack.Pop();
                var childs = _workOrderRepository
                    .GetQuery(x => x.ParentWorkOrderId != null && x.ParentWorkOrderId == workOrder.Id)
                    .Include(wo => wo.WorkOrderDetails)
                    .Include(wo => wo.WorkOrderMaterials);

                if (childs.Count() > 0)
                {
                    var childAsList = childs.ToList();

                    allWorkOrdersUnderParentWorkOrder.AddRange(childAsList);
                    await childs.ForEachAsync(childWorkOrderPm =>
                    {
                        stack.Push(childWorkOrderPm);
                    });

                }
            }

            return allWorkOrdersUnderParentWorkOrder;
        }

        private Dictionary<int, List<WorkOrder>> SortChildWorkOrdersParentId(List<WorkOrder> workOrders)
        {
            var childWorkOrdersByParentId = new Dictionary<int, List<WorkOrder>>();

            workOrders.ForEach(workOrder =>
            {
                if (workOrder.ParentWorkOrderId != null)
                {
                    var parentId = (int) workOrder.ParentWorkOrderId;

                    if (childWorkOrdersByParentId.ContainsKey((int)parentId) == false)
                    {
                        childWorkOrdersByParentId.Add(parentId, new List<WorkOrder> { workOrder });
                    }
                    else
                    {
                        childWorkOrdersByParentId[parentId].Add(workOrder);
                    }
                }
            });

            return childWorkOrdersByParentId;
        }

        private TelerikReportWorkOrder CreateTelerikReportWorkOrder(WorkOrderPM workOrderPM)
        {
            var result = new TelerikReportWorkOrder { WorkOrderDetails = workOrderPM };

            if (workOrderPM.RouteId > 0)
            {
                var route = _routings.FirstOrDefault(routing => routing.Id == workOrderPM.RouteId);
                result.RouteOperations = route?.RouteOperationPMs;
            }

            return result;
        }

        #region Assign Information to Work Order

        private void AssignChildWorkOrderInfoIfWorkOrderIsAParent(
            WorkOrderPM workOrderPm, Dictionary<int, List<WorkOrder>> childWorkOrdersByParentId
        )
        {
            if (childWorkOrdersByParentId.ContainsKey(workOrderPm.Id))
            {
                var childWorkOrders = childWorkOrdersByParentId[workOrderPm.Id];
                workOrderPm.ChildWorkOrders = WorkOrderMapper.ToPresentationModels(childWorkOrders).ToList();

                foreach (var child in workOrderPm.ChildWorkOrders)
                {
                    AssignAdditionalInformationForWorkOrder(child);
                }

                workOrderPm.NoofChildWOs = childWorkOrders.Count();
            }
        }

        private void AssignAdditionalInformationForWorkOrder(WorkOrderPM workOrderPm)
        {
            AssignProductInfoToWorkOrderPm(workOrderPm, _items);
            AssignProductInfoToWorkOrderUsingItsParentWorkOrderInfo(workOrderPm);
            AssignProductInfoToWorkOrderLines(workOrderPm, _items);

            AssignCustomerInfoToWorkOrderPm(workOrderPm, _customers);
            AssignRoutingInfoToWorkOrderPm(workOrderPm, _routings);
            AssignLocationInfoToWorkOrderPm(workOrderPm, _locations);
        }

        private void AssignLocationInfoToWorkOrderPm(WorkOrderPM workOrderPm, List<BasePM> _locations)
        {
            if (workOrderPm.LocationId != null)
            {
                workOrderPm.Location = _locations.FirstOrDefault(x => x.Id == (workOrderPm.LocationId ?? 0));
            }
        }

        private void AssignProductInfoToWorkOrderPm(WorkOrderPM workOrderPm, List<IdNamePM> _items)
        {
            var product = _items.FirstOrDefault(x => x.Id == workOrderPm.ProductId);
            if (product != null)
            {
                workOrderPm.ProductName = product.Description;
                workOrderPm.ProductNo = product.Name;
                workOrderPm.ProductionYield = (decimal?)product.Float1;
                workOrderPm.ProductFamily = product.String1;
            }
        }

        private void AssignCustomerInfoToWorkOrderPm(WorkOrderPM workOrderPm, List<BasePM> _customers)
        {
            if (workOrderPm.CustomerId != null)
            {
                workOrderPm.Customer = _customers.FirstOrDefault(x => x.Id == (workOrderPm.CustomerId ?? 0));
            }
        }

        private void AssignProductInfoToWorkOrderUsingItsParentWorkOrderInfo(WorkOrderPM workOrderPm)
        {
            if (workOrderPm.ParentWorkOrderId != null && workOrderPm.ParentWorkOrderId > 0)
            {
                var parentWO = _workOrderRepository.GetById(workOrderPm.ParentWorkOrderId ?? 0);
                if (parentWO != null && parentWO.ProductId > 0)
                {
                    var _items = ApiHelper.ApiGetProducts($"{workOrderPm.ProductId}");
                    var assembly = _items.FirstOrDefault(x => x.Id == parentWO.ProductId);

                    if (assembly != null)
                    {
                        workOrderPm.AssemblyNo = assembly.Name;
                        workOrderPm.AssemblyName = assembly.Description;
                    }
                }
            }
        }

        private void AssignProductInfoToWorkOrderLines(WorkOrderPM workOrderPm, List<IdNamePM> items)
        {
            var product = items.FirstOrDefault(x => x.Id == workOrderPm.ProductId);

            foreach (WorkOrderLinePM workOrderLinePM in workOrderPm.WorkOrderLines)
            {
                if (workOrderLinePM.ItemId == null) continue;

                if (product != null && workOrderLinePM.ItemId == product.Id)
                {
                    workOrderLinePM.ProductName = product.Name;
                }
                else
                {
                    var item = items.FirstOrDefault(x => x.Id == (workOrderLinePM.ItemId ?? 0));
                    if (item != null) workOrderLinePM.ProductName = item.Name;
                }
            }
        }

        private void AssignRoutingInfoToWorkOrderPm(WorkOrderPM workOrderPm, List<RoutePM> routings)
        {
            if (workOrderPm.RouteId != null)
            {
                var route = _routings.FirstOrDefault(x => x.Id == (workOrderPm.RouteId ?? 0));

                if (route != null)
                {
                    workOrderPm.RouteName = route.Name;
                    workOrderPm.IsRouteConfirmed = true;
                }

            }
        }

        private void AssignRawMaterialInfoToWorkOrderPm(
            WorkOrderPM workOrderPm, Dictionary<int, RawMaterialPM> rawMaterialDict
        )
        {
            foreach (var workOrderMaterial in workOrderPm.WorkOrderMaterials)
            {
                var id = workOrderMaterial.MaterialId;

                if (rawMaterialDict.ContainsKey(id))
                {
                    var rawMaterial = rawMaterialDict[id];

                    workOrderMaterial.MaterialName = rawMaterial.RawMaterialName;
                    workOrderMaterial.Description = rawMaterial.RawMaterialDescription;
                    workOrderMaterial.Type = rawMaterial.RawMaterialType;
                    workOrderMaterial.Grade = rawMaterial.Grade;
                }
            }
        }

        private void AssignPONumberToWorkOrder(WorkOrderPM workOrderPm)
        {
            foreach (WorkOrderLinePM workOrderLinePM in workOrderPm.WorkOrderLines)
            {
                WorkOrderLinePM pm = workOrderLinePM;
                if (pm.SalesOrderLineId != null)
                {
                    var so = _salesOrder.FirstOrDefault(x => x.SalesOrderLines.Any(y => y.Id == (pm.SalesOrderLineId ?? 0)));
                    SalesOrderLinePM sol = null;

                    if (so != null)
                    {
                        sol = so.SalesOrderLines.FirstOrDefault(y => y.Id == (pm.SalesOrderLineId ?? 0));
                    }

                    if (so != null && sol != null)
                    {
                        workOrderLinePM.SalesOrderNumber = so.SalesOrderNumber;
                        workOrderLinePM.SalesOrderLineNumber = sol.LineNumber ?? 0;

                        workOrderPm.PONumbers = string.IsNullOrWhiteSpace(workOrderPm.PONumbers) ? so.SalesOrderNumber : workOrderPm.PONumbers + "; " + so.SalesOrderNumber;
                        workOrderPm.CommittedDeliveryDate = ((DateTime)sol.DueDate).ToString("dd/MM/yyyy");
                    }
                }
            }
        }

        private void AssignPOnumberForChildWorkOrders(IEnumerable<WorkOrderPM> workOrderPms)
        {
            foreach (WorkOrderPM workOrderPm in workOrderPms.OrderBy(x => x.WorkOrderNumber))
            {
                if (workOrderPm.WorkOrderLines == null || workOrderPm.WorkOrderLines.Count() == 0)
                {
                    var parentWO = workOrderPms.FirstOrDefault(wo => wo.Id == workOrderPm.ParentWorkOrderId);

                    if (parentWO != null)
                    {
                        workOrderPm.PONumbers = parentWO.PONumbers;
                        workOrderPm.CommittedDeliveryDate = parentWO.CommittedDeliveryDate;
                    }
                    else
                    {
                        var parentWorkOrderId = workOrderPm.ParentWorkOrderId;
                        WorkOrder wo = null;
                        while (parentWorkOrderId > 0)
                        {
                            wo = _workOrderRepository.GetById(parentWorkOrderId ?? 0);
                            parentWorkOrderId = wo?.ParentWorkOrderId ?? 0;
                        }

                        if (wo != null)
                        {
                            var woPM = WorkOrderMapper.ToPresentationModel(wo);
                            woPM.WorkOrderLines = WorkOrderLineMapper.ToPresentationModels(wo.WorkOrderDetails).ToList();

                            AssignAdditionalInformationForWorkOrder(woPM);
                            workOrderPm.PONumbers = woPM.PONumbers;
                            workOrderPm.CommittedDeliveryDate = woPM.CommittedDeliveryDate;
                        }
                    }
                }
            }
        }

        #endregion

        #region Get Data
        private void GetAllRequiredWorkOrderDataForReport(List<WorkOrder> workOrders)
        {
            GetWorkOrderProductData(workOrders);
            GetWorkOrderCustomerData(workOrders);
            GetWorkOrderRoutingData(workOrders);

            GetWorkOrderLocationData(workOrders);
            GetWorkOrderSalesOrderData(workOrders);
        } 

        private void GetWorkOrderProductData(List<WorkOrder> workOrders)
        {
            var itemIds = workOrders.Select(x => x.ProductId).Distinct().ToList();
            var materialIds = workOrders.SelectMany(x => x.WorkOrderMaterials.Select(y => y.MaterialId)).Distinct().ToList();

            _items = ApiHelper.ApiGetProducts(string.Join(",", itemIds.Concat(materialIds)));
        }

        private void GetWorkOrderCustomerData(List<WorkOrder> workOrders)
        {
            var customerIds = workOrders.Select(x => x.CustomerId).Distinct().ToList();
            _customers = ApiHelper.ApiGetCustomers(string.Join(",", customerIds));
        }

        private void GetWorkOrderRoutingData(List<WorkOrder> workOrders)
        {
            var routeIds = workOrders.Select(x => x.RouteId ?? 0).Distinct().ToList();
            _routings = ApiHelper.ApiGetRoutes(routeIds);
        }

        private void GetWorkOrderLocationData(List<WorkOrder> workOrders)
        {
            var locationIds = workOrders.Select(x => x.LocationId ?? 0).Distinct().ToList();
            _locations = ApiHelper.ApiGetLocations(string.Join(",", locationIds));
        }

        private void GetWorkOrderSalesOrderData(List<WorkOrder> workOrders)
        {
            var salesOrderLineIds = workOrders.SelectMany(x => x.WorkOrderDetails.Select(y => y.SalesOrderLineId ?? 0).ToList()).Distinct().ToList();
            _salesOrder = ApiHelper.ApiGetSalesOrders(string.Join(",", salesOrderLineIds));
        }

        #endregion  

    }

}
