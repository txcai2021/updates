﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace SIMTech.APS.Customer.API.Repository
{
    using SIMTech.APS.Customer.API.Models;
    using SIMTech.APS.Customer.API.DBContext;
    using SIMTech.APS.Repository;

    public class CustomerRepository : Repository<Customer>,  ICustomerRepository
    {
        private readonly CustomerContext _dbContext;
        public CustomerRepository(CustomerContext context) : base(context) { _dbContext = context; }
       
    }
}
