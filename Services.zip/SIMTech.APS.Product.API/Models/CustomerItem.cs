﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.Product.API.Models
{
    using SIMTech.APS.Models;
    public partial class CustomerItem : BaseEntity
    {
        public string CustomerItemName { get; set; }
        public int CustomerId { get; set; }
        public int ItemId { get; set; }
        public int? ParentItemId { get; set; }
        public decimal? UnitPrice { get; set; }
        public int? InternalTat { get; set; }
        public int? ExternalTat { get; set; }
        public int? PriceUomId { get; set; }
        public string String1 { get; set; }
        public string String2 { get; set; }
        public string String3 { get; set; }
        public string String4 { get; set; }
        public string String5 { get; set; }
        public string String6 { get; set; }
        public string String7 { get; set; }
        public string String8 { get; set; }
        public string MaxString1 { get; set; }
        public string MaxString2 { get; set; }
        public string MaxString3 { get; set; }
        public int? Int1 { get; set; }
        public int? Int2 { get; set; }
        public decimal? Int3 { get; set; }
        public int? Int4 { get; set; }
        public double? Float1 { get; set; }
        public double? Float2 { get; set; }
        public bool? Flag1 { get; set; }
        public bool? Flag2 { get; set; }
        public bool? Flag3 { get; set; }
        

        public virtual Item Item { get; set; }
    }
}
