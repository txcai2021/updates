﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.Location.API.Models
{
    using SIMTech.APS.Models;
    public  class UserProductLine : BaseEntity
    {
        public int UserId { get; set; }
        public int ProductLineId { get; set; }
         

        public virtual Location ProductLine { get; set; }
    }
}
