﻿using System.Collections.Generic;
using System.Linq;
using SIMTech.APS.Product.Web.PresentationModel;
using SIMTech.APS.Security.Business;

namespace SIMTech.APS.Product.Web.Mappers
{
    public static class UserMapper
    {
        public static IEnumerable<UserPM> ToPresentationModels(IEnumerable<User> users)
        {
            if (users == null) return null;
            return users.Select(ToPresentationModel).ToList();
        }

        public static UserPM ToPresentationModel(User user)
        {
            if (user == null) return null;

            return new UserPM
            {
                UserId = user.UserId,
                Name = user.UserName,
                Comment = user.Comment,
                FirstName = user.FirstName,
                LastName = user.LastName,
            };
        }

        public static IEnumerable<User> FromPresentationModels(IEnumerable<UserPM> userPMs)
        {
            if (userPMs == null) return null;
            return userPMs.Select(FromPresentationModel).ToList();
        }

        public static User FromPresentationModel(UserPM userPM)
        {
            if (userPM == null) return null;

            return new User
            {
                UserId = userPM.UserId,
                UserName = userPM.Name,
                Comment = userPM.Comment,
                FirstName = userPM.FirstName,
                LastName = userPM.LastName,
            };
        }
    }
}
