﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.Permission.API.Models
{
    using SIMTech.APS.Models;
    public partial class UserRole :BaseEntity
    {

        public int UserId { get; set; }
        public int RoleId { get; set; }


        public virtual Role Role { get; set; }
    }
}
