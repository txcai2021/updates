﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SIMTech.APS.Scheduling.API.PresentationModels
{
    public class LateJob
    {
        public int WorkOrderId { get; set; }
        public string WorkOrderNumber { get; set; }
        public string PartNo { get; set; }
        public DateTime? DueDate { get; set; }
        public string LateOperation { get; set; }
        public DateTime CompletionDate { get; set; }
        public Double Quantity { get; set; }
        public string Remarks { get; set; }

    }

}
