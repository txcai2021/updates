﻿using System.Collections.Generic;
using System.Linq;


namespace SIMTech.APS.Product.Web.Mappers
{
    using SIMTech.APS.Product.API.Models;
    using SIMTech.APS.Product.API.PresentationModels;
    public class KitTypeMapper
    {
        public static IEnumerable<KitTypePM> ToPresentationModels(IEnumerable<Item> kitTypes)
        {
            if (kitTypes == null) return null;
            return kitTypes.Select(ToPresentationModel);
        }

        public static KitTypePM ToPresentationModel(Item kitType)
        {
            if (kitType == null) return null;

            KitTypePM kitTypePM = new KitTypePM
            {
               
                Category = string.IsNullOrEmpty(kitType.Category) ? string.Empty : kitType.Category,
                Description = string.IsNullOrEmpty(kitType.Description) ? string.Empty : kitType.Description,
                Id = kitType.Id,
                Name = string.IsNullOrEmpty(kitType.ItemName) ? string.Empty : kitType.ItemName,
                ProductionYield = (decimal?)kitType.Float1,
                NoOfCustomers = kitType.CustomerItems.Count(ci => ci.Float2 == null),
                NoOfParts = kitType.BillOfMaterialComponents.Count(bom=>!bom.Component.Category.Equals("RawMaterial")),
                UnitPrice = kitType.UnitPrice,
             
                //RouteId=kitType.Int5,
                Priority = kitType.Int6,
                QtyPerLot = kitType.Int7,
                //MinQty = kitType.Int8,
                //MaxQty = kitType.Int9,
                CustomerId = kitType.Int10,

                PartFamily = kitType.Group1,
                BuyFlag = string.IsNullOrEmpty(kitType.Group2) ? false : (kitType.Group2 == "B" ? true : false),
                NoActionFlag = string.IsNullOrEmpty(kitType.Group2) ? false : (kitType.Group2 == "N" ? true : false),
                Inactive = string.IsNullOrEmpty(kitType.Group3) ? false : (kitType.Group3 == "T" ? true : false),

              

                FGDimension = string.IsNullOrEmpty(kitType.String4) ? string.Empty : kitType.String4,
                Revision = kitType.String9,

                Remarks = kitType.MaxString1,

                PartGrpType = kitType.Flag2,

                //DefaultCustomerKitCode = string.IsNullOrEmpty(kitType.String1) ? string.Empty : kitType.String1,
                //DefaultExternalTat = kitType.Int5,
                //DefaultInternalTat = kitType.Int6,
                //NoOfKits = kitType.Item1.Count,
            };

            if (kitType.PictureId != null && kitType.PictureId>0)
            {
                //kitTypePM.ThumbnailImage = kitType.Picture.ThumbNailImage;
                //kitTypePM.ThumbnailImageFileName = kitType.Picture.ThumbnailImageFileName;
            }
            return kitTypePM;

        }

        public static IEnumerable<Item> FromPresentationModels(IEnumerable<KitTypePM> kitTypePms)
        {
            if (kitTypePms == null) return null;
            return kitTypePms.Select(FromPresentationModel);
        }

        public static Item FromPresentationModel(KitTypePM kitTypePM)
        {
            if (kitTypePM == null) return null;

            return new Item
            {                
                Category = kitTypePM.Category,
                Description = kitTypePM.Description,
                Id = kitTypePM.Id,
                ItemName = kitTypePM.Name,
                UnitPrice = kitTypePM.UnitPrice,
               
                Group1 = kitTypePM.PartFamily,
                //Group2 = kitTypePM.BuyFlag ? "B" : "M",
                Group2 = kitTypePM.BuyFlag ? "B" :kitTypePM.NoActionFlag ? "N" : "M" ,
                Group3 = kitTypePM.Inactive ? "T" : "F",
                //Int9 = kitTypePM.MaxQty,
                //Int8 = kitTypePM.MinQty,
                Int6 = kitTypePM.Priority ,
                Int7 = kitTypePM.QtyPerLot,
                Int10 = kitTypePM.CustomerId,

                String4 = kitTypePM.FGDimension,
                String9 = kitTypePM.Revision,

                MaxString1 = kitTypePM.Remarks,

                Flag2 = kitTypePM.PartGrpType,

                Float1 = (double?)kitTypePM.ProductionYield,


                //Int5 = kitTypePM.DefaultExternalTat,
                //Int6 = kitTypePM.DefaultInternalTat,
                //String1 = kitTypePM.DefaultCustomerKitCode,
            };
        }

        public static void UpdatePresentationModel(KitTypePM kitTypePM, Item kitType)
        {
            if (kitTypePM == null || kitType == null) return;

            kitTypePM.Category = string.IsNullOrEmpty(kitType.Category) ? string.Empty : kitType.Category;
            kitTypePM.Description = string.IsNullOrEmpty(kitType.Description) ? string.Empty : kitType.Description;
            kitTypePM.Id = kitType.Id;
            kitTypePM.Name = string.IsNullOrEmpty(kitType.ItemName) ? string.Empty : kitType.ItemName;
            kitTypePM.UnitPrice = kitType.UnitPrice;
            
            kitTypePM.PartFamily = kitType.Group1;
            kitTypePM.BuyFlag = string.IsNullOrEmpty(kitType.Group2) ? false : (kitType.Group2 == "B" ? true : false);
            kitTypePM.NoActionFlag = string.IsNullOrEmpty(kitType.Group2) ? false : (kitType.Group2 == "N" ? true : false);
            kitTypePM.Inactive = string.IsNullOrEmpty(kitType.Group3) ? false : (kitType.Group3 == "T" ? true : false);

            //kitTypePM.RouteId = kitType.Int5;
            kitTypePM.Priority  = kitType.Int6;
            kitTypePM.QtyPerLot = kitType.Int7;
            kitTypePM.CustomerId = kitType.Int10; 

            kitTypePM.FGDimension = string.IsNullOrEmpty(kitType.String4) ? string.Empty : kitType.String4;
            kitTypePM.Revision = kitType.String9;
            kitTypePM.Remarks = kitType.MaxString1;

            kitTypePM.PartGrpType = kitType.Flag2;

            kitTypePM.ProductionYield = (decimal?)kitType.Float1;
         

            //kitTypePM.MinQty = kitType.Int8;
            //kitTypePM.MaxQty = kitType.Int9;

            //kitTypePM.DefaultCustomerKitCode = string.IsNullOrEmpty(kitType.String1) ? string.Empty : kitType.String1;
            //kitTypePM.DefaultExternalTat = kitType.Int5;
            //kitTypePM.DefaultInternalTat = kitType.Int6;
        }
    }
}
