﻿using System.ComponentModel.DataAnnotations;

namespace SIMTech.APS.Permission.API.PresentationModels
{
    public class ModuleMenuPM
    {
        [Required]
        public string RoleName { get; set; }

        [Required]      
        public string ModuleName { get; set; }
    }
}
