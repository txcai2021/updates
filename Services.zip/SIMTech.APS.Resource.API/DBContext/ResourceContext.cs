﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace SIMTech.APS.Resource.API.DBContext
{
    using SIMTech.APS.Resource.API.Models;
    public partial class ResourceContext : DbContext
    {
        public ResourceContext()
        {
        }

        public ResourceContext(DbContextOptions<ResourceContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Equipment> Equipment { get; set; }
        public virtual DbSet<EquipmentBlockOut> EquipmentBlockOuts { get; set; }
        public virtual DbSet<EquipmentParameter> EquipmentParameters { get; set; }
        public virtual DbSet<FixtureSetting> FixtureSettings { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<Equipment>(entity =>
            {
                entity.HasIndex(e => new { e.EquipmentName, e.Type }, "IX_Resource_ResourceNameType")
                    .IsUnique();

                entity.Property(e => e.CalendarId).HasColumnName("CalendarID");

                entity.Property(e => e.Category).HasMaxLength(50);

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Description).HasMaxLength(250);

                entity.Property(e => e.EquipmentName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.LocationId).HasColumnName("LocationID");

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn)
                    .HasColumnType("datetime")
                    .HasComputedColumnSql("(getdate())", false);

                entity.Property(e => e.ParentEquipmentId).HasColumnName("ParentEquipmentID");

                entity.Property(e => e.String1).HasMaxLength(50);

                entity.Property(e => e.String2).HasMaxLength(50);

                entity.Property(e => e.Subcategory).HasMaxLength(50);
              
            });

            modelBuilder.Entity<EquipmentBlockOut>(entity =>
            {
                entity.ToTable("EquipmentBlockOut");

                entity.Property(e => e.BlockOutType)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EndDate).HasColumnType("datetime");

                entity.Property(e => e.EquipmentId).HasColumnName("EquipmentID");

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn).HasColumnType("datetime");

                entity.Property(e => e.StartDate).HasColumnType("datetime");


                entity.HasOne(d => d.Equipment)
                    .WithMany(p => p.EquipmentBlockOuts)
                    .HasForeignKey(d => d.EquipmentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_EquipmentBlockOut_Equipment");
            });

            modelBuilder.Entity<EquipmentParameter>(entity =>
            {
                entity.ToTable("EquipmentParameter");

                entity.HasIndex(e => new { e.EquipmentId, e.ParameterId }, "IX_EquipmentParameter_EquipmentIDParameterID")
                    .IsUnique();

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EquipmentId).HasColumnName("EquipmentID");

                entity.Property(e => e.MaxValue).HasMaxLength(50);

                entity.Property(e => e.MinValue).HasMaxLength(50);

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn).HasColumnType("datetime");

                entity.Property(e => e.ParameterId).HasColumnName("ParameterID");

                entity.Property(e => e.Value).HasMaxLength(50);


                entity.HasOne(d => d.Equipment)
                    .WithMany(p => p.EquipmentParameters)
                    .HasForeignKey(d => d.EquipmentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_EquipmentParameter_Equipment");
            });

            modelBuilder.Entity<FixtureSetting>(entity =>
            {
                entity.ToTable("FixtureSetting");
              
                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EquipmentId).HasColumnName("EquipmentID");

                entity.Property(e => e.ProductFamily).HasMaxLength(50);
             
                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn).HasColumnType("datetime");

                entity.Property(e => e.FixtureId).HasColumnName("FixtureId");

            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
