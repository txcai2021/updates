﻿namespace SIMTech.APS.DeliveryOrder.API.Enums
{
    public enum EDeliveryOrderType : byte
    {
        PartLevel = 0,
        POLevel = 1,
        KitLevel = 2,
    }
}
