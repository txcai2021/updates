﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel.DomainServices.Hosting;
using System.ServiceModel.DomainServices.Server;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using SIMTech.APS.Order.Business;
using SIMTech.APS.Product.Business;
using SIMTech.APS.Product.Web.Mappers;
using SIMTech.APS.Product.Web.PresentationModel;
using SIMTech.APS.Repository;
using SIMTech.APS.Utility;

namespace SIMTech.APS.Product.Web.Services
{
    [EnableClientAccess]
    public class CustomerItemDomainService : DomainService
    {
        private readonly ExceptionManager _exceptionManager;
        private readonly IRepository _productRepository;
        private readonly IRepository _orderRepository;

        public CustomerItemDomainService()
        {
            _exceptionManager = EnterpriseLibraryContainer.Current.GetInstance<ExceptionManager>();
            _productRepository = _exceptionManager.Process(() => IoCWorker.Resolve<IRepository>("Product"), "ExceptionShielding");
            _orderRepository = _exceptionManager.Process(() => IoCWorker.Resolve<IRepository>("Order"), "ExceptionShielding");
        }

        public IEnumerable<CustomerItemPM> GetCustomerItems()
        {
            IEnumerable<CustomerItem> customerItems = _exceptionManager.Process(() => _productRepository.GetQuery<CustomerItem>(), "ExceptionShielding");
            List<CustomerItemPM> customerItemPms = CustomerItemMapper.ToPresentationModels(customerItems).ToList();

            foreach (CustomerItemPM customerItemPM in customerItemPms)
            {
                customerItemPM.CustomerCode = _exceptionManager.Process(() => _orderRepository.GetByKey<Customer>(customerItemPM.CustomerId).CustomerName, "ExceptionShielding");
            }

            return customerItemPms;
        }

        public IEnumerable<CustomerItemPM> GetCustomerItemsForKitTypes()
        {
            IEnumerable<CustomerItem> customerItems = _exceptionManager.Process(() => _productRepository.GetQuery<CustomerItem>(ci => ci.Item.Category.Equals("ProductHierarchyLevelR") && ci.Float2 == null).OrderBy (ci=>ci.Item.ItemName), "ExceptionShielding");
            List<CustomerItemPM> customerItemPms = CustomerItemMapper.ToPresentationModels(customerItems).ToList();

            foreach (CustomerItemPM customerItemPM in customerItemPms)
            {
                customerItemPM.CustomerCode = _exceptionManager.Process(() => _orderRepository.GetByKey<Customer>(customerItemPM.CustomerId).CustomerName, "ExceptionShielding");
            }

            return customerItemPms;
        }

        public IEnumerable<CustomerItemPM> GetCustomerItemsForPartTypes(string searchText)
        {
            IEnumerable<CustomerItem> customerItems;
            List<CustomerItemPM> customerItemPms;

            if (searchText == "")
            {
                customerItems = _exceptionManager.Process(() => _productRepository.GetQuery<CustomerItem>(ci => ci.Item.Category.Equals("ProductHierarchyLevelR")), "ExceptionShielding");
                customerItemPms = CustomerItemMapper.ToPresentationModels(customerItems).ToList();
            }
            else
            {
                //IEnumerable<int> partTypeID = _exceptionManager.Process(() => _productRepository.GetQuery<Item>(it => it.Category.Equals("ProductHierarchyLevelB") && it.ItemName.Contains (searchText) ).Select(it => it.ItemID), "ExceptionShielding");
                List<int> kitTypeIDs = _exceptionManager.Process(() => _productRepository.GetQuery<BillOfMaterial>(bom => bom.Item.Category.Equals("ProductHierarchyLevelB") && bom.Item.ItemName.Contains(searchText)).Select(bom => bom.Item1.ItemID  ).Distinct ().ToList(), "ExceptionShielding");
                customerItems = _exceptionManager.Process(() => _productRepository.GetQuery<CustomerItem>(ci => kitTypeIDs.Contains (ci.ItemID)), "ExceptionShielding");
                customerItemPms = CustomerItemMapper.ToPresentationModels(customerItems).ToList();
            }

            //IEnumerable<CustomerItem> customerItems = _exceptionManager.Process(() => _productRepository.GetQuery<CustomerItem>(ci => ci.Item.Category.Equals("ProductHierarchyLevelR")), "ExceptionShielding");
            //List<CustomerItemPM> customerItemPms = CustomerItemMapper.ToPresentationModels(customerItems).ToList();

            foreach (CustomerItemPM customerItemPM in customerItemPms)
            {
                customerItemPM.CustomerCode = _exceptionManager.Process(() => _orderRepository.GetByKey<Customer>(customerItemPM.CustomerId).CustomerName, "ExceptionShielding");
            }

            return customerItemPms;
        }

        public IEnumerable<CustomerItemPM> GetCustomerItemsByKitType(int kitTypeId)
        {
            IEnumerable<CustomerItem> customerItems = _exceptionManager.Process(() => _productRepository.GetQuery<CustomerItem>(ci => ci.ItemID == kitTypeId), "ExceptionShielding");
            List<CustomerItemPM> customerItemPms = CustomerItemMapper.ToPresentationModels(customerItems).ToList();

            foreach (CustomerItemPM customerItemPM in customerItemPms)
            {
                customerItemPM.CustomerCode = _exceptionManager.Process(() => _orderRepository.GetByKey<Customer>(customerItemPM.CustomerId).CustomerName, "ExceptionShielding");
            }

            return customerItemPms;
        }

        public void AddCustomerItem(CustomerItemPM customerItemPM)
        {
            CustomerItem customerItem = CustomerItemMapper.FromPresentationModel(customerItemPM);
            customerItem.CreatedOn = DateTime.Today;

            _exceptionManager.Process(() =>
            {
                _productRepository.Add(customerItem);
                _productRepository.UnitOfWork.SaveChanges();
            }, "ExceptionShielding");

            CustomerItemMapper.UpdatePresentationModel(customerItemPM, customerItem);
        }

        public void UpdateCustomerItem(CustomerItemPM customerItemPM)
        {
            CustomerItem customerItem = CustomerItemMapper.FromPresentationModel(customerItemPM);
            CustomerItem existingCustomerItem = _exceptionManager.Process(() => _productRepository.GetByKey<CustomerItem>(customerItem.CustomerItemID), "ExceptionShielding");

            existingCustomerItem.CustomerID = customerItem.CustomerID;
            existingCustomerItem.ItemID = customerItem.ItemID;
            existingCustomerItem.ExternalTAT = customerItem.ExternalTAT;
            existingCustomerItem.InternalTAT = customerItem.InternalTAT;
            existingCustomerItem.String1 = customerItem.String1;
            existingCustomerItem.Int1 = customerItem.Int1;
            existingCustomerItem.Int2 = customerItem.Int2;
            existingCustomerItem.Int3 = customerItem.Int3;
            existingCustomerItem.Int4 = customerItem.Int4;
            existingCustomerItem.Float2 = customerItem.Float2;
            existingCustomerItem.UnitPrice = customerItem.UnitPrice;
            existingCustomerItem.Flag1 = customerItem.Flag1;
            existingCustomerItem.Float1 = customerItem.Float1;

            _exceptionManager.Process(() =>
            {
                _productRepository.Update(existingCustomerItem);
                _productRepository.UnitOfWork.SaveChanges();
            }, "ExceptionShielding");
        }

        public void DeleteCustomerItem(CustomerItemPM customerItemPM)
        {
            _exceptionManager.Process(() =>
            {
                _productRepository.Delete<CustomerItem>(ur => ur.CustomerItemID == customerItemPM.Id);
                _productRepository.UnitOfWork.SaveChanges();
            }, "ExceptionShielding");

        }

        [Invoke]
        public void UpdateCustomersForKitType(int kitTypeId, int[] assignedCustomers)
        {
            int[] customerIds = _productRepository.GetQuery<CustomerItem>(ci => ci.ItemID == kitTypeId).Select(ci => ci.CustomerID).ToArray();

            int[] removedCustomers = customerIds.Except(assignedCustomers).ToArray();

            foreach (int removedCustomer in removedCustomers)
            {
                _productRepository.Delete<CustomerItem>(ci => ci.ItemID == kitTypeId && ci.CustomerID == removedCustomer);
            }
            _productRepository.UnitOfWork.SaveChanges();

            for (int i = 0; i < assignedCustomers.Count(); i++)
            {
                int i1 = assignedCustomers[i];
                CustomerItem customerItem = _productRepository.First<CustomerItem>(ci => ci.ItemID == kitTypeId && ci.CustomerID == i1);

                if (customerItem == null)
                {
                    _productRepository.Add(new CustomerItem
                    {
                        ItemID = kitTypeId,
                        CustomerID = assignedCustomers[i],
                    });
                }
            }
            _productRepository.UnitOfWork.SaveChanges();
        }
    }
}
