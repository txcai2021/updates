﻿using System.ComponentModel.DataAnnotations;

namespace SIMTech.APS.Product.API.PresentationModels
{
    public class CustomerItemPM
    {
        [Key]
        public int Id { get; set; }

        public int CustomerId { get; set; }

        public string CustomerCode { get; set; }

        public int ItemId { get; set; }

        public int? SubItemId { get; set; }

        public string CustomerKitCode { get; set; }

        public string CustomerPartCode { get; set; }

        public int? CustomerItemNo { get; set; }
        
        public int? ExternalTat { get; set; }
        
        public int? InternalTat { get; set; }

        public int? MaxRecycleCount { get; set; }

        public int? MaxRefurbishmentCount { get; set; }

        public decimal? MaxRfHour { get; set; }

        public int? MaxWaferCount { get; set; }

        public bool? FiringProcess { get; set; }

        public decimal? UnitPrice { get; set; }
    }
}
