﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace SIMTech.APS.Operation.API.Mappers
{
    using SIMTech.APS.Setting.API.Models;
    using SIMTech.APS.PresentationModels;


    /// <summary>
    /// Maps  PMs (Presentation Models) to  BOs (Business Objects) and vice versa.
    /// </summary>
    public static class UoMMapper
    {
        

        /// <summary>
        /// Transforms list of CodeDetail BOs list of uom PMs.
        /// </summary>
        /// <param name="categorys">List of category BOs.</param>
        /// <returns>List of category PMs.</returns>
        public static IList<UoMPM> ToPresentationModels(IEnumerable<CodeDetail> uoms)
        {
            if (uoms == null) return null;
            return uoms.Select(u => ToPresentationModel(u)).ToList();
        }

        /// <summary>
        /// Transforms CodeDetail BO to uom PM.
        /// </summary>
        /// <param name="category">category BO.</param>
        /// <returns>category PM.</returns>
        public static UoMPM ToPresentationModel(CodeDetail uom)
        {
            if (uom == null) return null;
          
            return new UoMPM
            {
                Id = uom.Id,

                CodeTypeId = uom.CodeTypeId,
                Description = uom.Description,
                CodeNo = uom.CodeNo,

                CreatedDate = uom.CreatedOn,
                ModifiedDate = uom.ModifiedOn??DateTime.Now
               
            };
        }

        /// <summary>
        /// Transforms list of uom PMs list of CodeDetail BOs.
        /// </summary>
        /// <param name="categoryPMs">List of category PMs.</param>
        /// <returns>List of category BOs.</returns>
        public static IList<CodeDetail> FromPresentationModels(IEnumerable<UoMPM> uomPMs)
        {
            if (uomPMs == null) return null;
            return uomPMs.Select(u => FromPresentationModel(u)).ToList();
        }

        /// <summary>
        /// Transforms uom PM to CodeDetail BO.
        /// </summary>
        /// <param name="categoryPM">category PM.</param>
        /// <returns>CodeDetail BO.</returns>
        public static CodeDetail FromPresentationModel(UoMPM uomPM)
        {
            if (uomPM == null) return null;

            return new CodeDetail
            {
                Id = uomPM.Id,

                CodeTypeId = uomPM.CodeTypeId,
                Description = uomPM.Description,
                CodeNo = uomPM.CodeNo,

                CreatedOn = uomPM.CreatedDate,
                ModifiedOn = uomPM.ModifiedDate

            };
        }

        
      
    }
}
