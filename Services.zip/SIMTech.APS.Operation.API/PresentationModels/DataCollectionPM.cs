﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using SIMTech.APS.Resources;
using System.Collections.Generic;

namespace SIMTech.APS.Operation.API.PresentationModels
{
    public class DataCollectionPM 
    {
        public DataCollectionPM() 
        {
        }

        [Key]
        [Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
        public int Id { get; set; }

        [Display(ShortName = "Name", ResourceType = typeof(SharedResources), Name = "Name", Order = 0)]
        [Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
        [StringLength(50)]
        //[RegularExpression("^[a-zA-Z0-9_]*$", ErrorMessageResourceName = "ValidationErrorInvalidName", ErrorMessageResourceType = typeof(ErrorResources))]
        public string Name { get; set; }

        public byte Type { get; set; }

        public string DataType { get; set; }

        public string DefaultValue { get; set; }

        public string MinValue { get; set; }

        public string MaxValue { get; set; }

        public string UoM { get; set; }

        public string DataTypeName { get; set; }

        //public int NoofReading { get; set; }

        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }

        #region Auxiliary methods

        #endregion
    }
}
