﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Collections.ObjectModel;

namespace SIMTech.APS.Permission.API.Repository
{
    using SIMTech.APS.Repository;
    using SIMTech.APS.Permission.API.Models;
    using SIMTech.APS.Permission.API.DBContext;
    using SIMTech.APS.Permission.API.Mappers;
    using SIMTech.APS.Permission.API.PresentationModels;

    public class MenuRepository : Repository<Menu>, IMenuRepository
    {
        private readonly PermissionContext _dbContext;

        public MenuRepository(PermissionContext dbContext) : base(dbContext)
        {
            _dbContext = dbContext;
        }

        
    }
}
