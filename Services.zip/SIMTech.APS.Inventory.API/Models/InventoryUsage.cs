﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

#nullable disable

namespace SIMTech.APS.Inventory.API.Models
{
    using SIMTech.APS.Models;

    [Table("InventoryUsage")]
    public partial class InventoryUsage : BaseEntity
    {
        
        [Column("InventoryID")]
        public int InventoryId { get; set; }
        public int UsageType { get; set; }
        [Column("UsedByOrderID")]
        public int UsedByOrderId { get; set; }
        [Column(TypeName = "decimal(18, 3)")]
        public decimal? Quantity { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime DateOut { get; set; }
        [StringLength(50)]
        public string Status { get; set; }
        [StringLength(250)]
        public string Remarks { get; set; }      

        [ForeignKey(nameof(InventoryId))]
        [InverseProperty("InventoryUsages")]
        public virtual Inventory Inventory { get; set; }
    }
}
