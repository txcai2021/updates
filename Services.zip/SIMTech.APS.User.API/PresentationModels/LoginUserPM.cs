﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ServiceModel;

namespace SIMTech.APS.User.API.PresentationModels
{
    public class LoginUserPM
    {
        [Key]
        public string Name { get; set; }

        public string UserName { get; set; }

        public string PasswordSalt { get; set; }

        public string PasswordHash { get; set; }

        public IEnumerable<string> Roles { get; set; }

        public IEnumerable<string> Modules { get; set; }

        public string ChangePasswordError { get; set; }
        public DateTime? LastPassChangeDate { get; set; }
    }
}
