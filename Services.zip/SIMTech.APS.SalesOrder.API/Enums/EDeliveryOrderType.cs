﻿namespace SIMTech.APS.SalesOrder.API.Enums
{
    public enum EDeliveryOrderType : byte
    {
        PartLevel = 0,
        POLevel = 1,
        KitLevel = 2,
    }
}
