﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace SIMTech.APS.DeliveryOrder.API.Repository
{
    using SIMTech.APS.DeliveryOrder.API.Models;
    using SIMTech.APS.DeliveryOrder.API.DBContext;
    using SIMTech.APS.Repository;

    public class DeliveryOrderRepository : Repository<DeliveryOrder>,  IDeliveryOrderRepository
    {
        private readonly DeliveryOrderContext _dbContext;
        public DeliveryOrderRepository(DeliveryOrderContext context) : base(context) { _dbContext = context; }
       
    }
}
