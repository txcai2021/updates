﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using SIMTech.APS.Resources;

namespace SIMTech.APS.DeliveryOrder.API.PresentationModels
{
    using SIMTech.APS.DeliveryOrder.API.Enums;
    using SIMTech.APS.PresentationModels;

    public class DeliveryOrderPM
    {
        public DeliveryOrderPM()
        {
            DeliveryOrderLines = new List<DeliveryOrderLinePM>();
        }


        [Key]
        public int Id { get; set; }

        [Display(ShortName = "Deliver Order No", Name = "Deliver Order No")]
        public string DeliveryOrderNo { get; set; }

        public int? CustomerId { get; set; }
 
        [Display(ShortName = "Ship Address", Name = "Ship Address")]
        public string ShipToAddress { get; set; }

        [Display(ShortName = "No. of items", Name = "No. of  items")]
        public int count { get; set; }

        [Display(ShortName = "Total Qty", Name = "Total Qty")]
        public double?  TotalQty { get; set; }

        [Display(ShortName = "Delivery Date", Name = "Delivery Date")]
        public DateTime? OrderDate { get; set; }

        [Display(ShortName = "Remarks", Name = "Remarks")]
        public string Remarks { get; set; }

        public string CompanyNam { get; set; }

         [Display(ShortName = "PO Number", Name = "PO Number")]
        public string POList { get; set; }

         [Display(ShortName = "Part No", Name = "Part No")]
        public string PartNoList { get; set; }

         [Display(ShortName = "Part Name", Name = "Part Name")]
        public string PartNameList { get; set; }


        public string RegNo { get; set; }
        public bool? IsIncludeCustomizedReport { get; set; }
        public string InvoiceTOAddress { get; set; }        
        public string CompanyAddress { get; set; }
        public string CompanyName { get; set; }
       
        public string CompanyPhone { get; set; }
        public string Fax { get; set; }
        public string ContactNo { get; set; }
        public byte[] ImageSign { get; set; }
        public int? SignatureID { get; set; }
    
        public string WorkOrderNum { get; set; }
        public string WorkOrderList { get; set; }
        public string CreditTerms { get; set; }
        public string SCRNumber { get; set; }
        public string SCRNo { get; set; }
        public string LabelSCR { get; set; }
        public string WorkOrderNo { get; set; }
        public string PurchaseOrderNo { get; set; }
        public string Currency { get; set; }
        public string Title { get; set; }
        public string GatePassNO { get; set; }        
        public byte IsCustomerProductCode { get; set; }
        public EDeliveryOrderType Type { get; set; }
        public EDeliveryOrderStatus Status { get; set; }        
        public int? LocationId { get; set; }

        public int? SelAddressType { get; set; }

        public string address2 { get; set; }
        
        public IdNamePM Customer { get; set; }

        
        public IEnumerable<DeliveryOrderLinePM> DeliveryOrderLines { get; set; }

       
    }
}
