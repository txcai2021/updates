﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace SIMTech.APS.Picture.API.Repository
{
    using SIMTech.APS.Picture.API.Models;
    using SIMTech.APS.Picture.API.DBContext;
    using SIMTech.APS.Repository;

    public class PictureRepository : Repository<Picture>,  IPictureRepository
    {
        private readonly PictureContext _dbContext;
        public PictureRepository(PictureContext context) : base(context) { _dbContext = context; }
       
    }
}
