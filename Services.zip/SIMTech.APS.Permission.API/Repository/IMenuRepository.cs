﻿using System.Collections.Generic;

namespace SIMTech.APS.Permission.API.Repository
{
    using SIMTech.APS.Permission.API.Models;
    using SIMTech.APS.Permission.API.PresentationModels;
    using SIMTech.APS.Repository; 

    public interface IMenuRepository :  IRepository<Menu>
    {
    }

    
}
