﻿using System.ComponentModel.DataAnnotations;
using SIMTech.APS.Resources;
using System;
using System.Collections;
using System.Collections.Generic;

namespace SIMTech.APS.Location.API.PresentationModels
{
   
    public class CustomerPM 
    {
        [Key]
        public  int Id { get; set; }

        public string Code { get; set; }

        public  string Name { get; set; }

        public string Site { get; set; }

        public string Department { get; set; }

        public string Group { get; set; }

        public int? Priority { get; set; }

        public string Address { get; set; }

        public string Description { get; set; }


        public string ContactPerson { get; set; }

        public string Phone { get; set; }

        public string Email { get; set; }

        public string Fax { get; set; }



        public string RegNo { get; set; }

        public string GstRegno { get; set; }

      
        public string MaxString1 { get; set; }

        public string MaxString2 { get; set; }

        public string MaxString3 { get; set; }

        public string Category { get; set; }

        public int? PictureId { get; set; }

        public byte[] ThumbnailImage { get; set; }

        public string ThumbnailImageFileName { get; set; }
    }
}
