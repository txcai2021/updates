
namespace SIMTech.APS.Routing.API.Enums
{
    public enum EParameterType
    {
        PARAMETER,
        DATACOLLECTION,
	    CONTROLPARAMETER,
        STATUSPARAMETER,
        MEASUREPARAMETER
    }
}
