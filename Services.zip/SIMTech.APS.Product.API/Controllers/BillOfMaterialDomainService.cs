﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel.DomainServices.Hosting;
using System.ServiceModel.DomainServices.Server;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using SIMTech.APS.Product.Business;
using SIMTech.APS.Product.Web.Mappers;
using SIMTech.APS.Product.Web.PresentationModel;
using SIMTech.APS.Repository;
using SIMTech.APS.Utility;

namespace SIMTech.APS.Product.Web.Services
{
    [EnableClientAccess]
    public class BillOfMaterialDomainService : DomainService
    {
        private readonly ExceptionManager _exceptionManager;
        private readonly IRepository _productRepository;

        public BillOfMaterialDomainService()
        {
            _exceptionManager = EnterpriseLibraryContainer.Current.GetInstance<ExceptionManager>();
            _productRepository = _exceptionManager.Process(() => IoCWorker.Resolve<IRepository>("Product"), "ExceptionShielding");
        }

        public IQueryable<BillOfMaterialPM> GetBillOfMaterialsByKitType(int kitTypeId)
        {
            IEnumerable<BillOfMaterial> billOfMaterials = _exceptionManager.Process(() => _productRepository.GetQuery<BillOfMaterial>(bom => bom.ProductAssemblyId == kitTypeId), "ExceptionShielding");
            return BillOfMaterialMapper.ToPresentationModels(billOfMaterials).AsQueryable();
        }

        public IQueryable<BillOfMaterialPM> GetBillofMaterialsByProductId(int ProuductId, string category)
        {
            IEnumerable<BillOfMaterial> billOfMaterials;

            if (category.Equals ("M"))
                billOfMaterials = _exceptionManager.Process(() => _productRepository.GetQuery<BillOfMaterial>(bom => bom.ProductAssemblyId == ProuductId && bom.Item.Category.Equals ("RawMaterial") ), "ExceptionShielding");
            else
                billOfMaterials = _exceptionManager.Process(() => _productRepository.GetQuery<BillOfMaterial>(bom => bom.ProductAssemblyId == ProuductId && !bom.Item.Category.Equals ("RawMaterial") ), "ExceptionShielding");

            return BillOfMaterialMapper.ToPresentationModels(billOfMaterials).AsQueryable();
        }

         


        public BillOfMaterialPM GetBillOfMaterialByItemAndKitId(int componentId, int assemblyId)
        {
            BillOfMaterial billOfMaterial = _exceptionManager.Process(() => _productRepository.Single<BillOfMaterial>(bom => bom.ProductAssemblyId == assemblyId && bom.ComponentId == componentId), "ExceptionShielding");
            return BillOfMaterialMapper.ToPresentationModel(billOfMaterial);
        }

        [Query(HasSideEffects = true)]
        public IQueryable<BillOfMaterialPM> GetBillOfMaterialsByKitTypes(int[] kitTypeIds)
        {
            IEnumerable<BillOfMaterial> billOfMaterials = _exceptionManager.Process(() => _productRepository.GetQuery<BillOfMaterial>(bom => kitTypeIds.Contains(bom.ProductAssemblyId)), "ExceptionShielding");
            return BillOfMaterialMapper.ToPresentationModels(billOfMaterials).AsQueryable();
        }

        public IQueryable<BillOfMaterialPM> GetAllEntities(int kitTypeId)
        {
           
            IEnumerable<BillOfMaterial> billOfMaterials =null;
                
             if (kitTypeId==0)
             {
                 billOfMaterials = _exceptionManager.Process(() => _productRepository.GetAll<BillOfMaterial>(), "ExceptionShielding");
             }
             else
             {
                 List<int> itemIDs = new List<int>();
                 List<int> pendingItems = new List<int>();
                 itemIDs.Add(kitTypeId);
                 pendingItems.Add(kitTypeId);

                 while (pendingItems.Count > 0)
                 {
                     var itemId = pendingItems.First();
                     var componentIds = _productRepository.GetQuery<BillOfMaterial>(x => x.ProductAssemblyId == itemId).Select(x => x.ComponentId).ToList();

                     foreach (var componentId in componentIds)
                     {
                         itemIDs.Add(componentId);
                         pendingItems.Add(componentId);
                     }
                     pendingItems.Remove(itemId);
                 }
                 billOfMaterials = _exceptionManager.Process(() => _productRepository.GetQuery<BillOfMaterial>(x => itemIDs.Contains( x.ProductAssemblyId )), "ExceptionShielding");
             }
                 
            return BillOfMaterialMapper.ToPresentationModels(billOfMaterials).AsQueryable();           

        }

        public IQueryable<BillOfMaterialPM> GetAllBillOfMaterials()
        {
            IEnumerable<int> kitTypeIds = _productRepository.GetAll<CustomerItem>().Select(ci => ci.ItemID).Distinct();
            int kitTypeId = kitTypeIds.ElementAt(0);
            //IEnumerable<BillOfMaterial> billOfMaterials = _exceptionManager.Process(() => _productRepository.GetQuery<BillOfMaterial>(bom => kitTypeIds.Contains(bom.ProductAssemblyId)), "ExceptionShielding");
            IEnumerable<BillOfMaterial> billOfMaterials = _exceptionManager.Process(() => _productRepository.GetQuery<BillOfMaterial>(bom => bom.ProductAssemblyId == kitTypeId), "ExceptionShielding");
            return BillOfMaterialMapper.ToPresentationModels(billOfMaterials).AsQueryable();
        }

        public void AddBillOfMaterial(BillOfMaterialPM billOfMaterialPM)
        {
            BillOfMaterial billOfMaterial = BillOfMaterialMapper.FromPresentationModel(billOfMaterialPM);
            billOfMaterial.CreatedOn = DateTime.Today;

            _exceptionManager.Process(() =>
            {
                _productRepository.Add(billOfMaterial);
                _productRepository.UnitOfWork.SaveChanges();
            }, "ExceptionShielding");

            BillOfMaterialMapper.UpdatePresentationModel(billOfMaterialPM, billOfMaterial);
        }

        public void UpdateBillOfMaterial(BillOfMaterialPM billOfMaterialPM)
        {
            BillOfMaterial billOfMaterial = BillOfMaterialMapper.FromPresentationModel(billOfMaterialPM);
            BillOfMaterial existingBillOfMaterial = _exceptionManager.Process(() => _productRepository.GetByKey<BillOfMaterial>(billOfMaterial.BillOfMaterialId), "ExceptionShielding");

            existingBillOfMaterial.BOMLevel = billOfMaterial.BOMLevel;
            existingBillOfMaterial.ComponentId = billOfMaterial.ComponentId;
            existingBillOfMaterial.PerAssemblyQty = billOfMaterial.PerAssemblyQty;
            existingBillOfMaterial.ProductAssemblyId = billOfMaterial.ProductAssemblyId;
            existingBillOfMaterial.UOMCode = billOfMaterial.UOMCode;

            _exceptionManager.Process(() =>
            {
                _productRepository.Update(existingBillOfMaterial);
                _productRepository.UnitOfWork.SaveChanges();
            }, "ExceptionShielding");
        }

        public void DeleteUserRole(BillOfMaterialPM billOfMaterialPM)
        {
            _exceptionManager.Process(() =>
            {
                _productRepository.Delete<BillOfMaterial>(ur => ur.BillOfMaterialId == billOfMaterialPM.Id);
                _productRepository.UnitOfWork.SaveChanges();
            }, "ExceptionShielding");

        }

        [Invoke]
        public void UpdatePartTypesForKitType(int kitTypeId, int[] assignedPartIds, double[] quantities, int[] sequences)
        {
            //int[] partIds = _productRepository.GetQuery<BillOfMaterial>(bom => bom.ProductAssemblyId == kitTypeId).Select(bom => bom.ComponentId).ToArray();

            int[] partIds = _productRepository.GetQuery<BillOfMaterial>(bom => bom.ProductAssemblyId == kitTypeId && bom.Item.Category !="RawMaterial").Select(bom => bom.ComponentId).ToArray();

            int[] removedParts = partIds.Except(assignedPartIds).ToArray();

            foreach (int removedPart in removedParts)
            {
                _productRepository.Delete<BillOfMaterial>(bom => bom.ProductAssemblyId == kitTypeId && bom.ComponentId == removedPart);
            }
            _productRepository.UnitOfWork.SaveChanges();

            for (int i = 0; i < assignedPartIds.Count(); i++)
            {
                int i1 = assignedPartIds[i];
                BillOfMaterial billOfMaterial = _productRepository.First<BillOfMaterial>(bom => bom.ProductAssemblyId == kitTypeId && bom.ComponentId == i1);

                if (billOfMaterial != null)
                {
                    billOfMaterial.PerAssemblyQty = quantities[i];
                    billOfMaterial.UOMCode = i.ToString("000");
                    billOfMaterial.CreatedBy = sequences[i].ToString();
                    _productRepository.Update(billOfMaterial);
                }
                else
                {
                    _productRepository.Add(new BillOfMaterial
                    {
                        ProductAssemblyId = kitTypeId,
                        ComponentId = assignedPartIds[i],
                        PerAssemblyQty = quantities[i],
                        //UOMCode = "1",
                        UOMCode = i.ToString("000"), 
                        CreatedBy = sequences[i].ToString (),
                    });
                }

            }

           
            _productRepository.UnitOfWork.SaveChanges();
        }
    }
}
