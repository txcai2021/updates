﻿

using Microsoft.AspNetCore.SignalR;
using System;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;

namespace SIMTech.APS.Integration.API.Signalr
{
    public class SignalrHub : Hub
    {
        [HubMethodName("BroadcastMessage")]
        public async Task BroadcastMessageReceivedFromClients(string user, string message)
        {
            await Clients.All.SendAsync("SendAlerts", user, message);
        }
    }

    public class AlertPM
    {
        [Key]
        public int Id { get; set; }
        public string Title { get; set; }
        public string AlertType { get; set; }
        public string WorkOrderNumber { get; set; }
        public List<int> ReleasingWorkOrders {get;set;}
        public int Sequence { get; set; }
        public string OperationName { get; set; }
        public string MachineName { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Description { get; set; }
        public string Action { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedBy { get; set; }
    }
}