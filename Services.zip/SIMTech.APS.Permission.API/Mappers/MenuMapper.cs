﻿using System.Collections.Generic;
using System.Linq;


namespace SIMTech.APS.Permission.API.Mappers
{
    using SIMTech.APS.Permission.API.Models;
    using SIMTech.APS.Permission.API.PresentationModels;
    public class MenuMapper
    {
        public static IEnumerable<MenuPM> ToPresentationModels(IEnumerable<Menu> menus)
        {
            if (menus == null) return null;
            return menus.Select(ToPresentationModel);
        }

        public static MenuPM ToPresentationModel(Menu menu)
        {
            if (menu == null) return null;

            return new MenuPM
            {
                Id = menu.Id,
                ParentTaskId = menu.ParentTaskId,
                SortSequence = menu.SortSequence,
                TaskId = menu.TaskId,
            };
        }

        public static Menu FromPresentationModel(MenuPM menuPM)
        {
            if (menuPM == null) return null;

            return new Menu
            {
                Id = menuPM.Id,
                ParentTaskId = menuPM.ParentTaskId,
                SortSequence = menuPM.SortSequence,
                TaskId = menuPM.TaskId,
            };
        }

        public static void UpdatePresentationModel(MenuPM menuPM, Menu menu)
        {
            if (menuPM == null || menu == null) return;

            menuPM.Id = menu.Id;
            menuPM.ParentTaskId = menu.ParentTaskId;
            menuPM.SortSequence = menu.SortSequence;
            menuPM.TaskId = menu.TaskId;
        }
    }
}
