﻿using System.Collections.Generic;

namespace SIMTech.APS.Calendar.API.Repository
{
    using SIMTech.APS.Calendar.API.Models;
    using SIMTech.APS.Repository;
    public interface ICalendarDetailRepository : IRepository<CalendarDetail>
    {     
                   
    }
}
