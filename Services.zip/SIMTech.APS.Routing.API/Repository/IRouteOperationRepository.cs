﻿using System.Collections.Generic;

namespace SIMTech.APS.Routing.API.Repository
{
    using SIMTech.APS.Routing.API.Models;
    using SIMTech.APS.Repository;
    public interface IRouteOperationRepository : IRepository<RouteOperation>
    {     
                   
    }
}
