﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Transactions;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using Microsoft.EntityFrameworkCore;


namespace SIMTech.APS.Setting.API.Controllers
{
    using SIMTech.APS.Setting.API.Repository;
    using SIMTech.APS.Setting.API.Models;
    using SIMTech.APS.PresentationModels;


    [Route("api/[controller]")]
    [ApiController]
    public class OptionController : ControllerBase
    {
        private readonly IOptionRepository _optionRepository;
        private readonly ExceptionManager _exceptionManager;


        public OptionController(IOptionRepository optionRepository)
        {
            _optionRepository = optionRepository;
            _exceptionManager = new ExceptionManager();
        }


        [HttpGet]
        public IEnumerable<Option> GetAllOptions()
        {
            var options = _optionRepository.GetQuery(x => x.Id > 0).ToList();

            return options;

        }

        [HttpGet("Include/{name}")]
        public IEnumerable<Option> GetAllOptionsIncludeName(string name)
        {
            var options = _optionRepository.GetQuery(x => x.OptionName.Contains (name)).ToList();

            return options;

        }

        [HttpGet]
        [Route("{id}")]
        public Option GetOptionById(int id) 
        {
            var option = _optionRepository.GetById(id);         
            return option;
        }

        [HttpGet]
        [Route("Name/{name}")]
        public Option GetOptionByName(string name)
        {
            var option = _optionRepository.GetQuery(x => x.OptionName==name).FirstOrDefault();
            return option;
        }



        [HttpPost]
        public int AddOption([FromBody] Option option)
        {
           
            
            _exceptionManager.Process(() =>
            {
                _optionRepository.Insert(option);
            }, "ExceptionShielding");


            return option.Id;
           
        }

        [HttpPut]
        public void UpdateOption([FromBody] Option option)
        {
            var option1=_optionRepository.GetById(option.Id);
            option1.DefaultSetting = option.DefaultSetting;
            option1.ModifiedOn = DateTime.Now;

            _optionRepository.Update(option1);              
             
        }
       


    }
}
