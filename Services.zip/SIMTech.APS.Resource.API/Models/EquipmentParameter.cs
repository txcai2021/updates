﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.Resource.API.Models
{
    using SIMTech.APS.Models;
    public partial class EquipmentParameter : BaseEntity
    {
        public int EquipmentId { get; set; }
        public int ParameterId { get; set; }
        public string Value { get; set; }
        public string MinValue { get; set; }
        public string MaxValue { get; set; }

        public virtual Equipment Equipment { get; set; }
    }
}
