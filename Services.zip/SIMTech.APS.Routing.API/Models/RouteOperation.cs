﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.Routing.API.Models
{
    using SIMTech.APS.Models;
    public  class RouteOperation : BaseEntity
    {
        
        public int RouteId { get; set; }
        public int? OperationId { get; set; }
        public int? SubrouteId { get; set; }
        public int? Sequence { get; set; }
        public int? DefaultResourceId { get; set; }
        public string Instruction { get; set; }
        
        public virtual Route Route { get; set; }
        public virtual Route Subroute { get; set; }
    }
}
