﻿using System.ComponentModel.DataAnnotations;
using SIMTech.APS.Resources;

namespace SIMTech.APS.Product.API.PresentationModels
{ 
    public class UnitPM
    {
        [Key]
        public int Id { get; set; }

        [StringLength(50, ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ValidationErrorBadUnitName")]
        [Required(ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ValidationErrorRequiredField")]
        [Display( ResourceType = typeof(SharedResources), Name = "UnitName")]
        public string Name { get; set; }

        [StringLength(250, ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ValidationErrorBadUnitDescription")]
        [Display( ResourceType = typeof(SharedResources), Name = "UnitDescription")]
        public string Description { get; set; }

        [Display(ResourceType = typeof(SharedResources), Name = "NoOfProductionLines")]
        public int NoOfProductionLines { get; set; }

        
        [Display( Name = "Calendar")]
        public int? CalendarId { get; set; }

        [Display(Name = "Company Logo")]
        public int? CompanyLogoId { get; set; }

        [StringLength(250, ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ExceedMaxLength")]
        [Display(Name = "Address")]
        public string Address { get; set; }
        
        [StringLength(50, ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ExceedMaxLength")]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [StringLength(50, ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ExceedMaxLength")]
        [Display(Name = "Web Site")]
        public string Website { get; set; }


        [StringLength(50, ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ExceedMaxLength")]
        [Display(Name = "Phone")]
        public string Phone { get; set; }

        [StringLength(50, ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ExceedMaxLength")]
        [Display( Name = "Fax")]
        public string Fax { get; set; }

        [StringLength(50, ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ExceedMaxLength")]
        [Display( Name = "Co Reg No.")]
        public string CoRegNo { get; set; }

        [StringLength(50, ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ExceedMaxLength")]
        [Display( Name = "Gst Reg No.")]
        public string GstRegNo { get; set; }

        public int CustomerId { get; set; }

        public byte[] ThumbnailImage { get; set; }

        public string ThumbnailImageFileName { get; set; }

    }
}
