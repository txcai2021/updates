﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SIMTech.APS.Operation.API.Mappers
{
    using SIMTech.APS.Operation.API.Models;
    using SIMTech.APS.Operation.API.PresentationModels;

    /// <summary>
    /// Maps  PMs (Presentation Models) to  BOs (Business Objects) and vice versa.
    /// </summary>
    public static class OperationResourceMapper
    {

        /// <summary>
        /// Transforms list of operationresource BOs list of operationresource PMs.
        /// </summary>
        /// <param name="operationresources">List of operationresource BOs.</param>
        /// <returns>List of operationresource PMs.</returns>
        public static IList<OperationResourcePM> ToPresentationModels(IEnumerable<OperationResource> operationresources)
        {
            if (operationresources == null) return null;

            return operationresources.Select(u => ToPresentationModel(u)).ToList();
        }

        /// <summary>
        /// Transforms operationresource BO to operationresource PM.
        /// </summary>
        /// <param name="operationresource">operationresource BO.</param>
        /// <returns>operationresource PM.</returns>
        public static OperationResourcePM ToPresentationModel(OperationResource operationresource)
        {

            if (operationresource == null) return null;

            return new OperationResourcePM
            {

                Id = operationresource.Id,

                OperationId = operationresource.OperationId,
                ResourceId = operationresource.ResourceId,

                //ResourceName = operationresource.ResourceID.HasValue ? _resourceRepository.GetByKey<Equipment>(operationresource.ResourceID).EquipmentName : string.Empty,
                Cost = operationresource.Cost.HasValue ? operationresource.Cost : 0,
                Pretime = operationresource.Pretime.HasValue ? operationresource.Pretime : 0,
                Posttime = operationresource.Posttime.HasValue ? operationresource.Posttime : 0,
                ProductionRate = operationresource.Duration.HasValue ? operationresource.Duration : 0,
                ProdRateUoM = operationresource.DurationPer.HasValue ? (int?)operationresource.DurationPer : 249,
                //ProdRateUoM = (int?)operationresource.DurationPer,
                //isActive = operationresource.IsActive,

                isDefault = (bool)operationresource.IsDefault.HasValue ? operationresource.IsDefault.Value : false,

                //Description = operationresource.Description,
                Comment = operationresource.Instruction,
                CreatedDate = operationresource.CreatedOn

                //OperationResources = ToPresentationModels(operationresource.OperationResources),
            };
        }

        /// <summary>
        /// Transforms list of operationresourceRole BOs list of operationresourceRole PMs.
        /// </summary>
        /// <param name="operationresourceRoles">List of operationresourceRole BOs.</param>
        /// <returns>List of operationresourceRole PMs.</returns>
        //public static IList<UserRolePM> ToPresentationModels(IEnumerable<UserRole> operationresourceRoles)
        //{
        //    if (operationresourceRoles == null) return null;
        //    return operationresourceRoles.Select(ur => ToPresentationModel(ur)).ToList();
        //}

        /// <summary>
        /// Transforms operationresourceRole BO to operationresourceRole PM.
        /// </summary>
        /// <param name="operationresourceRole">operationresourceRole BO.</param>
        /// <returns>operationresourceRole PM.</returns>
        //public static UserRolePM ToPresentationModel(UserRole operationresourceRole)
        //{
        //    if (operationresourceRole == null) return null;

        //    return new UserRolePM
        //    {
        //        UserRoleId=operationresourceRole.UserRoleId,
        //        UserId = operationresourceRole.UserId,
        //        RoleId = operationresourceRole.RoleId
        //    };
        //}

        /// <summary>
        /// Transforms list of operationresource PMs list of operationresource BOs.
        /// </summary>
        /// <param name="operationresourcePMs">List of operationresource PMs.</param>
        /// <returns>List of operationresource BOs.</returns>
        public static IList<OperationResource> FromPresentationModels(IEnumerable<OperationResourcePM> operationresourcePMs)
        {
            if (operationresourcePMs == null) return null;
            return operationresourcePMs.Select(u => FromPresentationModel(u)).ToList();
        }

        /// <summary>
        /// Transforms operationresource PM to operationresource BO.
        /// </summary>
        /// <param name="operationresourcePM">operationresource PM.</param>
        /// <returns>operationresource BO.</returns>
        public static OperationResource FromPresentationModel(OperationResourcePM operationresourcePM)
        {
            if (operationresourcePM == null) return null;

            return new OperationResource
            {
                Id = operationresourcePM.Id,

                OperationId = operationresourcePM.OperationId,
                ResourceId = operationresourcePM.ResourceId,

                Cost = operationresourcePM.Cost,
                Pretime = operationresourcePM.Pretime,
                Posttime = operationresourcePM.Posttime,
                Duration = operationresourcePM.ProductionRate,
                DurationPer = operationresourcePM.ProdRateUoM,
                //IsActive = operationresourcePM.isActive,

                IsDefault = operationresourcePM.isDefault,

                //Description = operationresourcePM.Description,
                //Comments = operationresourcePM.Comment,
                CreatedOn = operationresourcePM.CreatedDate

                //OperationResource = FromPresentationModels(operationresourcePM.OperationResources)

            };
        }

        /// <summary>
        /// Transforms list of operationresourceRole PMs list of operationresourceRole BOs.
        /// </summary>
        /// <param name="operationresourceRolePMs">List of operationresourceRole PMs.</param>
        /// <returns>List of operationresourceRole BOs.</returns>
        //public static IList<UserRole> FromPresentationModels(IEnumerable<UserRolePM> operationresourceRolePMs)
        //{
        //    if (operationresourceRolePMs == null) return null;
        //    return operationresourceRolePMs.Select(ur => FromPresentationModel(ur)).ToList();
        //}

        /// <summary>
        /// Transforms operationresourceRole PM to operationresourceRole BO.
        /// </summary>
        /// <param name="operationresourceRolePM">operationresourceRole PM.</param>
        /// <returns>operationresourceRole BO.</returns>
        //public static UserRole FromPresentationModel(UserRolePM operationresourceRolePM)
        //{
        //    if (operationresourceRolePM == null) return null;

        //    return new UserRole
        //    {
        //        UserRoleId =operationresourceRolePM.UserRoleId ,
        //        UserId = operationresourceRolePM.UserId,
        //        RoleId = operationresourceRolePM.RoleId
        //    };
        //}






    }
}
