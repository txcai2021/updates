﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace SIMTech.APS.DeliveryOrder.API.Mappers
{
    using SIMTech.APS.DeliveryOrder.API.PresentationModels;
    using SIMTech.APS.DeliveryOrder.API.Models;
    using SIMTech.APS.DeliveryOrder.API.Enums;

    public static class DeliveryOrderMapper
    {

        public static IEnumerable<DeliveryOrderPM> ToPresentationModels(IEnumerable<DeliveryOrder> deliveryOrders)
        {
            if (deliveryOrders == null) return null;
            return deliveryOrders.Select(ToPresentationModel);
        }

        public static DeliveryOrderPM ToPresentationModel(DeliveryOrder deliveryOrder)
        {
            if (deliveryOrder == null) return null;

            var deliveryOrderPM = new DeliveryOrderPM();
            deliveryOrderPM.UpdateFrom(deliveryOrder); 

            return deliveryOrderPM;
        }

        public static IEnumerable<DeliveryOrder> FromPresentationModels(IEnumerable<DeliveryOrderPM> deliveryOrderPMs)
        {
            if (deliveryOrderPMs == null) return null;
            return deliveryOrderPMs.Select(FromPresentationModel);
        }

        public static DeliveryOrder FromPresentationModel(DeliveryOrderPM deliveryOrderPM)
        {
            if (deliveryOrderPM == null) return null;

            var deliveryOrder = new DeliveryOrder();
            deliveryOrder.UpdateFrom(deliveryOrderPM);

            return deliveryOrder;

            
        }

        public static void UpdateFrom(this DeliveryOrderPM deliveryOrderPM, DeliveryOrder deliveryOrder)
        {
            if (deliveryOrderPM == null || deliveryOrder == null) return;

            deliveryOrderPM.Id=deliveryOrder.Id ;
            deliveryOrderPM.DeliveryOrderNo=deliveryOrder.DeliveryOrderNumber ;
            deliveryOrderPM.CustomerId= deliveryOrder.CustomerId;
            deliveryOrderPM.ShipToAddress=deliveryOrder.ShipAddress;
            deliveryOrderPM.OrderDate=deliveryOrder.ShipDate;
            deliveryOrderPM.Remarks=deliveryOrder.Comment;
            

            deliveryOrderPM.Currency=deliveryOrder.Currency;
            deliveryOrderPM.InvoiceTOAddress=deliveryOrder.InvoiceAddress;
            deliveryOrderPM.Type = (EDeliveryOrderType)deliveryOrder.Type;
            deliveryOrderPM.Status = (EDeliveryOrderStatus)deliveryOrder.Status;

            deliveryOrderPM.CreditTerms=deliveryOrder.String2 ;
            deliveryOrderPM.CompanyNam = deliveryOrder.String6; //customer name
            deliveryOrderPM.CompanyName = deliveryOrder.String7;
            deliveryOrderPM.CompanyPhone = deliveryOrder.String8;
            deliveryOrderPM.Fax = deliveryOrder.String10;
            
            deliveryOrderPM.CompanyAddress = deliveryOrder.MaxString1;

            deliveryOrderPM.SignatureID=deliveryOrder.Int1;          
            deliveryOrderPM.LocationId = deliveryOrder.Int2;
            deliveryOrderPM.SelAddressType = deliveryOrder.Int3;

            var pos =deliveryOrder.DeliveryOrderDetails.Select(x=>x.String1).Distinct() ;

            foreach (var po in pos)
            {
                if (string.IsNullOrEmpty (deliveryOrderPM.POList))
                    deliveryOrderPM.POList  =  po;
                else
                    deliveryOrderPM.POList  = deliveryOrderPM.POList+ po;
            }

            var partNos = deliveryOrder.DeliveryOrderDetails.Select(x => x.String3).Distinct();

            foreach (var po in partNos)
            {
                if (string.IsNullOrEmpty(deliveryOrderPM.POList))
                    deliveryOrderPM.PartNoList = po;
                else
                    deliveryOrderPM.PartNoList = deliveryOrderPM.PartNoList + po;
            }

            var partNames = deliveryOrder.DeliveryOrderDetails.Select(x => x.String4).Distinct();

            foreach (var po in partNames)
            {
                if (string.IsNullOrEmpty(deliveryOrderPM.POList))
                    deliveryOrderPM.PartNameList = po;
                else
                    deliveryOrderPM.PartNameList = deliveryOrderPM.PartNameList + po;
            }
                
                           
        }

        public static void UpdateFrom(this DeliveryOrder deliveryOrder, DeliveryOrderPM deliveryOrderPM)
        {

            deliveryOrder.Id=deliveryOrderPM.Id;
            deliveryOrder.DeliveryOrderNumber = deliveryOrderPM.DeliveryOrderNo;
            deliveryOrder.CustomerId = deliveryOrderPM.CustomerId;
            deliveryOrder.ShipAddress = deliveryOrderPM.ShipToAddress;
            deliveryOrder.ShipDate = deliveryOrderPM.OrderDate;
            deliveryOrder.Comment = deliveryOrderPM.Remarks;
           
        
            deliveryOrder.Currency = deliveryOrderPM.Currency;           
            deliveryOrder.InvoiceAddress = deliveryOrderPM.InvoiceTOAddress;          
            deliveryOrder.Type = (byte)deliveryOrderPM.Type;
            deliveryOrder.Status = (byte)deliveryOrderPM.Status;

            deliveryOrder.String2 = deliveryOrderPM.CreditTerms;
            deliveryOrder.String6=deliveryOrderPM.CompanyNam; //customer name
            deliveryOrder.String7=deliveryOrderPM.CompanyName;
            deliveryOrder.String8 = deliveryOrderPM.CompanyPhone;
            deliveryOrder.String10 = deliveryOrderPM.Fax;

            deliveryOrder.MaxString1 =deliveryOrderPM.CompanyAddress ;

            deliveryOrder.Int1 =deliveryOrderPM.SignatureID ;
            deliveryOrder.Int2=deliveryOrderPM.LocationId  ;
            deliveryOrder.Int3 = deliveryOrderPM.SelAddressType;

             
                        
        }  
        
     



    }
}
