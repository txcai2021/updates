﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Transactions;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using System.Linq;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace SIMTech.APS.Permission.API.Controllers
{
    using SIMTech.APS.Permission.API.Repository;
    using SIMTech.APS.Permission.API.Models;
    using SIMTech.APS.Permission.API.PresentationModels;
    using SIMTech.APS.Permission.API.Mappers;

    [Route("api/[controller]")]
    [ApiController]
    public class RoleController : ControllerBase
    {
        private readonly IRoleRepository _roleRepository;

        public RoleController(IRoleRepository roleRepository)
        {
            _roleRepository = roleRepository;
        }


        //GET: api/Role
        [HttpGet]
        //public async Task<IEnumerable<Role>> GetAllRoles() => await _roleRepository.GetAll();

        public IEnumerable<RolePM> GetAllRoles()
        {
            var users = _roleRepository.GetQuery(u => u.RoleName != "DEVELOPER").OrderBy(x => x.RoleName).ToList();

            var rolePMs = RoleMapper.ToPresentationModels(users);

            return rolePMs.AsQueryable();
        }

        [HttpGet]
        [Route("{id}")]
        //public Role GetRoleById(int id) => _roleRepository.GetById(id);

        public RolePM GetRoleById(int id)
        {
            var role= _roleRepository.GetById(id);
            return RoleMapper.ToPresentationModel(role);
        }



        [HttpPost]
        //public void AddRole([FromBody] Role Role) => _roleRepository.Insert(Role);

        public void AddRole([FromBody] RolePM rolePM)
        {
            var role = RoleMapper.FromPresentationModel(rolePM);
            _roleRepository.Insert(role);
        }


        [HttpPut]
        //public void UpdateRole([FromBody] Role Role) => _roleRepository.Update(Role);
        public void UpdateRole([FromBody] RolePM rolePM)
        {
            var role = RoleMapper.FromPresentationModel(rolePM);
            var existingRole =  _roleRepository.GetById(role.Id);

            existingRole.Description = role.Description;
            existingRole.GlobalAccess = role.GlobalAccess;
            existingRole.RoleName = role.RoleName;
            existingRole.StartTaskId = role.StartTaskId;
            _roleRepository.Update(existingRole);
        }
        

        [HttpPost("userrole")]
        public IActionResult UpdateUserRole([FromBody] UserRole userRole)
        {

            _roleRepository.UpdateUserRole(userRole.UserId, userRole.RoleId);

            var role = _roleRepository.GetById(userRole.RoleId);

            return new OkObjectResult(null);
        }



        // DELETE api/<RoleController>/5
        [HttpDelete("{id}")]
        public void DeleteRole(int id) => _roleRepository.Delete(id);

        [HttpPost("menus")]
        public IActionResult GetMenuByRole([FromBody] ModuleMenuPM moduleMenuPM)
        {
            var menu = _roleRepository.GetMenuItemsByRole(moduleMenuPM.RoleName, moduleMenuPM.ModuleName);

            return new OkObjectResult(menu);
        }

        [HttpGet]
        [Route("module/{userId}")]
        public IActionResult GetModuleNames(int userId)
        {
            var moduleNames = _roleRepository.GetModuleNameByUserId(userId);

            return new OkObjectResult(moduleNames);
        }

        [HttpGet]
        [Route("Evn/{envVar}")]
        public IActionResult GetEnvironmentVariable(string envVar)
        {
            var db = Environment.GetEnvironmentVariable(envVar);

            return new OkObjectResult(db);
        }


        [HttpGet]
        [Route("user/{userId}")]
        public IActionResult GetRoleNames(int userId)
        {
            var roles = _roleRepository.GetRoleNameByUserId(userId);

            return new OkObjectResult(roles);
        }
    }
}
