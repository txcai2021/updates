﻿using System;
using System.ComponentModel.DataAnnotations;
using SIMTech.APS.Resources;
using System.Collections.Generic;


namespace SIMTech.APS.DeliveryOrder.API.PresentationModels
{
    using SIMTech.APS.DeliveryOrder.API.Enums;
    using SIMTech.APS.PresentationModels;
    public class DeliveryOrderLinePM
    {
        public DeliveryOrderLinePM()
        {
            SalesOrderLine = new IdNamePM();
            WorkOrder = new IdNamePM();
            InventoryAllocations =  new List<IdNamePM>();
        }

        [Key]
        public int Id { get; set; }
        
       

        [Display(ShortName = "Part No", Name = "Part No")]
        public string PartId { get; set; }

        [Display(ShortName = "Part Name", Name = "Part Name")]
        public string PartName { get; set; }  
         
        public int DeliveryOrderId { get; set; }

        [Display(ShortName = "PO Avail Qty", Name = "PO Avail Qty")]
        public double OrignalQuantity { get; set; }

        [Display(ShortName = "Inv Alloc Qty", Name = "Inv Alloc Qty")]
        public double? ChangeQuantity { get; set; }

        [Display(ShortName = "PO Bal Qty", Name = "PO Balance Qty")]
        public double? BalanceQuantity { get; set; }

        [Display(ShortName = "DO Qty", Name = "DO Qty")]
        public double Quantity { get; set; }

        public int? Dindex { get; set; }
        public int? pieces { get; set; }

        public int? CustomerId { get; set; }
        public string KitName { get; set; } // CustomerKitCode

        public string KitTypeId { get; set; }

        public string KitId { get; set; }
        //added
        public string PartTypeId { get; set; }

        public decimal? UnitPrice { get; set; }

        public decimal? Amount { get; set; }


        public string Description { get; set; }


        public string CustCompanyName { get; set; }
        public string CustModuleName { get; set;}
        public string SupplierNumber { get; set; }

        //changed string to decimal
        public string   AccRFHour { get; set; }
        //changed string to decimal
        public string  CurRFHour { get; set; }

        public string AccRCCount { get; set; }

        public string AccWaferCount { get; set; }

        public string AccRefCount { get; set; }

        
        //public string MaxRCCount { get; set; }
        public string CurWaferCount { get; set; }
        public string Disposition { get; set; }

        public string ChamberID { get; set; }
        public string PMReason { get; set; }
        public string TypeName { get; set; }
        public double? ItemNO { get; set; }

        public string NCRList { get; set; }

        //public string NCRUncleanList { get; set; }

        //public string NCRScrapped { get; set; }

        public string GatePassNO { get; set; }

        public string SerialNO { get; set; }
        public List<string> TypeofService { get; set; }
        public string SelectedTypeofService { get; set; }
        public List<string> GTitle { get; set; }
        public List<string> KitInfo { get; set; }
        public string SelectedKitInfo { get; set; }
        public string SelectedGTitle { get; set; }
        public bool? IsIncludeDeliverOrderLine { get; set; }
        public bool? IsIncludeCustomerPartCode { get; set; }
        public bool? IsIncludeCustomerKitCode { get; set; }
        public bool? IsIncludePartTypeId { get; set; }
        public bool? IsIncludePartId { get; set; }
        public bool? IsIncludeSerialNO {  get; set; }
        public bool? IsIncludeDescription { get; set; }
        public bool? IsIncludeItemNO { get; set; }
        public bool? IsIncludeTypeName { get; set; }
        public bool? IsIncludePMReason { get; set; }
        public bool? IsIncludePieces { get; set; }
        public bool? IsIncludeDisposition { get; set; }
        public bool? IsIncludeKitId { get; set; }
        public bool? IsIncludeChamberID { get; set; }
        public bool? IsIncludeKitInfo { get; set; }
        public bool? IsIncludeTypeOfService { get; set; }
              
        public bool? IsIncludeKit { get; set; }
            
        public bool? IsIncludeActualRFHour { get; set; }
        public bool? IsIncludeCustCompName { get; set; }
        public bool? IsIncludeCustModName { get; set; }
        public bool? IsIncludeSupplierNo { get; set; }

        public bool? IsIncludeCurRFHour { get; set; }
        public bool? IsIncludeActualRCCount { get; set; }
             
        public bool? IsIncludeActualWaferCount { get; set; }

        public bool? IsIncludeCurWaferCount { get; set; }
              
        public bool? IsIncludeActualRefCount { get; set; }
            
        public bool? IsIncludeNCRList { get; set; }
             
        //public bool? IsIncludeNCRUncleanList { get; set; }
              
        //public bool? IsIncludeNCRScrapped { get; set; }
        //for addition checkbox
        public bool? IsIncludeGatePass { get; set; }


        public bool? IsIncludeQuantity { get; set; }
        public bool? IsIncludeUnitPrice { get; set; }
        public bool? IsIncludeAmount { get; set; }
        //

        public bool? IsCheckYes { get; set; }

        public bool? IsCheckNo { get; set; }

        public bool? IsCustomerProductCode { get; set; }

        public bool? IsIncludeWorkOrderNumber { get; set; }
        

        public string Remarks { get; set; }

        public int? SalesOrderLineID { get; set; }

      

        public int? WorkOrderID { get; set; }


        [Display(ShortName = "Work Order Numbers", Name = "Work Order Numbers")]
        public string WorkOrderNumber { get; set; }



        [Display(ShortName = "Committed Del Date", Name = "Committed Del Date")]
        public string PODueDate { get; set; }

        [Display(ShortName = "PO Number", Name = "PO Number")]
        public string PONumber { get; set; }

        [Display(ShortName = "Printed PO Number", Name = "Printed PO Number")]
        public string PrintedPONumber { get; set; }
      
        public IdNamePM WorkOrder { get; set; }

        public IdNamePM SalesOrderLine { get; set; }

        public DeliveryOrderPM DeliveryOrder { get; set; }

        
       
        public IEnumerable<IdNamePM> InventoryAllocations { get; set; }
        //[Association("FK_DeliveryOrderLine_InventoryAllocations", "Id", "DelvieryOrderLineId")]
        //public IEnumerable<InventoryAllocationPM> InventoryAllocations { get; set; }


    }

    //public class InventoryAllocationPM
    //{
    //    [Key]
    //    public int Id { get; set; }

    //    public int DelvieryOrderLineId { get; set; }
    //    public int InventoryId { get; set; }

    //    public decimal? Quantity { get; set; }
       
    //}
}
