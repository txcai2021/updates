﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.Routing.API.Models

{
    using SIMTech.APS.Models ;
    public  class ProductRoute : BaseEntity
    {
        public ProductRoute()
        {
            ProductRouteStatuses = new HashSet<ProductRouteStatus>();
        }

        public string ProductRouteName { get; set; }
        public int Type { get; set; }
        public int CustomerId { get; set; }
        public int ProductId { get; set; }
        public int RouteId { get; set; }
        public byte Status { get; set; }
        public string Comment { get; set; }
        public string Remarks { get; set; }
        public int? Version { get; set; }
        public bool IsActive { get; set; }
        public bool? IsDefault { get; set; }
        public string String1 { get; set; }
        public string String2 { get; set; }
        public int? Int1 { get; set; }
        public int? Int2 { get; set; }


        public virtual Route Route { get; set; }
        public virtual ICollection<ProductRouteStatus> ProductRouteStatuses { get; set; }
    }
}
