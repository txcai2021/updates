﻿using System.Collections.Generic;
using System.Linq;


namespace SIMTech.APS.Inventory.API.Mappers
{
    using SIMTech.APS.Inventory.API.Models;
    using SIMTech.APS.Inventory.API.PresentationModels;
    public static class InventoryMasMapper
    {
        public static IEnumerable<InventoryMasPM> ToPresentationModels(IEnumerable<Item> items)
        {
            if (items == null) return null;
            return items.Select(ToPresentationModel);
        }

        public static InventoryMasPM ToPresentationModel(Item item)
        {
            if (item == null) return null;

            InventoryMasPM itemPM = new InventoryMasPM();
            itemPM.UpdateFrom(item); 
            return itemPM;
        }

        public static IEnumerable<Item> FromPresentationModels(IEnumerable<InventoryMasPM> itemPMs)
        {
            if (itemPMs == null) return null;
            return itemPMs.Select(FromPresentationModel);
        }

        public static Item FromPresentationModel(InventoryMasPM itemPM)
        {
            if (itemPM == null) return null;

            var item = new Item();
            item.UpdateFrom(itemPM);
            return item;

        }

        public static void UpdateFrom(this InventoryMasPM itemPM,Item item)
        {
            itemPM.Id = item.ItemID;            
            itemPM.Category =item.Category; 
            itemPM.PartId = item.ItemID ;            
            itemPM.CustomerId  = item.Int10;            
            itemPM.PartNo = item.ItemName;
            itemPM.PartName = item.Description;
            itemPM.PartFamily = item.Group1;

            itemPM.Cost = (decimal?)item.Float1;
            itemPM.SafetyStock = (decimal?)item.Float4;
            itemPM.MonthlyUsage = (decimal?)item.Float2;
            itemPM.CustomerFGQty = (decimal?)item.Float3;
            itemPM.Remarks = item.MaxString1;
            itemPM.Revision =item.String9;              
        }

        public static void UpdateFrom(this Item item, InventoryMasPM itemPM)
        {
            item.ItemID = itemPM.Id;
            item.Float4  =(double?)itemPM.SafetyStock ;
            item.Float2 = (double?)itemPM.MonthlyUsage;
            item.Float3 = (double?)itemPM.CustomerFGQty;
            item.MaxString1 = itemPM.Remarks; 
        }  
        
    }
}
