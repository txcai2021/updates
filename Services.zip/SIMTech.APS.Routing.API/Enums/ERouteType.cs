﻿
namespace SIMTech.APS.Routing.API.Enums
{
    public enum ERouteType
    {
        OR,
        AND
    }
}
