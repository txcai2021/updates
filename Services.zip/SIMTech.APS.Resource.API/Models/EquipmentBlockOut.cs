﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.Resource.API.Models
{
    using SIMTech.APS.Models;
    public partial class EquipmentBlockOut : BaseEntity
    {
        public int EquipmentId { get; set; }
        public string BlockOutType { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int? Value { get; set; }
        public string Remarks { get; set; }
        public virtual Equipment Equipment { get; set; }
    }
}
