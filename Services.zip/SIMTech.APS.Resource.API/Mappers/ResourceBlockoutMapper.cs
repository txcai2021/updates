﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;

namespace SIMTech.APS.Resource.API.Mappers
{
    using SIMTech.APS.Resource.API.Models;
    using SIMTech.APS.Resource.API.PresentationModels;


    /// <summary>
    /// Maps  PMs (Presentation Models) to  BOs (Business Objects) and vice versa.
    /// </summary>
    public static class ResourceBlockoutMapper
    {
        
        /// <summary>
        /// Transforms list of resource BOs list of resource PMs.
        /// </summary>
        /// <param name="resources">List of resource BOs.</param>
        /// <returns>List of resource PMs.</returns>
        public static IList<ResourceBlockoutPM> ToPresentationModels(IEnumerable<EquipmentBlockOut> resources)
        {
            if (resources == null) return null;
            return resources.Select(u => ToPresentationModel(u)).ToList();
        }

        /// <summary>
        /// Transforms resource BO to resource PM.
        /// </summary>
        /// <param name="resource">resource BO.</param>
        /// <returns>resource PM.</returns>
        public static ResourceBlockoutPM ToPresentationModel(EquipmentBlockOut resource)
        {
            if (resource == null) return null;

            return new ResourceBlockoutPM
            {
                EquipmentBlockOutID = resource.Id,
                EquipmentID = resource.EquipmentId,
                StartDate=resource.StartDate,
                EndDate = resource.EndDate,
                Remarks=resource.Remarks,
                BlockOutType=resource.BlockOutType,
                Value = resource.Value ?? 0,
                CreatedBy=resource.CreatedBy,
                CreatedOn=resource.CreatedOn
                
            };
        }

        
        ///// <summary>
        ///// Transforms list of resource PMs list of resource BOs.
        ///// </summary>
        ///// <param name="resourcePMs">List of resource PMs.</param>
        ///// <returns>List of resource BOs.</returns>
        public static IList<EquipmentBlockOut> FromPresentationModels(IEnumerable<ResourceBlockoutPM> resourcePMs)
        {
            if (resourcePMs == null) return null;
            return resourcePMs.Select(u => FromPresentationModel(u)).ToList();
        }

        ///// <summary>
        ///// Transforms resource PM to resource BO.
        ///// </summary>
        ///// <param name="resourcePM">resource PM.</param>
        ///// <returns>resource BO.</returns>
        public static EquipmentBlockOut FromPresentationModel(ResourceBlockoutPM resourcePM)
        {
            if (resourcePM == null) return null;

            return new EquipmentBlockOut
            {
                Id=resourcePM.EquipmentBlockOutID,
                EquipmentId = resourcePM.EquipmentID,
                BlockOutType = resourcePM.BlockOutType,
                StartDate=resourcePM.StartDate,
                EndDate=resourcePM.EndDate,
                Value=resourcePM.Value,
                Remarks=resourcePM.Remarks,
                CreatedOn = resourcePM.CreatedOn

            };
        }

              
    }
}
