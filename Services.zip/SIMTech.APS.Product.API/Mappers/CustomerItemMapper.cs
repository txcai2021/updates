﻿using System.Collections.Generic;
using System.Linq;


namespace SIMTech.APS.Product.Web.Mappers
{
    using SIMTech.APS.Product.API.Models;
    using SIMTech.APS.Product.API.PresentationModels;
    public class CustomerItemMapper
    {
        public static IEnumerable<CustomerItemPM> ToPresentationModels(IEnumerable<CustomerItem> customerItems)
        {
            if (customerItems == null) return null;
            return customerItems.Select(ToPresentationModel);
        }

        public static CustomerItemPM ToPresentationModel(CustomerItem customerItem)
        {
            if (customerItem == null) return null;

            return new CustomerItemPM
            {
                CustomerId = customerItem.CustomerId,
                CustomerKitCode = customerItem.String1,
                CustomerPartCode = customerItem.String1,
                ItemId = customerItem.ItemId,
                Id = customerItem.Id,
                ExternalTat = customerItem.ExternalTat,
                InternalTat = customerItem.InternalTat,
                SubItemId = (int?) customerItem.Float2,
                CustomerItemNo = (int?)customerItem.Float1,
                MaxRecycleCount = customerItem.Int1,
                MaxRefurbishmentCount = customerItem.Int2,
                MaxRfHour = customerItem.Int3,
                MaxWaferCount = customerItem.Int4,
                UnitPrice = customerItem.UnitPrice,
                FiringProcess =customerItem.Flag1 
            };
        }

        public static CustomerItem FromPresentationModel(CustomerItemPM customerItemPM)
        {
            if (customerItemPM == null) return null;

            CustomerItem customerItem = new CustomerItem
            {
                Id = customerItemPM.Id,
                CustomerId = customerItemPM.CustomerId,
                ItemId = customerItemPM.ItemId,
                String1 = customerItemPM.CustomerKitCode,
                ExternalTat = customerItemPM.ExternalTat,
                InternalTat = customerItemPM.InternalTat,
                Float1 = customerItemPM.CustomerItemNo,
                Float2 = customerItemPM.SubItemId,
                UnitPrice = customerItemPM.UnitPrice,
                Flag1 = customerItemPM.FiringProcess, 
            };

            if (customerItemPM.SubItemId != null)
            {
                customerItem.String1 = customerItemPM.CustomerPartCode;
                customerItem.Int1 = customerItemPM.MaxRecycleCount;
                customerItem.Int2 = customerItemPM.MaxRefurbishmentCount;
                customerItem.Int3 = customerItemPM.MaxRfHour;
                customerItem.Int4 = customerItemPM.MaxWaferCount;
                customerItem.Flag1 = customerItemPM.FiringProcess;
                customerItem.Float1 = customerItemPM.CustomerItemNo;
            }

            return customerItem;
        }

        public static void UpdatePresentationModel(CustomerItemPM customerItemPM, CustomerItem customerItem)
        {
            if (customerItemPM == null || customerItem == null) return;

            customerItemPM.CustomerId = customerItem.CustomerId;
            customerItemPM.Id = customerItem.Id;
            customerItemPM.ItemId = customerItem.ItemId;
            customerItemPM.CustomerItemNo = (int?)customerItem.Float1;
            customerItemPM.SubItemId = (int?) customerItem.Float2;
            customerItemPM.CustomerKitCode = customerItem.String1;
            customerItemPM.ExternalTat = customerItem.ExternalTat;
            customerItemPM.InternalTat = customerItem.InternalTat;
            customerItemPM.UnitPrice = customerItem.UnitPrice;

            if (customerItemPM.SubItemId != null)
            {
                customerItem.String1 = customerItemPM.CustomerPartCode;
                customerItem.Int1 = customerItemPM.MaxRecycleCount;
                customerItem.Int2 = customerItemPM.MaxRefurbishmentCount;
                customerItem.Int3 = customerItemPM.MaxRfHour;
                customerItem.Int4 = customerItemPM.MaxWaferCount;
                customerItem.Flag1 = customerItemPM.FiringProcess;
                customerItem.Float1 = customerItemPM.CustomerItemNo;
            }
        }
    }
}
