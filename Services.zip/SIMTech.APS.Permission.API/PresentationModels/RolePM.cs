﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using SIMTech.APS.Resources;

namespace SIMTech.APS.Permission.API.PresentationModels
{
    public class RolePM
    {
        public RolePM()
        {
            //UserRoles = new EntityCollection<UserRolePM>();
            //RoleTasks = new EntityCollection<RoleTaskPM>();
        }

        [Key]
        public int RoleId { get; set; }

        [StringLength(50)]
        //[RegularExpression("^[a-zA-Z0-9_]*$", ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ValidationErrorInvalidName")]
        [Required(ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ValidationErrorRequiredField")]
        [Display(ShortName = "RoleName", ResourceType = typeof(SharedResources), Name = "RoleName")]
        public string Name { get; set; }

        [StringLength(256)]
        [Display(ShortName = "Description", ResourceType = typeof(SharedResources), Name = "Description")]
        public string Description { get; set; }

        [Display(ShortName = "StartTaskId", ResourceType = typeof(SharedResources), Name = "StartTaskId")]
        public int? StartTaskId { get; set; }
        
        [Required(ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ValidationErrorRequiredField")]
        [Display(ShortName = "GlobalAccess", ResourceType = typeof(SharedResources), Name = "GlobalAccess")]
        public bool GlobalAccess { get; set; }

        //[Include]
        //[Association("UserRole", "RoleId", "RoleId")]
        //public IEnumerable<UserRolePM> UserRoles { get; set; }

        //[Include]
        //[Composition]
        //[Association("FK_RoleTask", "RoleId", "RoleId")]
        //public IEnumerable<RoleTaskPM> RoleTasks { get; set; }
    }
}
