﻿using System.ComponentModel.DataAnnotations;
using SIMTech.APS.Resources;

namespace SIMTech.APS.Inventory.API.PresentationModels
{
    public class InvCustomerPM
    {
        [Key]
        public int Id { get; set; }

        public string Code { get; set; }

        public string Name { get; set; }

        public string Site { get; set; }


    }
}
