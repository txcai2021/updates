﻿using System.Collections.Generic;
using System.Linq;


namespace SIMTech.APS.Permission.API.Mappers
{
    using SIMTech.APS.Models;
    using SIMTech.APS.Permission.API.Models;
    using SIMTech.APS.Permission.API.PresentationModels;
    public class DevOptionMapper
    {
        public static IEnumerable<DevOptionPM> ToPresentationModels(IEnumerable<Option> options)
        {
            if (options == null) return null;
            return options.Select(ToPresentationModel);
        }

        public static DevOptionPM ToPresentationModel(Option option)
        {
            if (option == null) return null;

            return new DevOptionPM
            {
                Id = option.Id,
                DefaultSetting = option.DefaultSetting,
                Name = option.OptionName,
                Description = option.Description,
                XmlType =1
            };
        }

        public static Option FromPresentationModel(DevOptionPM optionPM)
        {
            if (optionPM == null) return null;

            return new Option
            {
                Id=optionPM.Id,
                OptionName=optionPM.Name,
                DefaultSetting = optionPM.DefaultSetting
                
            };
        }

        public static void UpdatePresentationModel(DevOptionPM optionPM, Option option1)
        {
            if (optionPM == null || option1 == null) return;
            optionPM.Id = option1.Id;
            optionPM.Name = string.IsNullOrEmpty(option1.OptionName) ? string.Empty : option1.OptionName;           
            optionPM.DefaultSetting = string.IsNullOrEmpty(option1.DefaultSetting) ? string.Empty : option1.DefaultSetting.Trim();
           
        }

        // Task

        public static Task GetTaskModelFromDevModel(DevOptionPM optionPM)
        {
            if (optionPM == null) return null;

            return new Task
            {
                TaskName = optionPM.DBMenu,
                Type = optionPM.Type,
                ModuleName=optionPM.ModuleName,
                DisplayText=optionPM.DisplayText,
                ActionName = optionPM.ActionName,
                Description = optionPM.Description,
                Setting = optionPM.ImageFile               


            };
        }

    }
}
