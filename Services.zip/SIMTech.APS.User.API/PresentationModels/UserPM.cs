﻿using System;
using System.ComponentModel.DataAnnotations;
using SIMTech.APS.Resources;

namespace SIMTech.APS.User.API.PresentationModels
{
    public class UserPM
    {
        [Key]
        public int Id { get; set; }

        [StringLength(50)]
        //[RegularExpression("^[a-zA-Z0-9_-]*$", ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ValidationErrorInvalidName")]
        [Required(ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ValidationErrorRequiredField")]
        [Display(ShortName = "UserName", ResourceType = typeof(SharedResources), Name = "UserName")]
        public string Username { get; set; }

        [StringLength(50)]
        [Required(ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ValidationErrorRequiredField")]
        [Display(ShortName = "FirstName", ResourceType = typeof(SharedResources), Name = "FirstName")]
        public string FirstName { get; set; }

        [StringLength(50)]
        [Display(ShortName = "LastName", ResourceType = typeof(SharedResources), Name = "LastName")]
        public string LastName { get; set; }

        [StringLength(50)]
        [Display(ShortName = "Mobile", ResourceType = typeof(SharedResources), Name = "Mobile")]
        public string Mobile { get; set; }

        [StringLength(250)]
        [RegularExpression(@"^(?("")("".+?""@)|(([0-9a-zA-Z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)(?<=[0-9a-zA-Z])@))(?(\[)(\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,6}))$", ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ValidationErrorInvalidEmail")]
        [Display(ShortName = "Email", ResourceType = typeof(SharedResources), Name = "Email")]
        public string Email { get; set; }

        //[StringLength(20, MinimumLength = 8, ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ValidationErrorBadPasswordLength")]
        //[RegularExpression("^.*[^a-zA-Z0-9].*$", ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ValidationErrorBadPasswordStrength")]
        [Required(ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ValidationErrorRequiredField")]
        [Display(ShortName = "Password", ResourceType = typeof(SharedResources), Name = "Password")]
        public string Password { get; set; }

        //[Exclude]
        //[Required(ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ValidationErrorRequiredField")]
        //public string PasswordHash { get; set; }

        //[Exclude]
        //[Required(ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ValidationErrorRequiredField")]
        //public string PasswordSalt { get; set; }

        [StringLength(256)]
        //[Display(ShortName = "PasswordQuestion", ResourceType = typeof(SharedResources), Name = "PasswordQuesiton")]
        public string PasswordQuestion { get; set; }

        [Display(ShortName = "PasswordAnswer", ResourceType = typeof(SharedResources), Name = "PasswordAnswer")]
        public string PasswordAnswer { get; set; }

        //[Exclude]
        //public string PasswordAnswerHash { get; set; }

        //[Exclude]
        //public string PasswordAnswerSalt { get; set; }

        [Display(ShortName = "IsLockedOut", ResourceType = typeof(SharedResources), Name = "IsLockedOut")]
        public bool? IsLockedOut { get; set; }

        [Display(ShortName = "LastLoginDate", ResourceType = typeof(SharedResources), Name = "LastLoginDate")]
        public DateTime? LastLoginDate { get; set; }

        [Display(ShortName = "LastPasswordChangedDate", ResourceType = typeof(SharedResources), Name = "LastPasswordChangedDate")]
        public DateTime? LastPasswordChangedDate { get; set; }

        [Display(ShortName = "LastLockoutDate", ResourceType = typeof(SharedResources), Name = "LastLockoutDate")]
        public DateTime? LastLockoutDate { get; set; }

        [Display(ShortName = "FailedPasswordAttemptCount", ResourceType = typeof(SharedResources), Name = "FailedPasswordAttemptCount")]
        public int? FailedPasswordAttemptCount { get; set; }

        [Display(ShortName = "Comment", ResourceType = typeof(SharedResources), Name = "Comment")]
        public string Comment { get; set; }

        [Display(ShortName = "SignatureID")]
        public int? SignatureID { get; set; }

        [Display(ShortName = "PhotoID")]
        public int? PictureID { get; set; }

        [Display(ShortName = "Roles", ResourceType = typeof(SharedResources), Name = "Roles")]
        public string Roles { get; set; }

        [Required(ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ValidationErrorRequiredField")]
        [Display(ShortName = "RoleID")]
        public int RoleID { get; set; }
    }
}
