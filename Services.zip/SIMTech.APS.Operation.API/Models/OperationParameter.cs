﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.Operation.API.Models
{
    using SIMTech.APS.Models;
    public partial class OperationParameter:BaseEntity
    {
        public int OperationId { get; set; }
        public int? ParamterId { get; set; }
        public string Value { get; set; }
        public string MinValue { get; set; }
        public string MaxValue { get; set; }
        public string Uom { get; set; }
        public short? NoofReading { get; set; }
        public string MaxString1 { get; set; }
        public string MaxString2 { get; set; }
        public int? Int1 { get; set; }
        public int? Int2 { get; set; }
        public int? Int3 { get; set; }
        public int? Int4 { get; set; }
        public int? Int5 { get; set; }
        public int? Int6 { get; set; }
        public int? Int7 { get; set; }
        public int? Int8 { get; set; }
        public double? Float1 { get; set; }
        public double? Float2 { get; set; }
        public double? Float3 { get; set; }
        public double? Float4 { get; set; }
         
        public virtual Operation Operation { get; set; }
        public virtual Parameter Paramter { get; set; }
    }
}
