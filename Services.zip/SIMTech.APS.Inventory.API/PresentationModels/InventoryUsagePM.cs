﻿using System;
using System.ComponentModel.DataAnnotations;
using SIMTech.APS.Resources;

namespace SIMTech.APS.Inventory.API.PresentationModels
{
    public class InventoryUsagePM
    {
        [Key]
        public int Id { get; set; }

        public int InventoryId { get; set; }

        public int PartId { get; set; }

        public int Type { get; set; }

                
        public int UsedByOrderId { get; set; }

        [Display(ShortName = "Delivery Order Number", Name = "Delivery Order Number")]
        public string DeliveryOrderNumber{ get; set; }

        [Display(ShortName = "DO Qty", Name = "DO Qty")]
        public decimal? DOQty { get; set; }
           
        [Display(ShortName = "Quanity", Name = "Quanity")]
        public decimal Quantity { get; set; }

        [Display(ShortName = "Date Out", Name = "Date Out")]
        public DateTime DateOut { get; set; }
        
        public string Status { get; set; }

        [Display(ShortName = "Remarks", Name = "Remarks")]
        public string Remarks { get; set; }

        [Display(ShortName = "Created By", Name = "Created By")]
        public string CreatedBy { get; set; }

        //To store sales order info
        [Display(ShortName = "Sales Order Number", Name = "Sales Order Number")]
        public string SalesOrderNumber { get; set; }

        [Display(ShortName = "Line No", Name = "Line No")]
        public int LineNo { get; set; }

        [Display(ShortName = "Sales Order Qty", Name = "Sales Orde rQty")]
        public double? SalesOrderQty { get; set; }

        [Display(ShortName = "Committed Delivery Date", Name = "Committed Delivery Date")]
        public DateTime? CommittedDeliveryDate { get; set; }

        public InventoryPM Inventory { get; set; }

        public decimal? Cost { get; set; }


     }
}
