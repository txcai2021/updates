﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Collections.ObjectModel;

namespace SIMTech.APS.Permission.API.Repository
{
    using SIMTech.APS.Repository;
    using SIMTech.APS.Permission.API.Models;
    using SIMTech.APS.Permission.API.Mappers;
    using SIMTech.APS.Permission.API.PresentationModels;
    using SIMTech.APS.Permission.API.DBContext;

    public class RoleRepository : Repository<Role>, IRoleRepository
    {
        private readonly PermissionContext _dbContext;

        public RoleRepository(PermissionContext dbContext) : base(dbContext)
        {
            _dbContext = dbContext;
        }

        public IEnumerable<object> GetRoleNameByUserId(int userId)
        {
            //return _dbContext.UserRoles.Where(ur => ur.UserId == userId).Select(x=>x.Role.RoleName).ToList();
            return _dbContext.UserRoles.Where(ur => ur.UserId == userId).Select(x => new { x.Role.Id, x.Role.RoleName }).ToList ();
        }
        public IEnumerable<string> GetModuleNameByUserId(int userId)
        {
            var  roleIds =_dbContext.UserRoles.Where(ur => ur.UserId == userId).Select(x => x.Role.Id).ToList();
            return _dbContext.RoleTasks.Where(x => roleIds.Contains(x.RoleId) && x.Task.Type.Trim() == "Module").Select(x=>x.Task.ModuleName).ToList();
        }

        public IEnumerable<MenuItemPM> GetMenuItemsByRole(string userRole, string moduleName)
        {         

            //var role = _dbContext.Roles.FirstOrDefault(r => r.RoleName.Equals(userRole));
            var role = _dbContext.Roles.Include(r=>r.RoleTasks).ThenInclude(rt=>rt.Task).ThenInclude(t=>t.MenuParentTasks).ThenInclude(x=>x.Task).FirstOrDefault(r => r.RoleName.Equals(userRole));
            if (role == null) return null;

            moduleName = moduleName.Trim().ToLower();
          
            IEnumerable<Task> allowedTasks = role.RoleTasks.Where(rt => (rt.AccessMode.ToLower().Trim().Equals("yes") || rt.AccessMode.ToLower().Trim().Equals("middle")) && rt.Task.ModuleName.Trim().ToLower().Equals(moduleName)).Select(rt => rt.Task).ToList();

            if (allowedTasks.Count() == 0) return null;
            if (allowedTasks.Single(t => t.Type.Trim().Equals("Module")) == null) return null;

            IEnumerable<Task> menuTasks = allowedTasks.Single(t => t.Type.Trim().Equals("Module")).MenuParentTasks.OrderBy(m => m.SortSequence).Select(m => m.Task).Where(t => t.Type.Trim().Equals("MenuItem") && allowedTasks.Contains(t));
           
            return CreateMenuItems(allowedTasks.ToList(), menuTasks).ToList();
        }

        public IEnumerable<MenuItemPM> GetMenuItemsByRoles(string[] userRoles, string moduleName)
        {
            IEnumerable<Role> roles = _dbContext.Roles.Where(r => userRoles.Contains(r.RoleName));
            if (!roles.Any()) return null;

            IEnumerable<Task> allowedTasks = roles.SelectMany(r => r.RoleTasks).Where(rt => (rt.AccessMode.ToLower().Trim().Equals("yes") || rt.AccessMode.ToLower().Trim().Equals("middle")) && rt.Task.ModuleName.Trim().Equals(moduleName)).Select(rt => rt.Task).Distinct().ToList();
            if (allowedTasks.Count() == 0 && moduleName == "Scheduling")
            {
                allowedTasks = roles.SelectMany(r => r.RoleTasks).Where(rt => (rt.AccessMode.ToLower().Trim().Equals("yes") || rt.AccessMode.ToLower().Trim().Equals("middle")) && rt.Task.ModuleName.Trim().Equals("DPS")).Select(rt => rt.Task).Distinct().ToList();
            }

            IEnumerable<Task> menuTasks = allowedTasks.Single(t => t.Type.Trim().Equals("Module")).MenuTasks.OrderBy(m => m.SortSequence).Select(m => m.Task).Where(t => t.Type.Trim().Equals("MenuItem") && allowedTasks.Contains(t));


            return CreateMenuItems(allowedTasks.ToList(), menuTasks).ToList();
        }

        private IEnumerable<MenuItemPM> CreateMenuItems(List<Task> allowedTasks, IEnumerable<Task> tasks)
        {
            List<MenuItemPM> menuItems = new List<MenuItemPM>();

            foreach (Task task in tasks)
            {
                MenuItemPM menuItem = TaskMapper.ToMenuItem(task);                
                menuItem.ToolbarActions = new ObservableCollection<ToolbarActionPM>(TaskMapper.ToToolbarActions(task.MenuParentTasks.OrderBy(m => m.SortSequence).Select(m => m.Task).Where(t => t.Type.Trim().Equals("Action") && !(t.Setting == null || t.Setting.Trim().Equals("")) && allowedTasks.Contains(t))));
                menuItem.SubMenuItems = new ObservableCollection<MenuItemPM>(CreateMenuItems(allowedTasks, task.MenuParentTasks.OrderBy(m => m.SortSequence).Select(m => m.Task).Where(t => t.Type.Trim().Equals("MenuItem") && allowedTasks.Contains(t))));

                menuItems.Add(menuItem);
            }

            return menuItems;
        }

        public void UpdateUserRole(int userId, int roleId)
        {
            var userRole = _dbContext.UserRoles.Where(r => r.RoleId != roleId && r.UserId==userId).FirstOrDefault();

            if (userRole!=null)
            {
                _dbContext.UserRoles.Remove(userRole);
            }


            userRole = _dbContext.UserRoles.Where(r => r.RoleId == roleId && r.UserId == userId).FirstOrDefault();

           
            if (userRole == null)
            {
                _dbContext.UserRoles.Add(new UserRole() { UserId = userId, RoleId = roleId});             
            }

            _dbContext.SaveChanges();

        }



    }
}
