﻿using System;
using System.Collections.Generic;
using System.Linq;



namespace SIMTech.APS.SalesOrder.API.Mappers
{
    using SIMTech.APS.SalesOrder.API.PresentationModels;
    using SIMTech.APS.SalesOrder.API.Models;
    using SIMTech.APS.SalesOrder.API.Enums;

    public static class SalesOrderMapper
    {
        public static IEnumerable<SalesOrderPM> ToPresentationModels(IEnumerable<SalesOrder> salesOrders)
        {
            if (salesOrders == null) return null;
            return salesOrders.Select(ToPresentationModel);
        }

        public static SalesOrderPM ToPresentationModel(SalesOrder salesOrder)
        {
            if (salesOrder == null) return null;

            SalesOrderPM salesOrderPM = new SalesOrderPM
            {
                BalanceQuantity = salesOrder.Float2,
                Comment = salesOrder.Comment,
                ContactNo = salesOrder.ContactNo,
                ContactPersonName = salesOrder.ContactPersonName,
                CustomerId = salesOrder.CustomerId,
                DueDate = salesOrder.DueDate,
                Id = salesOrder.Id,
                LocationId = salesOrder.LocationId,
                OrderDate = salesOrder.OrderDate,
                OrderType = (ESalesOrderType)salesOrder.OrderType,
                PurchaseOrderNumber = salesOrder.PurchaseOrderNumber,
                SalesOrderNumber = salesOrder.SalesOrderNumber,
                SalesPersonName = salesOrder.SalesPersonName,
                ShipDate = salesOrder.ShipDate,
                Status = (ESalesOrderStatus)salesOrder.Status,
                TotalItems = salesOrder.TotalItems,
                Amount = salesOrder.TotalAmount,
                Quantity = salesOrder.TotalQuantity,
                BillingNo = salesOrder.String1,
                CreatedBy =salesOrder.CreatedBy ,
            };

            if (salesOrder.Float1 == null)
                salesOrderPM.BalanceAmount = null;
            else
                salesOrderPM.BalanceAmount = Convert.ToDecimal(salesOrder.Float1);

            return salesOrderPM;
        }

        public static IEnumerable<SalesOrder> FromPresentationModels(IEnumerable<SalesOrderPM> salesOrderPMs)
        {
            if (salesOrderPMs == null) return null;
            return salesOrderPMs.Select(FromPresentationModel);
        }

        public static SalesOrder FromPresentationModel(SalesOrderPM salesOrderPM)
        {
            if (salesOrderPM == null) return null;

            SalesOrder salesOrder = new SalesOrder
            {
                Comment = salesOrderPM.Comment,
                ContactNo = salesOrderPM.ContactNo,
                ContactPersonName = salesOrderPM.ContactPersonName,
                CustomerId = salesOrderPM.CustomerId,
                DueDate = salesOrderPM.DueDate,
                Float2 = salesOrderPM.BalanceQuantity,
                LocationId = salesOrderPM.LocationId,
                OrderDate = salesOrderPM.OrderDate,
                OrderType = (byte)salesOrderPM.OrderType,
                PurchaseOrderNumber = salesOrderPM.PurchaseOrderNumber,
                Id = salesOrderPM.Id,
                SalesOrderNumber = salesOrderPM.SalesOrderNumber,
                SalesPersonName = salesOrderPM.SalesPersonName,
                ShipDate = salesOrderPM.ShipDate,
                Status = (byte)salesOrderPM.Status,
                TotalItems = salesOrderPM.TotalItems,
                TotalAmount = salesOrderPM.Amount,
                TotalQuantity = salesOrderPM.Quantity,
                String1 = salesOrderPM.BillingNo ,
            };

            if (salesOrderPM.BalanceAmount == null)
                salesOrder.Float1 = null;
            else
                salesOrder.Float1 = Convert.ToDouble(salesOrderPM.BalanceAmount);

            return salesOrder;
        }

        public static void UpdatePresentationModel(SalesOrderPM salesOrderPM, SalesOrder salesOrder)
        {
            if (salesOrderPM == null || salesOrder == null) return;

            salesOrderPM.BalanceQuantity = salesOrder.Float2;
            salesOrderPM.Comment = salesOrder.Comment;
            salesOrderPM.ContactNo = salesOrder.ContactNo;
            salesOrderPM.ContactPersonName = salesOrder.ContactPersonName;
            salesOrderPM.CustomerId = salesOrder.CustomerId;
            salesOrderPM.DueDate = salesOrder.DueDate;
            salesOrderPM.Id = salesOrder.Id;
            salesOrderPM.LocationId = salesOrder.LocationId;
            salesOrderPM.OrderDate = salesOrder.OrderDate;
            salesOrderPM.OrderType = (ESalesOrderType)salesOrder.OrderType;
            salesOrderPM.PurchaseOrderNumber = salesOrder.PurchaseOrderNumber;
            salesOrderPM.SalesOrderNumber = salesOrder.SalesOrderNumber;
            salesOrderPM.SalesPersonName = salesOrder.SalesPersonName;
            salesOrderPM.ShipDate = salesOrder.ShipDate;
            salesOrderPM.Status = (ESalesOrderStatus)salesOrder.Status;
            salesOrderPM.TotalItems = salesOrder.TotalItems;
            salesOrderPM.Amount = salesOrder.TotalAmount;
            salesOrderPM.Quantity = salesOrder.TotalQuantity;
            salesOrderPM.BillingNo = salesOrder.String1;   

            if (salesOrder.Float1 == null)
                salesOrderPM.BalanceAmount = null;
            else
                salesOrderPM.BalanceAmount = Convert.ToDecimal(salesOrder.Float1);

            foreach (SalesOrderLinePM salesOrderLinePM in salesOrderPM.SalesOrderLines)
            {
                salesOrderLinePM.SalesOrderId = salesOrder.Id;
            }
        }
        public static void UpdateFrom(this SalesOrder existingSalesOrder, SalesOrder salesOrder)
        {
            existingSalesOrder.Comment = salesOrder.Comment;
            existingSalesOrder.ContactNo = salesOrder.ContactNo;
            existingSalesOrder.ContactPersonName = salesOrder.ContactPersonName;
            existingSalesOrder.CustomerId = salesOrder.CustomerId;
            existingSalesOrder.DueDate = salesOrder.DueDate;
            existingSalesOrder.Float1 = salesOrder.Float1;
            existingSalesOrder.Float2 = salesOrder.Float2;
            existingSalesOrder.LocationId = salesOrder.LocationId;
            existingSalesOrder.OrderDate = salesOrder.OrderDate;
            existingSalesOrder.OrderType = salesOrder.OrderType;
            existingSalesOrder.PurchaseOrderNumber = salesOrder.PurchaseOrderNumber;
            existingSalesOrder.SalesOrderNumber = salesOrder.SalesOrderNumber;
            existingSalesOrder.SalesPersonName = salesOrder.SalesPersonName;
            existingSalesOrder.ShipDate = salesOrder.ShipDate;
            existingSalesOrder.TotalItems = salesOrder.TotalItems;
            existingSalesOrder.TotalAmount = salesOrder.TotalAmount;
            existingSalesOrder.TotalQuantity = salesOrder.TotalQuantity;
            existingSalesOrder.String1 = salesOrder.String1;
        }
    }
}
