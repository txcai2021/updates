﻿using System.Collections.Generic;
using System.Linq;


namespace SIMTech.APS.Permission.API.Mappers
{
    using SIMTech.APS.Permission.API.Models;
    using SIMTech.APS.Permission.API.PresentationModels;
    public class RoleMapper
    {
        public static IEnumerable<RolePM> ToPresentationModels(IEnumerable<Role> roles)
        {
            if (roles == null) return null;
            return roles.Select(ToPresentationModel);
        }

        public static RolePM ToPresentationModel(Role role)
        {
            if (role == null) return null;

            return new RolePM
            {
                Description = string.IsNullOrEmpty(role.Description) ? string.Empty : role.Description.Trim(),
                GlobalAccess = role.GlobalAccess,
                Name = string.IsNullOrEmpty(role.RoleName) ? string.Empty : role.RoleName.Trim(),
                RoleId = role.Id,
                StartTaskId = role.StartTaskId,
            };
        }

        public static Role FromPresentationModel(RolePM rolePM)
        {
            if (rolePM == null) return null;

            return new Role
            {
                Description = rolePM.Description,
                GlobalAccess = rolePM.GlobalAccess,
                RoleName = rolePM.Name,
                Id = rolePM.RoleId,
                StartTaskId = rolePM.StartTaskId,
            };
        }

        public static void UpdatePresentationModel(RolePM rolePM, Role role)
        {
            if (rolePM == null || role == null) return;

            rolePM.Description = string.IsNullOrEmpty(role.Description) ? string.Empty : role.Description.Trim();
            rolePM.GlobalAccess = role.GlobalAccess;
            rolePM.Name = string.IsNullOrEmpty(role.RoleName) ? string.Empty : role.RoleName.Trim();
            rolePM.RoleId = role.Id;
            rolePM.StartTaskId = role.StartTaskId;
        }
    }
}
