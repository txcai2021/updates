﻿using System.Collections.Generic;

namespace SIMTech.APS.Location.API.Repository
{
    using SIMTech.APS.Location.API.Models;
    using SIMTech.APS.Repository;
    public interface ILocationRepository : IRepository<Location>
    {     
                   
    }
}
