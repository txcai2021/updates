﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace SIMTech.APS.Inventory.API.Repository
{
    using SIMTech.APS.Inventory.API.Models;
    using SIMTech.APS.Inventory.API.DBContext;
    using SIMTech.APS.Repository;

    public class InventoryRepository : Repository<Inventory>,  IInventoryRepository
    {
        private readonly InventoryContext _dbContext;
        public InventoryRepository(InventoryContext context) : base(context) { _dbContext = context; }
       
    }
}
