﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace SIMTech.APS.DeliveryOrder.API.Mappers
{
    using SIMTech.APS.DeliveryOrder.API.PresentationModels;
    using SIMTech.APS.DeliveryOrder.API.Models;
    using SIMTech.APS.DeliveryOrder.API.Enums;
    public static class DeliveryOrderDetailMapper
    {

        public static IEnumerable<DeliveryOrderLinePM> ToPresentationModels(IEnumerable<DeliveryOrderDetail> deliveryOrderDetails)
        {
            if (deliveryOrderDetails == null) return null;
            return deliveryOrderDetails.Select(ToPresentationModel);
        }

        public static DeliveryOrderLinePM ToPresentationModel(DeliveryOrderDetail deliveryOrderDetail)
        {
            if (deliveryOrderDetail == null) return null;

            var deliveryOrderLinePM = new DeliveryOrderLinePM();
            deliveryOrderLinePM.UpdateFrom(deliveryOrderDetail);

            return deliveryOrderLinePM;
            
        }
     
        public static IEnumerable<DeliveryOrderDetail> FromPresentationModels(IEnumerable<DeliveryOrderLinePM> deliveryOrderDetailPMs)
        {
            if (deliveryOrderDetailPMs == null) return null;
            return deliveryOrderDetailPMs.Select(FromPresentationModel);
        }

        public static DeliveryOrderDetail FromPresentationModel(DeliveryOrderLinePM deliveryOrderDetailPM)
        {
            if (deliveryOrderDetailPM == null) return null;

            var deliveryOrderLine = new DeliveryOrderDetail();
            deliveryOrderLine.UpdateFrom(deliveryOrderDetailPM);

            return deliveryOrderLine;
            
        }

        public static void UpdateFrom(this DeliveryOrderLinePM deliveryOrderLinePM, DeliveryOrderDetail deliveryOrderDetail)
        {
            if (deliveryOrderLinePM == null || deliveryOrderDetail == null) return;

             
             deliveryOrderLinePM.Id = deliveryOrderDetail.Id; 
             deliveryOrderLinePM.DeliveryOrderId = deliveryOrderDetail.DeliveryOrderId;             
             deliveryOrderLinePM.Quantity = deliveryOrderDetail.Quantity;                                  
             deliveryOrderLinePM.SalesOrderLineID = deliveryOrderDetail.SalesOrderLineId;
             deliveryOrderLinePM.Remarks  = deliveryOrderDetail.Comment ;
             
             deliveryOrderLinePM.UnitPrice = deliveryOrderDetail.UnitPrice;
             
             //deliveryOrderLinePM.WorkOrderID = deliveryOrderDetail.WorkOrderID;  
             //deliveryOrderLinePM.WorkOrder = WorkOrderMapper.ToPresentationModel(deliveryOrderDetail.WorkOrder);

             deliveryOrderLinePM.PONumber =deliveryOrderDetail.String1 ;
             deliveryOrderLinePM.PrintedPONumber  =deliveryOrderDetail.String2 ;
             deliveryOrderLinePM.PartId =deliveryOrderDetail.String3 ;
             deliveryOrderLinePM.PartName  =deliveryOrderDetail.String4 ;
             deliveryOrderLinePM.PODueDate  =deliveryOrderDetail.String5 ;
             
             deliveryOrderLinePM.BalanceQuantity  =deliveryOrderDetail.Float1;
             deliveryOrderLinePM.Amount = (decimal?)deliveryOrderDetail.Float2;            
             
        }

        public static void UpdateFrom(this  DeliveryOrderDetail deliveryOrderDetail, DeliveryOrderLinePM deliveryOrderLinePM)
        {
            if (deliveryOrderLinePM == null || deliveryOrderDetail == null) return;

            
            deliveryOrderDetail.Id = deliveryOrderLinePM.Id ;
            deliveryOrderDetail.DeliveryOrderId = deliveryOrderLinePM.DeliveryOrderId;
            deliveryOrderDetail.Quantity= deliveryOrderLinePM.Quantity;
            deliveryOrderDetail.SalesOrderLineId = deliveryOrderLinePM.SalesOrderLineID;
            deliveryOrderDetail.Comment = deliveryOrderLinePM.Remarks;
 
            deliveryOrderDetail.String1 = deliveryOrderLinePM.PONumber;
            deliveryOrderDetail.String2 = deliveryOrderLinePM.PrintedPONumber;
            deliveryOrderDetail.String3 = deliveryOrderLinePM.PartId;
            deliveryOrderDetail.String4 = deliveryOrderLinePM.PartName;
            deliveryOrderDetail.String5 = deliveryOrderLinePM.PODueDate;

            deliveryOrderDetail.UnitPrice = deliveryOrderLinePM.UnitPrice;
           

            deliveryOrderDetail.Float1=deliveryOrderLinePM.BalanceQuantity;
            deliveryOrderDetail.Float2 = (double?)deliveryOrderLinePM.Amount;

        }
      
    }
}
