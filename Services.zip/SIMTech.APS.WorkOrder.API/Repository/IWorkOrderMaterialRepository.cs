﻿using System.Collections.Generic;

namespace SIMTech.APS.WorkOrder.API.Repository
{
    using SIMTech.APS.WorkOrder.API.Models;
    using SIMTech.APS.Repository;
    public interface IWorkOrderMaterialRepository : IRepository<WorkOrderMaterial>
    {     
                   
    }
}
