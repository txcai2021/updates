﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.Location.API.Models
{
    using SIMTech.APS.Models;
    public  class Location : BaseEntity
    {
        public Location()
        {
            InverseParentLocation = new HashSet<Location>();
            ItemLocations = new HashSet<ItemLocation>();
            UserProductLines = new HashSet<UserProductLine>();
        }
       
        public string LocationName { get; set; }
        public string Category { get; set; }
        public string Subcategory { get; set; }
        public string Description { get; set; }
        public int? CalendarId { get; set; }
        public int? ParentLocationId { get; set; }
       

        public virtual Location ParentLocation { get; set; }
        public virtual ICollection<Location> InverseParentLocation { get; set; }
        public virtual ICollection<ItemLocation> ItemLocations { get; set; }
        public virtual ICollection<UserProductLine> UserProductLines { get; set; }
    }
}
