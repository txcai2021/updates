﻿using System.Collections.Generic;
using System.Linq;


namespace SIMTech.APS.Product.Web.Mappers
{
    using SIMTech.APS.Product.API.Models;
    using SIMTech.APS.Product.API.PresentationModels;
    public class KitMapper
    {
        public static IEnumerable<KitPM> ToPresentationModels(IEnumerable<Item> kits)
        {
            if (kits == null) return null;
            return kits.Select(ToPresentationModel);
        }

        public static KitPM ToPresentationModel(Item kit)
        {
            if (kit == null) return null;

            return new KitPM
            {
                Category = string.IsNullOrEmpty(kit.Category) ? string.Empty : kit.Category,
                Description = string.IsNullOrEmpty(kit.Description) ? string.Empty : kit.Description,
                Id = kit.Id,
                Name = string.IsNullOrEmpty(kit.ItemName) ? string.Empty : kit.ItemName,
                NoOfItems = kit.BillOfMaterialProductAssemblies.Count,
                KitTypeId = kit.ParentItemId ?? 0,
                KitTypeName = kit.ParentItem != null ? kit.ParentItem.ItemName : string.Empty,
                CustomerId = kit.Int10 ?? 0,
                //Nitharshan
                IsActive = (kit.Flag2 == null) ? true : (bool)kit.Flag2,
            };
        }

        public static IEnumerable<Item> FromPresentationModels(IEnumerable<KitPM> kitPms)
        {
            if (kitPms == null) return null;
            return kitPms.Select(FromPresentationModel);
        }

        public static Item FromPresentationModel(KitPM kitPM)
        {
            if (kitPM == null) return null;

            return new Item
            {
                Category = kitPM.Category,
                Description = kitPM.Description,
                Id = kitPM.Id,
                ItemName = kitPM.Name,
                ParentItemId = kitPM.KitTypeId,
                Int10 = kitPM.CustomerId,
                //Nitharshan
                Flag2 = kitPM.IsActive,
            };
        }

        
        public static void UpdatePresentationModel(KitPM kitPM, Item kit)
        {
            if (kitPM == null || kit == null) return;

            kitPM.Category = string.IsNullOrEmpty(kit.Category) ? string.Empty : kit.Category;
            //kitPM.Description = string.IsNullOrEmpty(kit.Description) ? string.Empty : kit.Description;
            kitPM.Id = kit.Id;
            //kitPM.Name = string.IsNullOrEmpty(kit.ItemName) ? string.Empty : kit.ItemName;
            //kitPM.KitTypeId = kit.ParentItemID ?? 0;
            //kitPM.KitTypeName = kit.Item2 != null ? kit.Item2.ItemName : string.Empty;
        }
    }
}
