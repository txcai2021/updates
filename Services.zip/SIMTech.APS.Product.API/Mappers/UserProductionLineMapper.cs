﻿using System.Collections.Generic;
using System.Linq;
using SIMTech.APS.Product.Business;
using SIMTech.APS.Product.Web.PresentationModel;

namespace SIMTech.APS.Product.Web.Mappers
{
    public class UserProductionLineMapper
    {
        public static IEnumerable<UserProductionLinePM> ToPresentationModels(IEnumerable<UserProductLine> userProductLines)
        {
            if (userProductLines == null) return null;
            return userProductLines.Select(ToPresentationModel);
        }

        public static UserProductionLinePM ToPresentationModel(UserProductLine userProductLine)
        {
            if (userProductLine == null) return null;

            return new UserProductionLinePM
            {
                Id = userProductLine.UserProductLineID,
                UserId = userProductLine.UserID,
                ProductionLineId = userProductLine.ProductLineID
            };
        }

        public static UserProductLine FromPresentationModel(UserProductionLinePM userProductionLinePM)
        {
            if (userProductionLinePM == null) return null;

            return new UserProductLine
            {
                UserID = userProductionLinePM.UserId,
                ProductLineID = userProductionLinePM.ProductionLineId,
                UserProductLineID = userProductionLinePM.Id,
            };
        }

        public static void UpdatePresentationModel(UserProductionLinePM userProductionLinePM, UserProductLine userProductLine)
        {
            if (userProductionLinePM == null || userProductLine == null) return;

            userProductionLinePM.UserId = userProductLine.UserID;
            userProductionLinePM.Id = userProductLine.UserProductLineID;
            userProductionLinePM.ProductionLineId = userProductLine.ProductLineID;
        }
    }
}
