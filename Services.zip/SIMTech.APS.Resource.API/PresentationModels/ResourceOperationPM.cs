﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
//using SIMTech.APS.Resource.Services.Web;
using SIMTech.APS.Resources;

namespace SIMTech.APS.Resource.API.PresentationModels
{
    
    /// <summary>
    /// Operation class exposes the following data members to the client:
    /// UserName, FirstName, LastName, Mobile, Email, IsLockedOut, Comment, 
    /// LastLoginDate, LastPasswordChangedDate, LastLockoutDate, FailedPasswordAttemptCount,
    /// and CreatedDate
    /// </summary>
    public class ResourceOperationPM
    {
        public ResourceOperationPM()
        {
            //OperationResources = new EntityCollection<OperationResourcePM>();
        }

        [Key]
        [Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
        public int Id { get; set; }


        [Display(ShortName = "OperationId", ResourceType = typeof(SharedResources), Name = "OperationId", Order = 0)]
        public int OperationId { get; set; }

        [Display(ShortName = "ResourceId", ResourceType = typeof(SharedResources), Name = "ResourceId", Order = 1)]
        public int? ResourceId { get; set; }
        

        //[Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
        [Display(ShortName = "Active", ResourceType = typeof(SharedResources), Name = "Active", Order = 2)]
        public Boolean isActive { get; set; }

        //[Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
        [Display(ShortName = "Default", ResourceType = typeof(SharedResources), Name = "Default", Order = 3)]
        public bool? isDefault { get; set; }

        [Display(ShortName = "Cost", ResourceType = typeof(SharedResources), Name = "Cost", Order = 4)]
        public double? Cost { get; set; }

        [Display(ShortName = "Pretime", ResourceType = typeof(SharedResources), Name = "Pretime", Order = 5)]
        public double? Pretime { get; set; }

        [Display(ShortName = "Posttime", ResourceType = typeof(SharedResources), Name = "Posttime", Order = 6)]
        public double? Posttime { get; set; }

        [Display(ShortName = "Duration", ResourceType = typeof(SharedResources), Name = "Duration", Order = 7)]
        public double? Duration { get; set; }

        [Display(ShortName = "DurationPer", ResourceType = typeof(SharedResources), Name = "DurationPer", Order = 8)]
        public double? DurationPer { get; set; }

        [Display(ShortName = "Description", ResourceType = typeof(SharedResources), Name = "Description", Order = 9)]
        public string Description { get; set; }

        [Display(ShortName = "Comments", ResourceType = typeof(SharedResources), Name = "Comments", Order = 10)]
        public string Comment { get; set; }

        [Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
        [Display(ShortName = "CreatedDate", ResourceType = typeof(SharedResources), Name = "CreatedDate", Order = 11)]
        public DateTime CreatedDate { get; set; }

        public DateTime ModifiedDate { get; set; }

        //[Association("FK_ProductBillOfMaterialPM", "ProductHierarchyLevelAId", "ItemID", IsForeignKey = true)]
        //public ProductHierarchyLevelAPM ProductHierarchyLevelA { get; set; }
        
        //[Association("FK_Operation_ResourceOperations", "OperationId", "Id", IsForeignKey = true)]
        //public OperationPM operationPM { get; set; }

        //[Association("FK_ProductBillOfMaterialPM2", "ProductHierarchyLevelCId", "ItemID", IsForeignKey = true)]
        //public ProductHierarchyLevelCPM ProductHierarchyLevelC { get; set; }
        
        [Association("FK_Resource_ResourceOperations", "ResourceId", "Id", IsForeignKey = true)]
        public ResourcePM resourcePM { get; set; }

        //[Include]
        //[Association("FK_Operation", "OperationId", "Id", IsForeignKey = true)]
        //[Display(ShortName = "Operation", ResourceType = typeof(SharedResources), Name = "Operation")]
        //public OperationPM Operation { get; set; }

        //[Include]
        //[Association("FK_Resource", "ResourceId", "Id", IsForeignKey = true)]
        //[Display(ShortName = "Resource", ResourceType = typeof(SharedResources), Name = "Resource")]
        //public ResourcePM Resource { get; set; }


        #region Auxiliary routines
        
        /// <summary>
        /// Validates the given property.
        /// </summary>
        /// <param name="propertyName">Property to validate.</param>
        /// <returns>Validation result.</returns>
        private bool Validate(string propertyName, object value)
        {
            bool flag = false;

            var context = new ValidationContext(this, null, null) { MemberName = propertyName };
            var validationResults = new Collection<System.ComponentModel.DataAnnotations.ValidationResult>();
            if (propertyName == "Password")
                {
                //flag = System.ComponentModel.DataAnnotations.Validator.TryValidateProperty(Password, context, validationResults);
                if (!flag)
                    ShowValidationResults(validationResults);
                }
            else
                flag = true;

            return flag;
        }

        static void ShowValidationResults(Collection<System.ComponentModel.DataAnnotations.ValidationResult> results)
        {
            // Check if the ValidationResults detected any validation errors.
            if (results.Count()==0)
            {
                Console.WriteLine("There were no validation errors.");
            }
            else
            {
                Console.WriteLine("The following {0} validation errors were detected:", results.Count);
                // Iterate through the collection of validation results.
                foreach (ValidationResult item in results)
                {
                    // Show the target member name and current value.
                    //Console.WriteLine("+ Target object: {0}, Member: {1}", GetTypeNameOnly(item.Target), item.Key);
                    // Display details of this validation error.
                    Console.WriteLine("{0}- Message: '{1}'", "  ", item.ErrorMessage);
                }
            }
            Console.WriteLine();
        }

        #endregion Auxiliary routines

    }
}
