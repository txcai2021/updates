﻿using System.ComponentModel.DataAnnotations;
using SIMTech.APS.Resources;

namespace SIMTech.APS.Product.API.PresentationModels
{
    public class ProductionLinePM
    {
        [Key]
        public int Id { get; set; }

        [StringLength(50, ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ValidationErrorBadProductionLineName")]
        [Required(ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ValidationErrorRequiredField")]
        [Display(ShortName = "ProductionLineName", ResourceType = typeof(SharedResources), Name = "ProductionLineName")]
        public string Name { get; set; }

        [StringLength(250, ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ValidationErrorBadProductionLineDescription")]
        [Display(ShortName = "ProductionLineDescription", ResourceType = typeof(SharedResources), Name = "ProductionLineDescription")]
        public string Description { get; set; }

        [Required(ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ValidationErrorRequiredField")]
        [Display(ShortName = "ProductionLineUnitId", ResourceType = typeof(SharedResources), Name = "ProductionLineUnitId")]
        public int? UnitId { get; set; }

        [Display(ShortName = "ProductionLineUnitName", ResourceType = typeof(SharedResources), Name = "ProductionLineUnitName")]
        public string UnitName { get; set; }

        [Display(ShortName = "NoOfUsers", ResourceType = typeof(SharedResources), Name = "NoOfUsers")]
        public int NoOfUsers { get; set; }

        [Display(ShortName = "NoOfKitTypes", ResourceType = typeof(SharedResources), Name = "NoOfKitTypes")]
        public int NoOfKitTypes { get; set; }
    }
}
