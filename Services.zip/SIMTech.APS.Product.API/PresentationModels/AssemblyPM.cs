﻿using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;

namespace SIMTech.APS.Product.API.PresentationModels
{
    public class AssemblyPM
    {
        [Key]
        public int Id { get; set; }
        public List<ComponetPM> Components {get;set;}

    }

    public class ComponetPM
    {
        
        public int assignedPartId { get; set; }
        public double quantity { get; set; }
        public int sequence { get; set; }
    }
}
