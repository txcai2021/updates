﻿using System;
using System.ComponentModel.DataAnnotations;

namespace SIMTech.APS.Product.API.PresentationModels
{
    public class WorkOrderInventoryPM
    {
      //  [Key]
        public int Id { get; set; }

        public int InventoryId { get; set; }

                
        public int UsedByOrderId { get; set; }

        public string WorkOrderNumber{ get; set; }

        public decimal? DOQty { get; set; }
           
        public decimal? Quantity { get; set; }

        public DateTime Createdon { get; set; }
        
        public string Status { get; set; }
        public string Customer { get; set; }

        public string string1 { get; set; }

        public string string2 { get; set; }

        public string CreatedBy { get; set; }

        public double? AllocQty { get; set; }

        public double? Ratio { get; set; }

        public bool allocated { get; set; }

        public double? Cost { get; set; }

        public decimal? dec1 { get; set; }
        public decimal? dec2 { get; set; }

        public double? val1 { get; set; }
        public double? val2 { get; set; }

        public DateTime DateOut { get; set; }
     }
}
