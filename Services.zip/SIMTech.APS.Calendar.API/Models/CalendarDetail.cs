﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.Calendar.API.Models
{
    using SIMTech.APS.Models;
    public  class CalendarDetail : BaseEntity
    {
       
        public string CalendarDetailName { get; set; }
        public int ParentCalendarId { get; set; }
        public int CalendarId { get; set; }
        public int Sequence { get; set; }
        public int? Priority { get; set; }
        public int? Interval { get; set; }
        public string Value { get; set; }
        
        public virtual Calendar Calendar { get; set; }
        public virtual Calendar ParentCalendar { get; set; }
    }
}
