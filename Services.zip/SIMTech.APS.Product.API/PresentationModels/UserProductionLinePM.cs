﻿using System.ComponentModel.DataAnnotations;

namespace SIMTech.APS.Product.API.PresentationModels
{
    public class UserProductionLinePM
    {
        [Key]
        public int Id { get; set; }

        public int UserId { get; set; }

        public int ProductionLineId { get; set; }
    }
}
