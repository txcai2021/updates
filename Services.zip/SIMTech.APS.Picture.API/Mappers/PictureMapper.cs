﻿using System.Collections.Generic;
using System.Linq;


namespace SIMTech.APS.Picture.API.Mappers
{
    using SIMTech.APS.PresentationModels;
    using SIMTech.APS.Picture.API.Models;
    public class PictureMapper
    {
        public static IEnumerable<PicturePM> ToPresentationModels(IEnumerable<Picture> pictures)
        {
            return pictures == null ? null : pictures.Select(ToPresentationModel);
        }

        public static PicturePM ToPresentationModel(Picture picture)
        {
            if (picture == null) return null;

            return new PicturePM
            {
                PictureID  = picture.Id ,
                ThumbnailImageFileName =  picture.ThumbnailImageFileName??"",
                ThumbNailImage = picture.ThumbNailImage,
                LargeImageFileName = picture.LargeImageFileName ??"",
                LargeImage = picture.LargeImage,
            };
        }


        public static IEnumerable<Picture> FromPresentationModels(IEnumerable<PicturePM> picturePMs)
        {
            return picturePMs == null ? null : picturePMs.Select(FromPresentationModel);
        }

        public static Picture FromPresentationModel(PicturePM picturePM)
        {
            if (picturePM == null) return null;

            return new Picture
            {
                Id = picturePM.PictureID,
                ThumbnailImageFileName = picturePM.ThumbnailImageFileName,
                ThumbNailImage = picturePM.ThumbNailImage,
                LargeImageFileName = picturePM.LargeImageFileName,
                LargeImage = picturePM.LargeImage,
            };
        }


        public static void UpdateEntity(PicturePM picturePM, Picture picture)
        {
            if (picturePM == null || picture == null) return;
            picture.ThumbnailImageFileName = picturePM.ThumbnailImageFileName;
            picture.ThumbNailImage = picturePM.ThumbNailImage;
            picture.LargeImageFileName = picturePM.LargeImageFileName;
            picture.LargeImage = picturePM.LargeImage;             
        }

        
    }
}
