﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.Permission.API.Models
{
    using SIMTech.APS.Models;
    public partial class Menu :BaseEntity
    {
       
        public int ParentTaskId { get; set; }
        public int TaskId { get; set; }
        public int SortSequence { get; set; }

        public virtual Task ParentTask { get; set; }
        public virtual Task Task { get; set; }
    }
}
