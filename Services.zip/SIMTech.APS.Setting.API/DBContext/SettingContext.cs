﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace SIMTech.APS.Setting.API.DBContext
{
    using SIMTech.APS.Setting.API.Models;
    public partial class SettingContext : DbContext
    {
        public SettingContext()
        {
        }

        public SettingContext(DbContextOptions<SettingContext> options)
            : base(options)
        {
        }

        public virtual DbSet<CodeDetail> CodeDetails { get; set; }
        public virtual DbSet<CodeType> CodeTypes { get; set; }
        public virtual DbSet<CodeUsage> CodeUsages { get; set; }
        public virtual DbSet<Option> Options { get; set; }
        public virtual DbSet<UserPreference> UserPreferences { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<CodeDetail>(entity =>
            {
                entity.ToTable("CodeDetail");

                entity.Property(e => e.CodeNo)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Description).HasMaxLength(250);

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn).HasColumnType("datetime");


                //entity.Property(e => e.VersionStamp)
                //    .IsRequired()
                //    .IsRowVersion()
                //    .IsConcurrencyToken();

                entity.HasOne(d => d.CodeType)
                    .WithMany(p => p.CodeDetails)
                    .HasForeignKey(d => d.CodeTypeId)
                    .HasConstraintName("FK_CodeDetail_CodeType");
            });

            modelBuilder.Entity<CodeType>(entity =>
            {
                entity.ToTable("CodeType");

                entity.Property(e => e.CodeTypeName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DataType).HasMaxLength(50);

                entity.Property(e => e.Description).HasMaxLength(250);

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn).HasColumnType("datetime");

                //entity.Property(e => e.VersionStamp)
                //    .IsRequired()
                //    .IsRowVersion()
                //    .IsConcurrencyToken();
            });

            modelBuilder.Entity<CodeUsage>(entity =>
            {
                entity.ToTable("CodeUsage");

                entity.Property(e => e.ColumnName).HasMaxLength(50);

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn).HasColumnType("datetime");

                entity.Property(e => e.TableName).HasMaxLength(50);

                //entity.Property(e => e.VersionStamp)
                //    .IsRequired()
                //    .IsRowVersion()
                //    .IsConcurrencyToken();

                entity.HasOne(d => d.CodeType)
                    .WithMany(p => p.CodeUsages)
                    .HasForeignKey(d => d.CodeTypeId)
                    .HasConstraintName("FK_CodeUsage_CodeType");
            });

            modelBuilder.Entity<Option>(entity =>
            {
                entity.ToTable("Option");

                entity.HasIndex(e => new { e.ModuleName, e.OptionName }, "IX_Option_OptionName")
                    .IsUnique();

                entity.Property(e => e.Category)
                    .HasMaxLength(50)
                    .IsFixedLength(true);

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DataType)
                    .HasMaxLength(50)
                    .IsFixedLength(true);

                entity.Property(e => e.Description).HasMaxLength(250);

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn).HasColumnType("datetime");

                entity.Property(e => e.ModuleName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.OptionName)
                    .IsRequired()
                    .HasMaxLength(50);

                //entity.Property(e => e.VersionStamp)
                //    .IsRequired()
                //    .IsRowVersion()
                //    .IsConcurrencyToken();
            });

            modelBuilder.Entity<UserPreference>(entity =>
            {
                entity.ToTable("UserPreference");

                entity.HasIndex(e => new { e.UserId, e.OptionId }, "IX_UserPreference_UserOptionId")
                    .IsUnique();

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn).HasColumnType("datetime");

                //entity.Property(e => e.VersionStamp)
                //    .IsRequired()
                //    .IsRowVersion()
                //    .IsConcurrencyToken();

                entity.HasOne(d => d.Option)
                    .WithMany(p => p.UserPreferences)
                    .HasForeignKey(d => d.OptionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__UserPrefe__Optio__51300E55");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
