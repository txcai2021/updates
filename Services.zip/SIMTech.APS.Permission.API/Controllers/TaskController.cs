﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Transactions;
using System.Threading.Tasks;


namespace SIMTech.APS.Permission.API.Controllers
{
    using SIMTech.APS.Permission.API.Repository;
    using SIMTech.APS.Permission.API.Models;
    using SIMTech.APS.Permission.API.PresentationModels;

    [Route("api/[controller]")]
    [ApiController]
    public class TaskController : ControllerBase
    {
        private readonly ITaskRepository _taskRepository;

        public TaskController(ITaskRepository TaskRepository)
        {
            _taskRepository = TaskRepository;
        }


        //GET: api/Role
        [HttpGet]
        public async Task<IEnumerable<Task>> GetAllTasks() => await _taskRepository.GetAll();

        [HttpGet]
        [Route("{id}")]
        public Task GetTaskById(int id) => _taskRepository.GetById(id);


        [HttpPost]
        public void AddTask([FromBody] Task Task) => _taskRepository.Insert(Task);

        [HttpPut]
        public void UpdateTask([FromBody] Task Task) => _taskRepository.Update(Task);



        // DELETE api/<RoleController>/5
        [HttpDelete("{id}")]
        public void DeleteTask(int id) => _taskRepository.Delete(id);

    }
}
