﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SIMTech.APS.User.API.Models
{
    using SIMTech.APS.Models;
    public partial class User : BaseEntity
    {
        public string LoginId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public string PasswordHash { get; set; }
        public string PasswordSalt { get; set; }
        public string PasswordQuestion { get; set; }
        public string PasswordAnswerHash { get; set; }
        public string PasswordAnswerSalt { get; set; }
        public bool? IsLockedOut { get; set; }
        public DateTime? LastLoginDate { get; set; }
        public DateTime? LastPasswordChangedDate { get; set; }
        public DateTime? LastLockoutDate { get; set; }
        public int? FailedPasswordAttemptCount { get; set; }
        public string LanguageCode { get; set; }
        public string Comment { get; set; }
        public int? PictureId { get; set; }
        public int? SignatureId { get; set; }
    }

    public class UserRole
    {

        public int UserId { get; set; }
        public int RoleId { get; set; }

    }

    public class Role
    {

        public int Id { get; set; }
        public string RoleName { get; set; }

    }
}

