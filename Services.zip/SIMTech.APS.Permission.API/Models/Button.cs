﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.Permission.API.Models
{
    using SIMTech.APS.Models;
    public partial class Button : BaseEntity
    {
        public Button()
        {
            Tasks = new HashSet<Task>();
        }

        public string ButtonName { get; set; }
        public string Type { get; set; }
        public string DisplayText { get; set; }
        public string ImageFileName { get; set; }
        public byte[] Image { get; set; }
        public string Description { get; set; }
        
        public virtual ICollection<Task> Tasks { get; set; }
    }
}
