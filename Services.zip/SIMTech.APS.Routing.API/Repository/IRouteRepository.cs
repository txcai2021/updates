﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace SIMTech.APS.Routing.API.Repository
{
    using SIMTech.APS.Routing.API.Models;
    using SIMTech.APS.Repository;
    public interface IRouteRepository : IRepository<Route>
    {
        Task<IEnumerable<Route>> GetRoutes(int routeId=0, bool template =true);

        Task<IEnumerable<Route>> GetRoutes(string routeIds);

        Task<IEnumerable<Route>> GetRoutesbyOperation(int opeartionId);
    }
}
