﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.Routing.API.Models
{
    using SIMTech.APS.Models;
    public  class Route : BaseEntity
    {
        public Route()
        {
            ProductRoutes = new HashSet<ProductRoute>();
            RouteOperationRoutes = new HashSet<RouteOperation>();
            RouteOperationSubroutes = new HashSet<RouteOperation>();
        }
 
        public string RouteName { get; set; }
        public byte Type { get; set; }
        public string Description { get; set; }
        public string Comment { get; set; }
        public int? Version { get; set; }
        public bool IsActive { get; set; }
        public bool? IsDefault { get; set; }
        public int? LocationId { get; set; }
        public byte? TraceLevel { get; set; }
   

        public virtual ICollection<ProductRoute> ProductRoutes { get; set; }
        public virtual ICollection<RouteOperation> RouteOperationRoutes { get; set; }
        public virtual ICollection<RouteOperation> RouteOperationSubroutes { get; set; }
    }
}
