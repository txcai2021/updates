﻿using System.Collections.Generic;
using System.Linq;


namespace SIMTech.APS.WorkOrder.API.Mappers
{
    using SIMTech.APS.WorkOrder.API.Models;
    using SIMTech.APS.WorkOrder.API.PresentationModels;
    using SIMTech.APS.WorkOrder.API.Enums;

    public static class WIPMapper
    {
        public static IEnumerable<WIP> ToPresentationModels(IEnumerable<WIP1> wips)
        {
            if (wips == null) return null;
            return wips.Select(ToPresentationModel);
        }

        public static WIP ToPresentationModel(WIP1 wip)
        {
            if (wip == null) return null;

            return new WIP
            {
                ActualRecDate = wip.ActualRecDate,
                ActualRecQty = wip.ActualRecQty,
                RouteId = wip.RouteId,
                CompletedDate = wip.CompletedDate,
                CompletedQty = wip.CompletedQty,
                MachineName = wip.MachineName,
                OperationName = wip.OperationName,
                OutstandingDate = wip.OutstandingDate,
                OutstandingQty = wip.OutstandingQty,
                ProdStartDate = wip.ProdStartDate,
                ScrapDate = wip.ScrapDate,
                ScrapQty = wip.ScrapQty,
                Sequence = wip.Sequence,
                Status = wip.Status,
                WorkOrderNumber = wip.WorkOrderNumber
            };

        }

    }
}
