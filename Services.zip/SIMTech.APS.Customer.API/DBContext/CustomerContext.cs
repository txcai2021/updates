﻿
using Microsoft.EntityFrameworkCore;


#nullable disable

namespace SIMTech.APS.Customer.API.DBContext
{
    using SIMTech.APS.Customer.API.Models;
    public  class CustomerContext : DbContext
    {
        public CustomerContext()
        {
        }

        public CustomerContext(DbContextOptions<CustomerContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Customer> Customers { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<Customer>(entity =>
            {
                entity.ToTable("Customer");

                entity.HasIndex(e => new { e.CustomerName, e.Category }, "IX_Customer_CustomerName")
                    .IsUnique();

                entity.Property(e => e.Address).HasMaxLength(250);

                entity.Property(e => e.BillingAddress).HasMaxLength(250);

                entity.Property(e => e.Category)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.CompanyName).HasMaxLength(250);

                entity.Property(e => e.ContactPerson).HasMaxLength(50);

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                //entity.Property(e => e.CreatedOn)
                //    .HasColumnType("datetime")
                //    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.CustomerName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Email).HasMaxLength(250);

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                //entity.Property(e => e.ModifiedOn)
                //    .HasColumnType("datetime")
                //    .HasComputedColumnSql("(getdate())", false);

                entity.Property(e => e.Phone).HasMaxLength(50);

                entity.Property(e => e.PictureId).HasColumnName("PictureID");

                entity.Property(e => e.String1).HasMaxLength(50);

                entity.Property(e => e.String2).HasMaxLength(50);

                entity.Property(e => e.String3).HasMaxLength(50);

                entity.Property(e => e.String4).HasMaxLength(50);

                entity.Property(e => e.String5).HasMaxLength(50);

                //entity.Property(e => e.VersionStamp)
                //    .IsRequired()
                //    .IsRowVersion()
                //    .IsConcurrencyToken();
            });

        }

    }
}
