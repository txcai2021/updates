﻿using System.ComponentModel.DataAnnotations;

namespace SIMTech.APS.Permission.API.PresentationModels
{
    public class DevOptionPM
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public string DefaultSetting { get; set; }
        public string Description { get; set; }
        public string string1 { get; set; }
        public string string2 { get; set; }
        public int int1 { get; set; }

        public int XmlId { get; set; }
        public string XmlName { get; set; }
        public string XmlDefaultSetting { get; set; }
        public int XmlType { get; set; }
        public string DBMenu { get; set; }
        public string ModuleName { get; set; }
        public string Type { get; set; }
        public string ActionName { get; set; }
        public string DisplayText { get; set; }
        public string ImageFile { get; set; }
        public string ParentMenu { get; set; }
        public bool IsMenuExisted { get; set; }
        public bool IsMenuNotExisted { get; set; }
      
    }
}
