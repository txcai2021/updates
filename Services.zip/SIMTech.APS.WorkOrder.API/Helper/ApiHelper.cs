﻿using System;
using System.Collections.Generic;

namespace SIMTech.APS.WorkOrder.API.Helper
{
    using SIMTech.APS.PresentationModels;
    using SIMTech.APS.Product.API.PresentationModels;
    using SIMTech.APS.SalesOrder.API.PresentationModels;
    using SIMTech.APS.Utilities;
    using SIMTech.APS.WorkOrder.API.PresentationModels;

    public class ApiHelper
    {
        private ApiHelper() { }

        public static Dictionary<int, RawMaterialPM> ApiGetRawMaterialAsDictionary()
        {
            var apiBaseUrl = Environment.GetEnvironmentVariable("RPS_PRODUCT_URL");
            var dictionary = new Dictionary<int, RawMaterialPM>();

            if (!string.IsNullOrWhiteSpace(apiBaseUrl))
            {
                try
                {
                    var rawMaterials = HttpHelper.Get<List<RawMaterialPM>>(apiBaseUrl, "Material");

                    rawMaterials.ForEach(rm => dictionary.Add(rm.Id, rm));
                }
                catch (Exception e)
                {
                    Console.WriteLine($"Unable to retrieve Raw Materials from API, Endpoint: {apiBaseUrl}, Error: {e.Message}");
                }
            }

            return dictionary;
        }

        public static List<IdNamePM> ApiGetProducts(string itemsId)
        {
            var product = new List<IdNamePM>();
            var apiBaseUrl = Environment.GetEnvironmentVariable("RPS_PRODUCT_URL");

            if (!string.IsNullOrWhiteSpace(apiBaseUrl))
            {
                try
                {
                    product = HttpHelper.Get<List<IdNamePM>>(apiBaseUrl, $"IdName/{itemsId}");
                }
                catch (Exception e)
                {
                    Console.WriteLine("Error in getting assembies/parts:" + $"IdName/{itemsId}");
                    Console.WriteLine(e.Message);
                    if (e.InnerException != null) Console.WriteLine(e.InnerException.Message);
                }
            }

            return product;
        }

        public static List<BasePM> ApiGetCustomers(string customerIds)
        {
            var customers = new List<BasePM>();
            var apiBaseUrl = Environment.GetEnvironmentVariable("RPS_CUSTOMER_URL");

            if (!string.IsNullOrWhiteSpace(apiBaseUrl))
            {
                try
                {
                    customers = HttpHelper.Get<List<BasePM>>(apiBaseUrl, $"IdName/{customerIds}");

                }
                catch (Exception e)
                {
                    Console.WriteLine("Error in getting customers:" + $"IdName/{customerIds}");
                    Console.WriteLine(e.Message);
                    if (e.InnerException != null) Console.WriteLine(e.InnerException.Message);
                }
            }

            return customers ?? new List<BasePM>();
        }

        public static List<RoutePM> ApiGetRoutes(List<int> routeIds)
        {
            var routes = new List<RoutePM>();
            var apiBaseUrl = Environment.GetEnvironmentVariable("RPS_ROUTE_URL");

            if (!string.IsNullOrWhiteSpace(apiBaseUrl) && routeIds?.Count > 0)
            {
                foreach(var routeId in routeIds)
                {
                    try
                    {
                        routes.Add(HttpHelper.Get<RoutePM>(apiBaseUrl, $"{routeId}"));
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("Error in getting routing:" + $"{routeId}");
                        Console.WriteLine(e.Message);
                        if (e.InnerException != null) Console.WriteLine(e.InnerException.Message);
                    }
                }

            }

            return routes;
        }

        public static List<BasePM> ApiGetLocations(string locationIds)
        {
            var locations = new List<BasePM>();
            var apiBaseUrl = Environment.GetEnvironmentVariable("RPS_LOCATION_URL");

            if (!string.IsNullOrWhiteSpace(apiBaseUrl))
            {
                try
                {
                    locations = HttpHelper.Get<List<BasePM>>(apiBaseUrl, $"IdName/{locationIds}");
                }
                catch (Exception e)
                {
                    Console.WriteLine("Error in getting locations:" + $"DetailIds/{locationIds}");
                    Console.WriteLine(e.Message);
                    if (e.InnerException != null) Console.WriteLine(e.InnerException.Message);
                }
            }

            return locations ?? new List<BasePM>();
        }

        public static List<SalesOrderPM> ApiGetSalesOrders(string soDetIds)
        {
            var salesOrders = new List<SalesOrderPM>();
            var apiBaseUrl = Environment.GetEnvironmentVariable("RPS_SALESORDER_URL");

            if (!string.IsNullOrWhiteSpace(apiBaseUrl))
            {
                try
                {
                    salesOrders = HttpHelper.Get<List<SalesOrderPM>>(apiBaseUrl, $"DetailIds/{soDetIds}");
                }
                catch (Exception e)
                {
                    Console.WriteLine("Error in getting sales order:" + $"DetailIds/{soDetIds}");
                    Console.WriteLine(e.Message);
                    if (e.InnerException != null) Console.WriteLine(e.InnerException.Message);
                }
            }

            return salesOrders ?? new List<SalesOrderPM>();
        }
    }
}
