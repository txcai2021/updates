﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace SIMTech.APS.Setting.API.Repository
{
    using SIMTech.APS.Setting.API.Models;
    using SIMTech.APS.Setting.API.DBContext;
    using SIMTech.APS.Repository;

    public class CodeRepository : Repository<CodeType>,  ICodeRepository
    {
        private readonly SettingContext _dbContext;
        public CodeRepository(SettingContext context) : base(context) { _dbContext = context; }

        public IEnumerable<CodeType> GetCodes(int codeId = 0)
        {
            var codes = _dbContext.CodeTypes.Include(x => x.CodeDetails).ToList ();
            if (codeId > 0)
            {
                codes = codes.Where(x => x.Id == codeId).ToList();
            }

            return RemoveCycleReference(codes);
        }
        public IEnumerable<CodeType> GetCodesbyName(string codeName = "")
        {
            var codes = _dbContext.CodeTypes.Include(x => x.CodeDetails).Where (x=>x.CodeTypeName ==codeName).ToList();

            return RemoveCycleReference(codes);
        }

        private List<CodeType> RemoveCycleReference(List<CodeType> codes)
        {
            foreach (var code in codes)
            {
                foreach (var codeDetail in code.CodeDetails)
                    codeDetail.CodeType = null;
            }

            return codes;
        }

    }
}
