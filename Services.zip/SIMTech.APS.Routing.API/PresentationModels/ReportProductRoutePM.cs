﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using SIMTech.APS.Resources;
using System.Collections.Generic;

namespace SIMTech.APS.Routing.API.PresentationModels
{
    public class ReportProductRoutePM 
    {
        public ReportProductRoutePM() 
        {
                       
        }

        [Key]
        [Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
        public int Id { get; set; }

        public string RouteName { get; set; }

        public string OperationName { get; set; }

        public int Sequence { get; set; }

        public byte Type { get; set; }

        public byte? TraceLevel { get; set; }

        public string Description { get; set; }
        
        public string Comment { get; set; }

        public string Instruction { get; set; }

        public string OperationResourceName { get; set; }

        public string OperationParameterReport { get; set; }

        public Boolean IsParameter { get; set; }

        public Boolean IsThumbNailImage { get; set; }
        public byte[] ThumbNailImage { get; set; }
        public string ThumbnailImageFileName { get; set; }

        public Boolean IsLargeImage { get; set; }
        public byte[] LargeImage { get; set; }
        
        public string LargeImageFileName { get; set; }
        public string ThumbNailImageFileName { get; set; }

        public int OperationDataCollectionId { get; set; }

        public string OperationDataCollectionName { get; set; }

        public string OperationDataCollectionUOM { get; set; }

        public string OperationDataCollectionReport { get; set; }

        public short? NoofReading { get; set; }

        public Boolean IsDataCollection { get; set; }

        public string OperationSParameterReport { get; set; }
        
        public Boolean IsSParameter { get; set; }

        public string OK { get; set; }
        public string NG { get; set; }

        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }

        public Boolean? TrackLevel { get; set; }

        public Boolean IsRoute { get; set; }

        #region Auxiliary methods

        #endregion
    }
}
