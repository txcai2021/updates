﻿using System.Collections.Generic;
using System.Linq;
using SIMTech.APS.Product.Business;
using SIMTech.APS.Product.Web.PresentationModel;

namespace SIMTech.APS.Product.Web.Mappers
{
    public class ProductionLineMapper
    {
        public static IEnumerable<ProductionLinePM> ToPresentationModels(IEnumerable<Location> locations)
        {
            if (locations == null) return null;
            return locations.Select(ToPresentationModel);
        }

        public static ProductionLinePM ToPresentationModel(Location location)
        {
            if (location == null) return null;

            return new ProductionLinePM
            {
                Description = string.IsNullOrEmpty(location.Description) ? string.Empty : location.Description,
                Id = location.LocationId,
                Name = string.IsNullOrEmpty(location.LocationName) ? string.Empty : location.LocationName,
                UnitId = location.ParentLocationId,
                UnitName = location.Location2 != null ? location.Location2.LocationName : string.Empty,
                NoOfUsers = location.UserProductLines.Count,
                NoOfKitTypes = location.ItemLocations.Count
            };
        }

        public static IEnumerable<Location> FromPresentationModels(IEnumerable<ProductionLinePM> productionLinePms)
        {
            if (productionLinePms == null) return null;
            return productionLinePms.Select(FromPresentationModel);
        }

        public static Location FromPresentationModel(ProductionLinePM productionLinePM)
        {
            if (productionLinePM == null) return null;

            return new Location
            {
                Description = productionLinePM.Description,
                LocationId = productionLinePM.Id,
                LocationName = productionLinePM.Name,
                ParentLocationId = productionLinePM.UnitId
            };
        }

        public static void UpdatePresentationModel(ProductionLinePM productionLinePM, Location location)
        {
            if (productionLinePM == null || location == null) return;

            productionLinePM.Description = string.IsNullOrEmpty(location.Description) ? string.Empty : location.Description;
            productionLinePM.Id = location.LocationId;
            productionLinePM.Name = string.IsNullOrEmpty(location.LocationName) ? string.Empty : location.LocationName;
            productionLinePM.UnitId = location.ParentLocationId;
        }
    }
}
