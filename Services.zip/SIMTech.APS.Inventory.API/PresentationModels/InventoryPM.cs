﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using SIMTech.APS.Resources;

namespace SIMTech.APS.Inventory.API.PresentationModels
{
    public class InventoryPM
    {
        public InventoryPM()
        {
            InventoryUsages = new List<InventoryUsagePM>();
        }

        [Key]
        public int Id { get; set; }
         
        public string Type { get; set; }

        public int? LocationId { get; set; }

        [Display(ShortName = "Date In", Name = "Date In")]
        public DateTime DateIn { get; set; }

        public int PartId { get; set; }
        [Display(ShortName = "Product No", Name = "Product No")]
        public string PartNo { get; set; }
        [Display(ShortName = "Product Name", Name = "Product Name")]
        public string PartName { get; set; }
        [Display(ShortName = "Product Family", Name = "Product Family")]
        public string PartFamily { get; set; }
       
        public int? CustomerId { get; set; }      
        [Display(ShortName = "Customer", Name = "Customer")]
        public string CustomerCode { get; set; }

        public int? WorkOrderId { get; set; }
        [Display(ShortName = "Work Order Number", Name = "Work Order Number")]
        public string WorkOrderNumber { get; set; }

        [Display(ShortName = "Completed Qty", Name = "Completed Qty")]
        public decimal? CompletedQty { get; set; }

        [Display(ShortName = "Balanced FG Qty", Name = "Balanced FG Qty")]
        public decimal? BalancedQty { get; set; }

        [Display(ShortName = "DO Qty", Name = "DO Qty")]
        public decimal? DOQty { get; set; }

        [Display(ShortName = "WO Qty", Name = "WO Qty")]
        public decimal? WOQty { get; set; }

        [Display(ShortName = "Remarks", Name = "Remarks")]
        public string Remarks { get; set; }

        [Display(ShortName = "Created By", Name = "Created By")]
        public string CreatedBy { get; set; }

        [Display(ShortName = "Operation", Name = "Operation")]
        public string OperationName { get; set; }

        public int? SeqNo { get; set; }

        public int? AssemblyId{ get; set; }

        public string Status { get; set; }

        public bool InStock { get; set; }

        public bool Allocated { get; set; }

        public decimal? Cost { get; set; }

        public decimal? BalanceCost { get; set; }

        public IEnumerable<InventoryUsagePM> InventoryUsages { get; set; }
     }
}
