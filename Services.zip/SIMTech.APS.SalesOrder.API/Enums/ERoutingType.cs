﻿namespace SIMTech.APS.SalesOrder.API.Enums
{ 
    public enum ERoutingType
    {
        AND,
        OR
    }
}
