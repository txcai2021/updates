﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;



namespace SIMTech.APS.Operation.API.Repository
{
    using SIMTech.APS.Operation.API.Models;
    using SIMTech.APS.Operation.API.DBContext;
    using SIMTech.APS.Repository;

    public class OperationRateRepository : Repository<OperationRate>,  IOperationRateRepository
    {
        private readonly OperationContext _dbContext;
        public OperationRateRepository(OperationContext context) : base(context) { _dbContext = context; }

        public async Task<int> CopyOperationRate(int routeId, int routeOperationId, int newRouteId, int newRouteOperationId)
        {
            var operationRates = await _dbContext.OperationRates.Where(x => x.RouteId == routeId && x.RouteOperationId ==routeOperationId).ToListAsync();

            int count = 0;

            foreach (var opr in operationRates)
            {
                var copiedOperationRate = new OperationRate()
                {
                    RouteId = newRouteId,
                    RouteOperationId=newRouteOperationId,
                    OperationId=opr.OperationId,
                    ResourceId=opr.ResourceId ,
                    ItemId =opr.ItemId ,
                    Instruction = opr.Instruction,
                    Cost = opr.Cost,
                    Pretime = opr.Pretime,
                    Posttime = opr.Posttime,
                    Uom = opr.Uom,
                    RunTime=opr.RunTime ,
                    IsDefault =opr.IsDefault ,
                    CreatedBy =opr.CreatedBy,
                    ModifiedBy =opr.ModifiedBy 
                };
                _dbContext.OperationRates.Add(copiedOperationRate);
                count++;
            }

            await _dbContext.SaveChangesAsync();
            return count;
        }

    }
}
