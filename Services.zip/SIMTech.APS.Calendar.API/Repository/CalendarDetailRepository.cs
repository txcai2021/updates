﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace SIMTech.APS.Calendar.API.Repository
{
    using SIMTech.APS.Calendar.API.Models;
    using SIMTech.APS.Calendar.API.DBContext;
    using SIMTech.APS.Repository;

    public class CalendarDetailRepository : Repository<CalendarDetail>,  ICalendarDetailRepository
    {
        private readonly CalendarContext _dbContext;
        public CalendarDetailRepository(CalendarContext context) : base(context) { _dbContext = context; }
       
    }
}
