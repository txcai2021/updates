﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.Routing.API.Models
{
    using SIMTech.APS.Models;
    public  class ProductRouteStatus : BaseEntity
    {

        public int ProductRouteId { get; set; }
        public int StepNo { get; set; }
        public string ApprovedBy { get; set; }
        public bool IsApproved { get; set; }
        public string Remarks { get; set; }

        public virtual ProductRoute ProductRoute { get; set; }
    }
}
