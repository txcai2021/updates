﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;

namespace SIMTech.APS.Routing.API.Mappers
{
    using SIMTech.APS.Routing.API.Models;
    using SIMTech.APS.Routing.API.PresentationModels;
    

    /// <summary>
    /// Maps  PMs (Presentation Models) to  BOs (Business Objects) and vice versa.
    /// </summary>
    public static class RouteMapper
    {

        /// <summary>
        /// Transforms list of route BOs list of route PMs.
        /// </summary>
        /// <param name="routes">List of route BOs.</param>
        /// <returns>List of route PMs.</returns>
        public static IList<RoutePM> ToPresentationModels(IEnumerable<Route> routes)
        {
            if (routes == null) return null;
            return routes.Select(u => ToPresentationModel(u)).ToList();
        }

        /// <summary>
        /// Transforms route BO to route PM.
        /// </summary>
        /// <param name="route">route BO.</param>
        /// <returns>route PM.</returns>
        public static RoutePM ToPresentationModel(Route route)
        {
            if (route == null) return null;

            return new RoutePM
            {
                Id = route.Id,
                Name = route.RouteName,
                LocationId = route.LocationId,

                Type = route.Type,
                Active = route.IsActive,
                Version = route.Version,
                TraceLevel = route.TraceLevel,

                TrackLevel = route.TraceLevel == 1 ? true : false,

                Description = route.Description,
                ProductFamily = route.Comment,
                RouteOperationPMs = RouteOperationMapper.ToPresentationModels(route.RouteOperationRoutes).ToList(),
                //ProductRoutePMs = ProductRouteMapper.ToPresentationModels(route.ProductRoutes).ToList(),
                PartName = route.ProductRoutes.FirstOrDefault(x => x.Remarks == null || x.Remarks == "Y")==null? "":route.ProductRoutes.FirstOrDefault(x=> x.Remarks==null || x.Remarks=="Y").ProductId.ToString(),
                PartList = route.ProductRoutes.Select(x=>x.ProductId).ToList(),
                NoofParts = route.ProductRoutes.Count(),
                operations = route.RouteOperationRoutes.Count(),
                CreatedBy = route.CreatedBy,
                ModifiedBy = route.ModifiedBy, 

                CreatedDate = route.CreatedOn,
                ModifiedDate = route.ModifiedOn, 
            };
        }

        /// <summary>
        /// Transforms list of route PMs list of route BOs.
        /// </summary>
        /// <param name="routePMs">List of route PMs.</param>
        /// <returns>List of route BOs.</returns>
        public static IList<Route> FromPresentationModels(IEnumerable<RoutePM> routePMs)
        {
            if (routePMs == null) return null;
            return routePMs.Select(u => FromPresentationModel(u)).ToList();
        }

        /// <summary>
        /// Transforms route PM to route BO.
        /// </summary>
        /// <param name="routePM">route PM.</param>
        /// <returns>route BO.</returns>
        public static Route FromPresentationModel(RoutePM routePM)
        {
            if (routePM == null) return null;

            return new Route
            {
                Id = routePM.Id,
                RouteName = routePM.Name,
                LocationId = routePM.LocationId ,

                Type = routePM.Type,
                IsActive = routePM.Active,
                Version = routePM.Version,
                TraceLevel = routePM.TraceLevel,

                Description = routePM.Description,
                //Comment = string.IsNullOrEmpty (routePM.PartName)?  routePM.ProductFamily:"",
                Comment =  routePM.ProductFamily,

                RouteOperationRoutes = RouteOperationMapper.FromPresentationModels(routePM.RouteOperationPMs).ToList(),

                CreatedBy = routePM.CreatedBy,
                ModifiedBy = routePM.ModifiedBy,

                CreatedOn = routePM.CreatedDate,
                ModifiedOn = routePM.ModifiedDate
            };
        }

        
      
    }
}
