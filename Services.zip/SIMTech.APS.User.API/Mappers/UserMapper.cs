﻿using System.Collections.Generic;
using System.Linq;


namespace  SIMTech.APS.User.API.Mappers
{
    using SIMTech.APS.User.API.Models;
    using SIMTech.APS.User.API.PresentationModels;

    public class UserMapper
    {
        public static IEnumerable<UserPM> ToPresentationModels(IEnumerable<User> users)
        {
            if (users == null) return null;
            return users.Select(ToPresentationModel);
        }

        public static UserPM ToPresentationModel(User user)
        {
            if (user == null) return null;

            return new UserPM
            {
                Comment = string.IsNullOrEmpty(user.Comment) ? string.Empty : user.Comment.Trim(),
                Email = string.IsNullOrEmpty(user.Email) ? string.Empty : user.Email.Trim(),
                FailedPasswordAttemptCount = user.FailedPasswordAttemptCount,
                FirstName = string.IsNullOrEmpty(user.FirstName) ? string.Empty : user.FirstName.Trim(),
                Id = user.Id,
                IsLockedOut = user.IsLockedOut??false,
                LastLockoutDate = user.LastLockoutDate,
                LastLoginDate = user.LastLoginDate,
                LastName = string.IsNullOrEmpty(user.LastName) ? string.Empty : user.LastName.Trim(),
                LastPasswordChangedDate = user.LastPasswordChangedDate,
                Mobile = string.IsNullOrEmpty(user.Mobile) ? string.Empty : user.Mobile.Trim(),
                //PasswordAnswerHash = string.IsNullOrEmpty(user.PasswordAnswerHash) ? string.Empty : user.PasswordAnswerHash.Trim(),
                //PasswordAnswerSalt = string.IsNullOrEmpty(user.PasswordAnswerSalt) ? string.Empty : user.PasswordAnswerSalt.Trim(),
                //PasswordHash = string.IsNullOrEmpty(user.PasswordHash) ? string.Empty : user.PasswordHash.Trim(),
                PasswordQuestion = string.IsNullOrEmpty(user.PasswordQuestion) ? string.Empty : user.PasswordQuestion.Trim(),
                //PasswordSalt = string.IsNullOrEmpty(user.PasswordSalt) ? string.Empty : user.PasswordSalt.Trim(),
                Username = string.IsNullOrEmpty(user.LoginId) ? string.Empty : user.LoginId.Trim(),
                SignatureID = user.SignatureId,
                PictureID = user.PictureId,
                Password = "**********",                 
            };
        }

        public static User FromPresentationModel(UserPM userPM)
        {
            if (userPM == null) return null;

            return new User
            {
                Comment = userPM.Comment,
                Email = userPM.Email,
                FailedPasswordAttemptCount = userPM.FailedPasswordAttemptCount,
                FirstName = userPM.FirstName,
                Id = userPM.Id,
                IsLockedOut = userPM.IsLockedOut,
                LastLockoutDate = userPM.LastLockoutDate,
                LastLoginDate = userPM.LastLoginDate,
                LastName = userPM.LastName,
                LastPasswordChangedDate = userPM.LastPasswordChangedDate,
                Mobile = userPM.Mobile,
                //PasswordAnswerHash = userPM.PasswordAnswerHash,
                //PasswordAnswerSalt = userPM.PasswordAnswerSalt,
                //PasswordHash = userPM.PasswordHash,
                PasswordQuestion = userPM.PasswordQuestion,
                //PasswordSalt = userPM.PasswordSalt,
                LoginId = userPM.Username,
                SignatureId = userPM.SignatureID,
                PictureId = userPM.PictureID,
            };
        }

        public static void UpdatePresentationModel(UserPM userPM, User user)
        {
            if (userPM == null || user == null) return;

            userPM.Comment = string.IsNullOrEmpty(user.Comment) ? string.Empty : user.Comment.Trim();
            userPM.Email = string.IsNullOrEmpty(user.Email) ? string.Empty : user.Email.Trim();
            userPM.FailedPasswordAttemptCount = user.FailedPasswordAttemptCount;
            userPM.FirstName = string.IsNullOrEmpty(user.FirstName) ? string.Empty : user.FirstName.Trim();
            userPM.Id = user.Id;
            userPM.IsLockedOut = user.IsLockedOut;
            userPM.LastLockoutDate = user.LastLockoutDate;
            userPM.LastLoginDate = user.LastLoginDate;
            userPM.LastName = string.IsNullOrEmpty(user.LastName) ? string.Empty : user.LastName.Trim();
            userPM.LastPasswordChangedDate = user.LastPasswordChangedDate;
            userPM.Mobile = string.IsNullOrEmpty(user.Mobile) ? string.Empty : user.Mobile.Trim();
            //userPM.PasswordAnswerHash = string.IsNullOrEmpty(user.PasswordAnswerHash) ? string.Empty : user.PasswordAnswerHash.Trim();
            //userPM.PasswordAnswerSalt = string.IsNullOrEmpty(user.PasswordAnswerSalt) ? string.Empty : user.PasswordAnswerSalt.Trim();
            //userPM.PasswordHash = string.IsNullOrEmpty(user.PasswordHash) ? string.Empty : user.PasswordHash.Trim();
            userPM.PasswordQuestion = string.IsNullOrEmpty(user.PasswordQuestion) ? string.Empty : user.PasswordQuestion.Trim();
            //userPM.PasswordSalt = string.IsNullOrEmpty(user.PasswordSalt) ? string.Empty : user.PasswordSalt.Trim();
            userPM.Username = string.IsNullOrEmpty(user.LoginId) ? string.Empty : user.LoginId.Trim();
            userPM.SignatureID = user.SignatureId;
            userPM.PictureID = user.PictureId;
        }
    }
}
