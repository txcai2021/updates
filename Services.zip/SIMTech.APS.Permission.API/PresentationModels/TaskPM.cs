﻿using SIMTech.APS.Permission.API.Enums;

namespace SIMTech.APS.Permission.API.PresentationModels
{
    public class TaskPM
    {
        public int Id { get; set; }

        public string ActionName { get; set; }

        public string ButtonText { get; set; }

        public ETaskType TaskType { get; set; }

        public string OrderBy { get; set; }

        public string Setting { get; set; }

        public string Description { get; set; }

        public string ModuleName { get; set; }

        public string Selection { get; set; }
    }
}
