﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SIMTech.APS.Product.API.Repository
{
    using SIMTech.APS.Product.API.Models;
    using SIMTech.APS.Repository;
    public interface IBOMRepository : IRepository<BillOfMaterial>
    {
        IList<BillOfMaterial> GetBillOfMaterialsbyAssemblyId(int assemblyId, string category="");

    }
}
