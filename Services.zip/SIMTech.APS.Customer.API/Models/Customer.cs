﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.Customer.API.Models
{

    using SIMTech.APS.Models;
    public  class Customer : BaseEntity
    {
        public string CustomerName { get; set; }
        public string Category { get; set; }
        public int? Priority { get; set; }
        public string CompanyName { get; set; }
        public string Address { get; set; }
        public string BillingAddress { get; set; }
        public string ContactPerson { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public int? PictureId { get; set; }
        public string String1 { get; set; }
        public string String2 { get; set; }
        public string String3 { get; set; }
        public string String4 { get; set; }
        public string String5 { get; set; }
        public string MaxString1 { get; set; }
        public string MaxString2 { get; set; }
        public string MaxString3 { get; set; }
      
    }
}
