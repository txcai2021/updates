﻿using System.ComponentModel.DataAnnotations;

namespace SIMTech.APS.Product.API.PresentationModels
{
    public class ItemProductionLinePM
    {
        [Key]
        public int Id { get; set; }

        public int ItemId { get; set; }

        public int ProductionLineId { get; set; }
    }
}
