﻿namespace SIMTech.APS.Product.API.Enums
{
    public enum ERawMaterialType : byte
    {
       
        FlatBar = 0,
        SquareBar = 1,
        Pipe = 2,
        RoundRod = 3,
        Plate = 4,
        AF = 5,  
    }

    public enum EWorkOrderStatus : byte
    {
        Pending = 0,
        Released = 10,
        Dispatched = 100,
        Queuing = 110,
        Processing = 120,
        Scrapped = 200,
        Discard = 210,
        ReturnUnclean = 220,
        Completed = 230,
        Charged = 240,
        SCRGenerated = 255
    }

}
