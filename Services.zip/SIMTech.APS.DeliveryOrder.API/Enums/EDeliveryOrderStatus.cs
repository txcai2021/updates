﻿namespace SIMTech.APS.DeliveryOrder.API.Enums
{
    public enum EDeliveryOrderStatus : byte
    {
        ProductCode = 0,
        CustomerProductCode = 1,
       
    }
}
