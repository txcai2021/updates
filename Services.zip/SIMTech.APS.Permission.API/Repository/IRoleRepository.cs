﻿using System.Collections.Generic;

namespace SIMTech.APS.Permission.API.Repository
{
    using SIMTech.APS.Permission.API.Models;
    using SIMTech.APS.Permission.API.PresentationModels;
    using SIMTech.APS.Repository; 

    public interface IRoleRepository :  IRepository<Role>
    {
        IEnumerable<MenuItemPM> GetMenuItemsByRole(string userRole, string moduleName);
        IEnumerable<MenuItemPM> GetMenuItemsByRoles(string[] userRoles, string moduleName);
        //IEnumerable<string> GetRoleNameByUserId(int userId);
        IEnumerable<object> GetRoleNameByUserId(int userId);      
        IEnumerable<string> GetModuleNameByUserId(int userId);

        void UpdateUserRole(int userId, int roleId);
    }

    
}
