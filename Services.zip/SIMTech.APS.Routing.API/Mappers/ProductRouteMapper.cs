﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SIMTech.APS.Routing.API.Mappers
{
    using SIMTech.APS.Routing.API.Models;
    using SIMTech.APS.Routing.API.PresentationModels;


    /// <summary>
    /// Maps  PMs (Presentation Models) to  BOs (Business Objects) and vice versa.
    /// </summary>
    public static class ProductRouteMapper
    {

        /// <summary>
        /// Transforms list of productroute BOs list of productroute PMs.
        /// </summary>
        /// <param name="productroutes">List of productroute BOs.</param>
        /// <returns>List of productroute PMs.</returns>
        public static IList<ProductRoutePM> ToPresentationModels(IEnumerable<ProductRoute> productroutes)
        {
            if (productroutes == null) return null;
            return productroutes.Select(pr => ToPresentationModel(pr)).ToList();
        }

        /// <summary>
        /// Transforms productroute BO to productroute PM.
        /// </summary>
        /// <param name="productroute">productroute BO.</param>
        /// <returns>productroute PM.</returns>
        public static ProductRoutePM ToPresentationModel(ProductRoute productroute)
        {
            if (productroute == null) return null;

            return new ProductRoutePM
            {
                Id = productroute.Id,

                ProductRouteName = productroute.ProductRouteName,
                RouteId = productroute.RouteId,
                ProductId = productroute.ProductId,
                CustomerId = productroute.CustomerId,
                KitTypeId = productroute.Int1,

                BaseRouteId = productroute.Int2,

                Type = productroute.Type,

                TemplateNormalSpecial = productroute.String1,
                String2 = productroute.String2,

                Comment = productroute.Comment,
                Version = productroute.Version,
                Active = productroute.IsActive,
                Status = productroute.Status,
                
                CreatedDate = productroute.CreatedOn,
                ModifiedDate = productroute.ModifiedOn,

                CreatedBy = productroute.CreatedBy,
                ModifiedBy = productroute.ModifiedBy
                //OperationOperations = ToPresentationModels(productroute.OperationOperations),
            };
        }


        /// <summary>
        /// Transforms list of productroute PMs list of productroute BOs.
        /// </summary>
        /// <param name="resourceoperationPMs">List of productroute PMs.</param>
        /// <returns>List of productroute BOs.</returns>
        public static IList<ProductRoute> FromPresentationModels(IEnumerable<ProductRoutePM> productroutePMs)
        {
            if (productroutePMs == null) return null;
            return productroutePMs.Select(pr => FromPresentationModel(pr)).ToList();
        }

        /// <summary>
        /// Transforms productroute PM to productroute BO.
        /// </summary>
        /// <param name="resourceoperationPM">productroute PM.</param>
        /// <returns>productroute BO.</returns>
        public static ProductRoute FromPresentationModel(ProductRoutePM productroutePM)
        {
            if (productroutePM == null) return null;

            return new ProductRoute
            {
                Id = productroutePM.Id,

                ProductRouteName = productroutePM.ProductRouteName,
                RouteId = productroutePM.RouteId,
                ProductId = productroutePM.ProductId,
                CustomerId = productroutePM.CustomerId,
                Int1 = productroutePM.KitTypeId,

                Int2 = productroutePM.BaseRouteId,

                Type = productroutePM.Type,

                String1 = productroutePM.TemplateNormalSpecial,
                String2 = productroutePM.String2,

                Comment = productroutePM.Comment,
                Version = productroutePM.Version,
                IsActive = productroutePM.Active,
                Status = productroutePM.Status,

                CreatedOn = productroutePM.CreatedDate,
                ModifiedOn = productroutePM.ModifiedDate,

                CreatedBy = productroutePM.CreatedBy,
                ModifiedBy = productroutePM.ModifiedBy

                //ProductRoute = FromPresentationModels(resourceoperationPM.OperationOperations)
                
            };
        }

      
    }
}
