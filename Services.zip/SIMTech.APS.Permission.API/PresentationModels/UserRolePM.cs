﻿using System.ComponentModel.DataAnnotations;

namespace SIMTech.APS.Permission.API.PresentationModels
{
    public class UserRolePM
    {
        [Key]
        public int UserRoleId { get; set; }

        public int UserId { get; set; }

        public int RoleId { get; set; }

        public string RoleName { get; set; }
    }
}
