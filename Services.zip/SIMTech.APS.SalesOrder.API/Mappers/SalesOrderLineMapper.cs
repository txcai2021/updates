﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace SIMTech.APS.SalesOrder.API.Mappers
{
    using SIMTech.APS.SalesOrder.API.Models;
    using SIMTech.APS.SalesOrder.API.PresentationModels;
    using SIMTech.APS.SalesOrder.API.Enums;
    using SIMTech.APS.WorkOrder.API.Enums;

    public static class SalesOrderLineMapper
    {
        public static IEnumerable<SalesOrderLinePM> ToPresentationModels(IEnumerable<SalesOrderDetail> salesOrderLines)
        {
            if (salesOrderLines == null) return null;
            return salesOrderLines.Select(ToPresentationModel);
        }

        public static SalesOrderLinePM ToPresentationModel(SalesOrderDetail salesOrderLine)
        {
            if (salesOrderLine == null) return null;

            SalesOrderLinePM salesOrderLinePM = new SalesOrderLinePM
            {
                Amount = salesOrderLine.Amount,
                BalanceQuantity = salesOrderLine.Float2??salesOrderLine.OrderQty,
                Description = salesOrderLine.Description,
                DueDate = salesOrderLine.DueDate,
                DueDate1 = salesOrderLine.DueDate != null ? ((DateTime)salesOrderLine.DueDate).ToString("dd/MM/yyyy") : null,
                Id = salesOrderLine.Id,
                LineNumber = salesOrderLine.LineNumber,
                LineNumber1 = salesOrderLine.LineNumber,
                ProductId = salesOrderLine.ProductId ?? 0,
                Quantity = salesOrderLine.OrderQty ?? 0,
                Remarks = salesOrderLine.Remark,
                SalesOrderId = salesOrderLine.SalesOrderId,
                Status = (ESalesOrderLineStatus)salesOrderLine.Status,
                UnitPrice = salesOrderLine.UnitPrice,
                SalesOrderNumber = salesOrderLine.SalesOrder!=null?salesOrderLine.SalesOrder.PurchaseOrderNumber:"",
                //UrgentFlag = (EWorkOrderUrgentFlag)(salesOrderLine.Int1 ?? 0),
                UrgentFlag = (EWorkOrderUrgentFlag)(salesOrderLine.Float1 ?? 0),
                AssemblyId = salesOrderLine.Int2,
                Revision = salesOrderLine.String2,
                Currency = salesOrderLine.String3,
                Remarks1 = salesOrderLine.MaxString1,
                UploadedFileName = salesOrderLine.String7,
                ThumbnailImageFileName = salesOrderLine.String8,
                SeverFileName = salesOrderLine.MaxString2,
                CreatedBy = salesOrderLine.CreatedBy,
                Uom = salesOrderLine.String4

            };

            //if (salesOrderLine.Float1 == null)
            //    salesOrderLinePM.BalanceAmount = null;
            //else
            //    salesOrderLinePM.BalanceAmount = Convert.ToDecimal(salesOrderLine.Float1);

            return salesOrderLinePM;
        }

        public static IEnumerable<SalesOrderDetail> FromPresentationModels(IEnumerable<SalesOrderLinePM> salesOrderLinePMs)
        {
            if (salesOrderLinePMs == null) return null;
            return salesOrderLinePMs.Select(FromPresentationModel);
        }

        public static SalesOrderDetail FromPresentationModel(SalesOrderLinePM salesOrderLinePM)
        {
            if (salesOrderLinePM == null) return null;

            SalesOrderDetail salesOrderDetail = new SalesOrderDetail
            {
                Amount = salesOrderLinePM.Amount,
                Description = salesOrderLinePM.Description,
                DueDate = salesOrderLinePM.DueDate,
                Float2 = salesOrderLinePM.BalanceQuantity,
                LineNumber = salesOrderLinePM.LineNumber ?? 0,
                OrderQty = salesOrderLinePM.Quantity,
                ProductId = salesOrderLinePM.ProductId,
                Remark = salesOrderLinePM.Remarks,
                SalesOrderId = salesOrderLinePM.SalesOrderId,
                Id = salesOrderLinePM.Id,
                Status = (byte)salesOrderLinePM.Status,
                UnitPrice = salesOrderLinePM.UnitPrice,
                //Int1 = (int?)salesOrderLinePM.UrgentFlag,
                Float1 = (int?)salesOrderLinePM.UrgentFlag,
                Int2 = salesOrderLinePM.AssemblyId,
                String2 = salesOrderLinePM.Revision,
                String3 = salesOrderLinePM.Currency,
                String8 = salesOrderLinePM.ThumbnailImageFileName,
                MaxString1 = salesOrderLinePM.Remarks1,
                MaxString2 = salesOrderLinePM.SeverFileName,
                CreatedBy = salesOrderLinePM.CreatedBy,
                ModifiedBy = salesOrderLinePM.ModifiedBy,
                String4 = salesOrderLinePM.Uom
            };

            //if (salesOrderLinePM.BalanceAmount == null)
            //    salesOrderDetail.Float1 = null;
            //else
            //    salesOrderDetail.Float1 = Convert.ToDouble(salesOrderLinePM.BalanceAmount);

            return salesOrderDetail;
        }

        public static void UpdatePresentationModel(SalesOrderLinePM salesOrderLinePM, SalesOrderDetail salesOrderLine)
        {
            if (salesOrderLinePM == null || salesOrderLine == null) return;

            salesOrderLinePM.Amount = salesOrderLine.Amount;
            salesOrderLinePM.BalanceQuantity = salesOrderLine.Float2;
            salesOrderLinePM.Description = salesOrderLine.Description;
            salesOrderLinePM.DueDate = salesOrderLine.DueDate;
            salesOrderLinePM.Id = salesOrderLine.Id;
            salesOrderLinePM.LineNumber = salesOrderLine.LineNumber;
            salesOrderLinePM.ProductId = salesOrderLine.ProductId ?? 0;
            salesOrderLinePM.Quantity = salesOrderLine.OrderQty ?? 0;
            salesOrderLinePM.Remarks = salesOrderLine.Remark;
            salesOrderLinePM.SalesOrderId = salesOrderLine.SalesOrderId;
            salesOrderLinePM.Status = (ESalesOrderLineStatus)salesOrderLine.Status;
            salesOrderLinePM.UnitPrice = salesOrderLine.UnitPrice;
            //salesOrderLinePM.UrgentFlag = (EWorkOrderUrgentFlag)(salesOrderLine.Int1 ?? 0);
            salesOrderLinePM.UrgentFlag = (EWorkOrderUrgentFlag)(salesOrderLine.Float1 ?? 0);
            salesOrderLinePM.AssemblyId = salesOrderLine.Int2;
            salesOrderLinePM.Revision = salesOrderLine.String2;
            salesOrderLinePM.Currency = salesOrderLine.String3;
            salesOrderLinePM.ThumbnailImageFileName = salesOrderLine.String8;

            salesOrderLinePM.Remarks1 = salesOrderLine.MaxString1;
            salesOrderLinePM.SeverFileName = salesOrderLine.MaxString2;
            salesOrderLinePM.CreatedBy = salesOrderLine.CreatedBy;

            salesOrderLinePM.Uom = salesOrderLine.String4;
            if (salesOrderLine.Float1 == null)
                salesOrderLinePM.BalanceAmount = null;
            else
                salesOrderLinePM.BalanceAmount = Convert.ToDecimal(salesOrderLine.Float1);
        }

        public static void UpdateFrom(this SalesOrderDetail existingSalesOrderDetail, SalesOrderDetail salesOrderDetail)
        {
            existingSalesOrderDetail.Amount = salesOrderDetail.Amount;
            existingSalesOrderDetail.Description = salesOrderDetail.Description;
            existingSalesOrderDetail.DueDate = salesOrderDetail.DueDate;
            existingSalesOrderDetail.Float1 = salesOrderDetail.Float1;
            existingSalesOrderDetail.Float2 = salesOrderDetail.Float2;
            existingSalesOrderDetail.LineNumber = salesOrderDetail.LineNumber;
            existingSalesOrderDetail.OrderQty = salesOrderDetail.OrderQty;
            existingSalesOrderDetail.ProductId = salesOrderDetail.ProductId;
            existingSalesOrderDetail.Remark = salesOrderDetail.Remark;
            existingSalesOrderDetail.SalesOrderId = salesOrderDetail.SalesOrderId;
            //Status can be updated from UI due to cancel
            existingSalesOrderDetail.Status = salesOrderDetail.Status;
            existingSalesOrderDetail.UnitPrice = salesOrderDetail.UnitPrice;
            existingSalesOrderDetail.String2 = salesOrderDetail.String2;
            existingSalesOrderDetail.String3 = salesOrderDetail.String3;
            existingSalesOrderDetail.String4 = salesOrderDetail.String4;
            existingSalesOrderDetail.MaxString1 = salesOrderDetail.MaxString1;
            existingSalesOrderDetail.MaxString2 = salesOrderDetail.MaxString2;
            existingSalesOrderDetail.Int1 = salesOrderDetail.Int1;
            existingSalesOrderDetail.Int2 = salesOrderDetail.Int2;
            existingSalesOrderDetail.ModifiedBy = salesOrderDetail.ModifiedBy;
            //if (!string.IsNullOrEmpty(salesOrderLinePM.ThumbnailImageFileName) && salesOrderLinePM.ThumbnailImage != null)
            //{
            //    if (string.IsNullOrEmpty(existingSalesOrderDetail.String8) || existingSalesOrderDetail.String8 != salesOrderLinePM.ThumbnailImageFileName)
            //    {
            //        string fname = null;
            //        fname = SaveDataToFile(salesOrderLinePM.ThumbnailImageFileName, salesOrderLinePM.ThumbnailImage, (salesOrderLinePM.LineNumber ?? 0));
            //        existingSalesOrderDetail.MaxString2 = fname;
            //    }
            //    else
            //    {
            //        if (!string.IsNullOrEmpty(existingSalesOrderDetail.MaxString2))
            //        {
            //            var bytes = GetSalesOrderImage(existingSalesOrderDetail.MaxString2);
            //            if (bytes.Length != salesOrderLinePM.ThumbnailImage.Length)
            //            {
            //                string fname = null;
            //                fname = SaveDataToFile(salesOrderLinePM.ThumbnailImageFileName, salesOrderLinePM.ThumbnailImage, (salesOrderLinePM.LineNumber ?? 0));
            //                existingSalesOrderDetail.MaxString2 = fname;
            //            }
            //        }

            //    }
            //}
            existingSalesOrderDetail.String8 = salesOrderDetail.String8;
            if (string.IsNullOrEmpty(existingSalesOrderDetail.String8))
                existingSalesOrderDetail.MaxString2 = null;

        }
    }
}
