﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace SIMTech.APS.Operation.API.DBContext
{

    using SIMTech.APS.Operation.API.Models;
    public partial class OperationContext : DbContext
    {
        public OperationContext()
        {
        }

        public OperationContext(DbContextOptions<OperationContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Operation> Operations { get; set; }
        public virtual DbSet<OperationParameter> OperationParameters { get; set; }
        public virtual DbSet<OperationRate> OperationRates { get; set; }
        public virtual DbSet<OperationResource> OperationResources { get; set; }
        public virtual DbSet<Parameter> Parameters { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<Operation>(entity =>
            {
                entity.ToTable("Operation");

                entity.HasIndex(e => new { e.OperationName, e.Version }, "IX_Opeation_OpeationNameVersion")
                    .IsUnique();

                entity.Property(e => e.Categroy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Description).HasMaxLength(250);

                entity.Property(e => e.LocationId).HasColumnName("LocationID");

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn)
                    .HasColumnType("datetime");


                entity.Property(e => e.OperationName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Uom).HasColumnName("UOM");

            });

            modelBuilder.Entity<OperationParameter>(entity =>
            {
                entity.ToTable("OperationParameter");

                entity.HasIndex(e => new { e.OperationId, e.ParamterId }, "IX_OperationParameter_OperationIDParameterID")
                    .IsUnique();

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.MaxValue).HasMaxLength(50);

                entity.Property(e => e.MinValue).HasMaxLength(50);

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn)
                    .HasColumnType("datetime");


                entity.Property(e => e.OperationId).HasColumnName("OperationID");

                entity.Property(e => e.ParamterId).HasColumnName("ParamterID");

                entity.Property(e => e.Uom)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .HasColumnName("UOM")
                    .IsFixedLength(true);

                entity.Property(e => e.Value).HasMaxLength(250);


                entity.HasOne(d => d.Operation)
                    .WithMany(p => p.OperationParameters)
                    .HasForeignKey(d => d.OperationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_OperationParamter_Operation");

                entity.HasOne(d => d.Paramter)
                    .WithMany(p => p.OperationParameters)
                    .HasForeignKey(d => d.ParamterId)
                    .HasConstraintName("FK_OperationParamter_Parameter");
            });

            modelBuilder.Entity<OperationRate>(entity =>
            {
                entity.ToTable("OperationRate");

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ItemId).HasColumnName("ItemID");

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn).HasColumnType("datetime");

                entity.Property(e => e.OperationId).HasColumnName("OperationID");

                entity.Property(e => e.ResourceId).HasColumnName("ResourceID");

                entity.Property(e => e.RouteId).HasColumnName("RouteID");

                entity.Property(e => e.Uom).HasColumnName("UOM");

            });

            modelBuilder.Entity<OperationResource>(entity =>
            {
                entity.ToTable("OperationResource");

                entity.HasIndex(e => new { e.OperationId, e.ResourceId }, "IX_OperationResource_OperationIDResourceID")
                    .IsUnique();

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn)
                    .HasColumnType("datetime");


                entity.Property(e => e.OperationId).HasColumnName("OperationID");

                entity.Property(e => e.ResourceId).HasColumnName("ResourceID");


                entity.HasOne(d => d.Operation)
                    .WithMany(p => p.OperationResources)
                    .HasForeignKey(d => d.OperationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_OperationResource_Operation");
            });

            modelBuilder.Entity<Parameter>(entity =>
            {
                entity.ToTable("Parameter");

                entity.HasIndex(e => new { e.ParameterName, e.Type }, "IX_Parameter_ParementerNameType")
                    .IsUnique();

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DataType)
                    .IsRequired()
                    .HasMaxLength(10);

                entity.Property(e => e.DefaultValue).HasMaxLength(50);

                entity.Property(e => e.MaxValue).HasMaxLength(50);

                entity.Property(e => e.MinValue).HasMaxLength(50);

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn)
                    .HasColumnType("datetime");


                entity.Property(e => e.ParameterName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Uom)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .HasColumnName("UOM")
                    .IsFixedLength(true);

            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
