﻿
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SIMTech.APS.Product.API.Repository
{
    using SIMTech.APS.Repository;
    using SIMTech.APS.Product.API.Models;
    using SIMTech.APS.Product.API.DBContext;
    using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;

    public class BOMRepository : Repository<BillOfMaterial>, IBOMRepository
    {
        private readonly ProductContext _dbContext;
        private readonly ExceptionManager _exceptionManager;

        public BOMRepository(ProductContext dbContext) : base(dbContext)
        {
            _dbContext = dbContext;
            _exceptionManager = new ExceptionManager();
        }

        public IList<BillOfMaterial> GetBillOfMaterialsbyAssemblyId(int assemblyId, string category = "")
        {
            var boMs = _exceptionManager.Process(() => _dbContext.BillOfMaterials.Include(i => i.Component).Where(bom=>bom.ProductAssemblyId == assemblyId), "ExceptionShielding");

            if (category == "M")
                return boMs.Where(x => x.Component.Category == "RawMaterial").ToList();
            else if (category=="P")
                return boMs.Where(x => x.Component.Category != "RawMaterial").ToList();
            else
                return boMs.ToList ();
        }

    }
}

