﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.Product.API.Models
{
    using SIMTech.APS.Models;
    public partial class Item :BaseEntity
    {
        public Item()
        {
            BillOfMaterialComponents = new HashSet<BillOfMaterial>();
            BillOfMaterialProductAssemblies = new HashSet<BillOfMaterial>();
            CustomerItems = new HashSet<CustomerItem>();
            InverseParentItem = new HashSet<Item>();
        }
        public string ItemName { get; set; }
        public byte Type { get; set; }
        public string Category { get; set; }
        public string Subcategory { get; set; }
        public string Description { get; set; }
        public decimal? StandardCost { get; set; }
        public decimal? UnitPrice { get; set; }
        public int? PictureId { get; set; }
        public bool? MakeFlag { get; set; }
        public short? SafetyStockLevel { get; set; }
        public short? ReorderPoint { get; set; }
        public string Group1 { get; set; }
        public string Group2 { get; set; }
        public string Group3 { get; set; }
        public string Group4 { get; set; }
        public string Group5 { get; set; }
        public string Group6 { get; set; }
        public int? ParentItemId { get; set; }
        public string String1 { get; set; }
        public string String2 { get; set; }
        public string String3 { get; set; }
        public string String4 { get; set; }
        public string String5 { get; set; }
        public string String6 { get; set; }
        public string String7 { get; set; }
        public string String8 { get; set; }
        public string String9 { get; set; }
        public string MaxString1 { get; set; }
        public string MaxString2 { get; set; }
        public string MaxString3 { get; set; }
        public string MaxString4 { get; set; }
        public string MaxString5 { get; set; }
        public DateTime? Date1 { get; set; }
        public DateTime? Date2 { get; set; }
        public DateTime? Date3 { get; set; }
        public DateTime? Date4 { get; set; }
        public DateTime? Date5 { get; set; }
        public bool? Flag1 { get; set; }
        public bool? Flag2 { get; set; }
        public bool? Flag3 { get; set; }
        public bool? Flag4 { get; set; }
        public bool? Flag5 { get; set; }
        public int? Int1 { get; set; }
        public int? Int2 { get; set; }
        public decimal? Int3 { get; set; }
        public int? Int4 { get; set; }
        public int? Int5 { get; set; }
        public int? Int6 { get; set; }
        public int? Int7 { get; set; }
        public int? Int8 { get; set; }
        public int? Int9 { get; set; }
        public int? Int10 { get; set; }
        public double? Float1 { get; set; }
        public double? Float2 { get; set; }
        public double? Float3 { get; set; }
        public double? Float4 { get; set; }
        public double? Float5 { get; set; }

        public virtual Item ParentItem { get; set; }
        public virtual ICollection<BillOfMaterial> BillOfMaterialComponents { get; set; }
        public virtual ICollection<BillOfMaterial> BillOfMaterialProductAssemblies { get; set; }
        public virtual ICollection<CustomerItem> CustomerItems { get; set; }
        public virtual ICollection<Item> InverseParentItem { get; set; }
    }
}
