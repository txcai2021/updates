
using System;


namespace SIMTech.APS.User.API.Models
{
    public  class Option
    {
        #region Primitive Properties
    
        public virtual int OptionId
        {
            get;
            set;
        }
    
        public virtual string OptionName
        {
            get;
            set;
        }
    
        public virtual string Description
        {
            get;
            set;
        }
    
        public virtual string ModuleName
        {
            get;
            set;
        }
    
        public virtual string Category
        {
            get;
            set;
        }
    
        public virtual string DataType
        {
            get;
            set;
        }
    
        public virtual string DefaultSetting
        {
            get;
            set;
        }
    
        public virtual string CreatedBy
        {
            get;
            set;
        }
    
        public virtual System.DateTime CreatedOn
        {
            get;
            set;
        }
    
        public virtual string ModifiedBy
        {
            get;
            set;
        }
    
        public virtual Nullable<System.DateTime> ModifiedOn
        {
            get;
            set;
        }
    
        public virtual byte[] VersionStamp
        {
            get;
            set;
        }

        #endregion

    }
}
