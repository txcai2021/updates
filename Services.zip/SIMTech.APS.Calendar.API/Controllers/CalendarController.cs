﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Transactions;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.AspNetCore.Http;
using System.Text.Json;
using System.Text.Json.Serialization;


namespace SIMTech.APS.Calendar.API.Controllers
{
    using SIMTech.APS.Calendar.API.Repository;
    using SIMTech.APS.Calendar.API.Mappers;
    using SIMTech.APS.Calendar.API.Models;
    using SIMTech.APS.Calendar.API.PresentationModels;
   
    [Route("api/[controller]")]
    [ApiController]
    public class CalendarController : ControllerBase
    {
        private readonly ICalendarRepository _CalendarRepository;
        private readonly ICalendarDetailRepository _CalendardetailRepository;
        public CalendarController(ICalendarRepository CalendarRepository,ICalendarDetailRepository CalendarDetailRepository)
        {
            _CalendarRepository = CalendarRepository;
            _CalendardetailRepository = CalendarDetailRepository;
        }


        //GET: api/Role
        //[HttpGet]
        //public async Task<IEnumerable<Calendar>> GetAllCalendars() => await _CalendarRepository.GetAll();
       

        //[HttpGet]
        //[Route("{id}")]
        //public Calendar GetCalendarById(int id) => _CalendarRepository.GetById(id);
       

        //[HttpPost]
        //public void AddCalendar([FromBody] Calendar Calendar) => _CalendarRepository.Insert(Calendar);
       

        //[HttpPut]
        //public void UpdateCalendar([FromBody] Calendar Calendar) => _CalendarRepository.Update(Calendar);
       


        //// DELETE api/<CalendarController>/5
        //[HttpDelete("{id}")]
        //public void DeleteCalendar(int id) => _CalendarRepository.Delete(id);

        [HttpGet("DB/{calendarIds}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<ActionResult<IEnumerable<Calendar>>> GetCalendarList(string calendarIds)
        {
            //var calendars = await _CalendarRepository.GetQueryAsync(x => x.Category != "Calendar" || calendarIds.Contains(x.Id.ToString()));
            var calIds = calendarIds.Split(",").Select (x=>Convert.ToInt32 (x)).ToList();
              
            var calendars = (await _CalendarRepository.GetQueryAsync(x=> calIds.Contains(x.Id))).ToList ();

            var options = new JsonSerializerOptions
            {
                ReferenceHandler = ReferenceHandler.Preserve,
                WriteIndented = true,
            };

           
            return Ok(JsonSerializer.Serialize(calendars, options));
            
        }



        [HttpGet]

        [Route("GetCalendars")]
        public IEnumerable<CalendarPM> GetCalendarsbyCategory(string category)
        {
            var calendarList = _CalendarRepository.GetQuery(x => x.Category == category).OrderBy(s => s.CalendarName).ToList();
            if(category != "Meal" && calendarList != null && calendarList.Count > 0)
            {
                foreach(var objCalendar in calendarList)
                {
                   IList<CalendarDetail> childLists= _CalendardetailRepository.GetQuery(m => m.ParentCalendarId == objCalendar.Id).ToList();
                    if(category == "Calendar")
                    {
                        if (childLists != null && childLists.Count > 0)
                        {
                            objCalendar.CalendarDetailParentCalendars = childLists.OrderBy(s => (string.IsNullOrEmpty(s.Value) ? 0: s.Value.Length)).ThenBy(s => s.Value).ToList();
                        }
                    }
                    else
                    {
                        if (childLists != null && childLists.Count > 0)
                        {
                            objCalendar.CalendarDetailParentCalendars = childLists;
                        }
                    }
                   
                }
            }
            return CalendarMapper.ToPresentationModels(calendarList).AsQueryable();
        }

        [HttpPost]
        [Route("AddMeal")]
        public IActionResult AddMeal([FromBody] CalendarPM calendarpm)
        {
            Calendar dbCalendar = CalendarMapper.FromPresentationModel(calendarpm);
            dbCalendar.CreatedOn = DateTime.Today;
            dbCalendar.Category = "Meal";
            dbCalendar.Type = 0;
            dbCalendar.ModifiedOn = DateTime.Now;
            _CalendarRepository.Insert(dbCalendar);

            CalendarMapper.UpdatePresentationModel(calendarpm, dbCalendar);
            return new OkObjectResult(calendarpm);
        }


        [HttpPut]
        [Route("UpdateMeal")]
        //public void UpdateCustomer([FromBody] Customer Customer) => _customerRepository.Update(Customer);
        public void UpdateMeal([FromBody] CalendarPM calendapm)
        {
            Calendar uiCalendar = CalendarMapper.FromPresentationModel(calendapm);
            Calendar existingCalendar = _CalendarRepository.GetById(uiCalendar.Id);
            existingCalendar.Description = uiCalendar.Description;
            existingCalendar.StartTime = uiCalendar.StartTime;
            existingCalendar.EndTime = uiCalendar.EndTime;
            existingCalendar.ModifiedOn = DateTime.Now;
            _CalendarRepository.Update(existingCalendar);
        }




        // DELETE api/<RoleController>/5
        [HttpDelete]
        [Route("DeleteCalendar")]
        public int DeleteCalendar(int id)
        {
            int res = 0;
            try
            {
                var relationexistList = _CalendardetailRepository.GetQuery(c => c.CalendarId == id).ToList();
                if(relationexistList != null && relationexistList.Count > 0)
                {
                    return -1;
                }
                var childlist = _CalendardetailRepository.GetQuery(c => c.ParentCalendarId == id).Select(s => s.Id).ToList<int>();
                if(childlist != null && childlist.Count  > 0)
                {
                    foreach(var objID in childlist)
                    {
                        _CalendardetailRepository.Delete(objID);
                    }
                }
                _CalendarRepository.Delete(id);
                res = id;
            }
            catch (Exception exception)
            {
                if (exception.InnerException == null) throw;
                var sqlException = exception.InnerException as Microsoft.Data.SqlClient.SqlException;
                if (sqlException == null) throw;

                if (sqlException.Number != 547) throw;
                throw new Exception("Record cannot be deleted due related records.");
            }

            return res;
        }

        [HttpPost]
        [Route("AddCalendarItem")]
        public IActionResult AddCalendarItem([FromBody] CalendarPM calendarpm)
        {
            calendarpm.Id = 0;
            Calendar dbCalendar = CalendarMapper.FromPresentationModel(calendarpm);
            dbCalendar.CreatedOn = DateTime.Today;
            dbCalendar.Category = calendarpm.Category;
            dbCalendar.Type = 0;
            dbCalendar.ModifiedOn = DateTime.Now;
            _CalendarRepository.Insert(dbCalendar);

            if(calendarpm != null && calendarpm.CalendarDetails != null && calendarpm.CalendarDetails.Count() > 0
                && dbCalendar != null && dbCalendar.Id > 0)
            {
                foreach(var objcalendarDetail in calendarpm.CalendarDetails)
                {
                    CalendarDetail objUIDetail = new CalendarDetail();
                    objUIDetail.Id = 0;
                    objUIDetail.ParentCalendarId = dbCalendar.Id;
                    objUIDetail.CalendarId = objcalendarDetail.CalendarId;
                    objUIDetail.Sequence = 0;
                    objUIDetail.Interval = 0;
                    objUIDetail.Value = objcalendarDetail.Value;
                    objUIDetail.CreatedOn = DateTime.Now;
                    objUIDetail.ModifiedOn = DateTime.Now;
                   
                    objUIDetail.CalendarDetailName = dbCalendar.CalendarName + "-" + objcalendarDetail.Name;
                    _CalendardetailRepository.Insert(objUIDetail);
                }
            }

            CalendarMapper.UpdatePresentationModel(calendarpm, dbCalendar);
            return new OkObjectResult(calendarpm);
        }



        [HttpPut]
        [Route("UpdateCalendarItem")]
        //public void UpdateCustomer([FromBody] Customer Customer) => _customerRepository.Update(Customer);
        public void UpdateCalendarItem([FromBody] CalendarPM calendarpm)
        {
            logfile("Befin");
            Calendar uiCalendar = CalendarMapper.FromPresentationModel(calendarpm);
            Calendar existingCalendar = _CalendarRepository.GetById(uiCalendar.Id);
            existingCalendar.Description = uiCalendar.Description;
            existingCalendar.StartTime = uiCalendar.StartTime;
            if(uiCalendar.Category == "CalendarException")
            {
                existingCalendar.StartDate = uiCalendar.StartDate;
            }
           
            existingCalendar.EndTime = uiCalendar.EndTime;
            existingCalendar.ModifiedOn = DateTime.Now;
            _CalendarRepository.Update(existingCalendar);

            if (calendarpm != null && calendarpm.CalendarDetails != null && calendarpm.CalendarDetails.Count() > 0
               && existingCalendar != null && existingCalendar.Id > 0)
            {
                foreach (var objcalendarDetail in calendarpm.CalendarDetails)
                {
                    logfile(objcalendarDetail.ParentCalendarId.ToString());
                    logfile(objcalendarDetail.CalendarId.ToString());
                    logfile(calendarpm.Id.ToString());
                    if (objcalendarDetail.ParentCalendarId <= -1)
                    {
                        logfile("reday to delte");
                        if(calendarpm.Category.ToUpper() == "CALENDAR" && !string.IsNullOrEmpty(objcalendarDetail.Value))
                        {

                            var existingCalendardetaillist = _CalendardetailRepository.GetQuery(e => e.CalendarId == objcalendarDetail.CalendarId
                    && e.ParentCalendarId == calendarpm.Id && e.Value == objcalendarDetail.Value).ToList();
                            if (existingCalendardetaillist != null && existingCalendardetaillist.Count > 0)
                            {
                                // logfile("to be delte");
                                _CalendardetailRepository.Delete(existingCalendardetaillist.FirstOrDefault().Id);

                            }
                        }
                        else
                        {
                            var existingCalendardetaillist = _CalendardetailRepository.GetQuery(e => e.CalendarId == objcalendarDetail.CalendarId
                      && e.ParentCalendarId == calendarpm.Id).ToList();
                            if (existingCalendardetaillist != null && existingCalendardetaillist.Count > 0)
                            {
                               // logfile("to be delte");
                                _CalendardetailRepository.Delete(existingCalendardetaillist.FirstOrDefault().Id);
                               
                            }
                        }
                       
                    }
                    else if (objcalendarDetail.ParentCalendarId == 0)
                    {
                        logfile("add new" + existingCalendar.Id.ToString());

                        if (calendarpm.Category.ToUpper() == "CALENDAR" && !string.IsNullOrEmpty(objcalendarDetail.Value))
                        {
                            var duplictecheck = _CalendardetailRepository.GetQuery(e => e.CalendarId == objcalendarDetail.CalendarId
                   && e.ParentCalendarId == existingCalendar.Id && e.Value == objcalendarDetail.Value).ToList();
                            if (duplictecheck != null && duplictecheck.Count > 0)
                            {


                            }
                            else
                            {
                                CalendarDetail objUIDetail1 = new CalendarDetail();
                                objUIDetail1.Id = 0;
                                objUIDetail1.ParentCalendarId = existingCalendar.Id;
                                objUIDetail1.CalendarId = objcalendarDetail.CalendarId;
                                objUIDetail1.Sequence = 0;
                                objUIDetail1.Interval = 0;
                                objUIDetail1.Value = objcalendarDetail.Value;
                                objUIDetail1.CreatedOn = DateTime.Now;
                                objUIDetail1.ModifiedOn = DateTime.Now;

                                objUIDetail1.CalendarDetailName = existingCalendar.CalendarName + "-" + objcalendarDetail.Name;
                                _CalendardetailRepository.Insert(objUIDetail1);
                            }
                        }
                        else
                        {
                            var duplictecheck = _CalendardetailRepository.GetQuery(e => e.CalendarId == objcalendarDetail.CalendarId
                    && e.ParentCalendarId == existingCalendar.Id).ToList();
                            if (duplictecheck != null && duplictecheck.Count > 0)
                            {


                            }
                            else
                            {
                                CalendarDetail objUIDetail1 = new CalendarDetail();
                                objUIDetail1.Id = 0;
                                objUIDetail1.ParentCalendarId = existingCalendar.Id;
                                objUIDetail1.CalendarId = objcalendarDetail.CalendarId;
                                objUIDetail1.Sequence = 0;
                                objUIDetail1.Interval = 0;
                                objUIDetail1.Value = objcalendarDetail.Value;
                                objUIDetail1.CreatedOn = DateTime.Now;
                                objUIDetail1.ModifiedOn = DateTime.Now;

                                objUIDetail1.CalendarDetailName = existingCalendar.CalendarName + "-" + objcalendarDetail.Name;
                                _CalendardetailRepository.Insert(objUIDetail1);
                            }
                        }
                           
                       
                    }
                   

                }
            }
        }


        private void logfile(string strdata)
        {
            try{

               System.IO.File.AppendAllText(@"C:\SIMTech\testlog.txt", strdata + Environment.NewLine);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
            }
        }
    }
}
