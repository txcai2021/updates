﻿using System.ComponentModel.DataAnnotations;

namespace SIMTech.APS.Permission.API.PresentationModels
{
    public class MenuPM
    {
        [Key]
        public int Id { get; set; }
        
        public int ParentTaskId { get; set; }
        
        public int TaskId { get; set; }
        
        public int SortSequence { get; set; }
    }
}
