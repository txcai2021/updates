﻿using System.Collections.Generic;
using System.Linq;


namespace SIMTech.APS.Product.Web.Mappers
{
    using SIMTech.APS.Product.API.Models;
    using SIMTech.APS.Product.API.PresentationModels;
    public class ItemProductionLineMapper
    {
        public static IEnumerable<ItemProductionLinePM> ToPresentationModels(IEnumerable<ItemLocation> itemLocations)
        {
            if (itemLocations == null) return null;
            return itemLocations.Select(ToPresentationModel);
        }

        public static ItemProductionLinePM ToPresentationModel(ItemLocation itemLocation)
        {
            if (itemLocation == null) return null;

            return new ItemProductionLinePM
            {
                Id = itemLocation.ItemLocationId,
                ItemId = itemLocation.ItemId,
                ProductionLineId = itemLocation.ProductLineId
            };
        }

        public static ItemLocation FromPresentationModel(ItemProductionLinePM itemProductionLinePM)
        {
            if (itemProductionLinePM == null) return null;

            return new ItemLocation
            {
                ItemId = itemProductionLinePM.ItemId,
                ProductLineId = itemProductionLinePM.ProductionLineId,
                ItemLocationId = itemProductionLinePM.Id,
            };
        }

        public static void UpdatePresentationModel(ItemProductionLinePM itemProductionLinePM, ItemLocation itemLocation)
        {
            if (itemProductionLinePM == null || itemLocation == null) return;

            itemProductionLinePM.ItemId = itemLocation.ItemId;
            itemProductionLinePM.Id = itemLocation.ItemLocationId;
            itemProductionLinePM.ProductionLineId = itemLocation.ProductLineId;
        }
    }
}
