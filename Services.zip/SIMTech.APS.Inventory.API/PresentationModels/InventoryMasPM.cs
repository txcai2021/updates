﻿using System.ComponentModel.DataAnnotations;
using SIMTech.APS.Resources;

namespace SIMTech.APS.Inventory.API.PresentationModels
{
    public class InventoryMasPM
    {
        [Key]
        public int Id { get; set; }
         
        public string Name { get; set; }

        public string Category { get; set; }

        public int PartId { get; set; }

        public int AssemblyId { get; set; }

        [Display(ShortName = "Product No", Name = "Product No")]
        public string PartNo { get; set; }

        [Display(ShortName = "Product Name", Name = "Product Name")]
        public string PartName { get; set; }

        [Display(ShortName = "Product Family", Name = "Product Family")]
        public string PartFamily { get; set; }
       
        public int? CustomerId { get; set; }

        [Display(ShortName = "Customer", Name = "Customer")]
        public string CustomerCode { get; set; }

        [Display(ShortName = "Safety Stock", Name = "Safety Stock")]
        public decimal? SafetyStock { get; set; }

        [Display(ShortName = "Monthly Usage", Name = "Monthly Usage")]
        public decimal? MonthlyUsage { get; set; }

        [Display(ShortName = "Customer FG Qty", Name = "Customer FG Qty")]
        public decimal? CustomerFGQty { get; set; }

        [Display(ShortName = "FG Qty", Name = "FG Qty")]
        public decimal? FGQty { get; set; }

        [Display(ShortName = "DO Qty", Name = "DO Qty")]
        public decimal? DOQty { get; set; }

        [Display(ShortName = "WIP Qty", Name = "WIP Qty")]
        public decimal? WipQty { get; set; }

        public string Remarks { get; set; }

        public decimal? Cost { get; set; }

        [Display(Name = "Revision", ShortName = "Revision")]
        public string Revision { get; set; }
     
     }
}
