﻿using System.Collections.Generic;
using System.Linq;
using SIMTech.APS.Order.Business;
using SIMTech.APS.Product.Web.PresentationModel;

namespace SIMTech.APS.Product.Web.Mappers
{
    public class CustomerMapper
    {
        public static IEnumerable<CustomerPM> ToPresentationModels(IEnumerable<Customer> customers)
        {
            if (customers == null) return null;
            return customers.Select(ToPresentationModel);
        }

        public static CustomerPM ToPresentationModel(Customer customer)
        {
            if (customer == null) return null;

            return new CustomerPM
            {
                Address = customer.Address,
                Code = customer.CustomerName,
                Department = customer.String2,
                Description = customer.MaxString1,
                Id = customer.CustomerID,
                Name = customer.CompanyName,
                Priority = customer.Priority,
                Site = customer.String1
            };
        }

        public static IEnumerable<Customer> FromPresentationModels(IEnumerable<CustomerPM> customerPMs)
        {
            if (customerPMs == null) return null;
            return customerPMs.Select(FromPresentationModel);
        }

        public static Customer FromPresentationModel(CustomerPM customerPM)
        {
            if (customerPM == null) return null;

            return new Customer
            {
                CustomerID = customerPM.Id,
                CustomerName = customerPM.Code,
                CompanyName = customerPM.Name,
                Priority = customerPM.Priority,
                Address = customerPM.Address,
                MaxString1 = customerPM.Description,
                String1 = customerPM.Site,
                String2 = customerPM.Department
            };
        }

        public static void UpdatePresentationModel(CustomerPM customerPM, Customer customer)
        {
            if (customerPM == null || customer == null) return;

            customerPM.Address = customer.Address;
            customerPM.Code = customer.CustomerName;
            customerPM.Department = customer.String2;
            customerPM.Description = customer.MaxString1;
            customerPM.Id = customer.CustomerID;
            customerPM.Name = customer.CompanyName;
            customerPM.Priority = customer.Priority;
            customerPM.Site = customer.String1;
        }
    }
}
