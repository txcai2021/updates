﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.Resource.API.Models
{
    using SIMTech.APS.Models;
    public partial class Equipment : BaseEntity
    {
        public Equipment()
        {
            EquipmentBlockOuts = new HashSet<EquipmentBlockOut>();
            EquipmentParameters = new HashSet<EquipmentParameter>();
        }

        public string EquipmentName { get; set; }
        public string Description { get; set; }
        public string Category { get; set; }
        public string Subcategory { get; set; }
        public int? Type { get; set; }
        public int? ParentEquipmentId { get; set; }
        public int? LocationId { get; set; }
        public int? CalendarId { get; set; }
        public string String1 { get; set; }
        public string String2 { get; set; }
        public string MaxString1 { get; set; }
        public string MaxString2 { get; set; }
        public double? Float1 { get; set; }
        public double? Float2 { get; set; }

        public virtual ICollection<EquipmentBlockOut> EquipmentBlockOuts { get; set; }
        public virtual ICollection<EquipmentParameter> EquipmentParameters { get; set; }
    }
}
