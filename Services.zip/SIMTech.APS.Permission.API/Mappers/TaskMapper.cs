﻿using System.Collections.Generic;
using System.Linq;


namespace SIMTech.APS.Permission.API.Mappers
{
    using SIMTech.APS.Permission.API.Models;
    using SIMTech.APS.Permission.API.PresentationModels;
    public class TaskMapper
    {
        public static IEnumerable<MenuItemPM> ToMenuItems(IEnumerable<Task> tasks)
        {
            return tasks == null ? null : tasks.Select(ToMenuItem);
        }

        public static MenuItemPM ToMenuItem(Task task)
        {
            if (task == null) return null;

            return new MenuItemPM
            {
                Id = task.Id,
                ActionName = string.IsNullOrEmpty(task.ActionName) ? string.Empty : task.ActionName.Trim(),
                ButtonText = string.IsNullOrEmpty(task.DisplayText) ? string.Empty : task.DisplayText.Trim(),
                OrderBy = string.IsNullOrEmpty(task.OrderBy) ? string.Empty : task.OrderBy.Trim(),
                Setting = string.IsNullOrEmpty(task.Setting) ? string.Empty : task.Setting.Trim(),
                Description = string.IsNullOrEmpty(task.Description) ? string.Empty : task.Description.Trim(),
            };
        }

        public static IEnumerable<ToolbarActionPM> ToToolbarActions(IEnumerable<Task> tasks)
        {
            return tasks == null ? null : tasks.Select(ToToolbarAction);
        }

        public static ToolbarActionPM ToToolbarAction(Task task)
        {
            if (task == null) return null;

            return new ToolbarActionPM
            {
                Id = task.Id,
                ActionName = string.IsNullOrEmpty(task.ActionName) ? string.Empty : task.ActionName.Trim(),
                ButtonText = string.IsNullOrEmpty(task.DisplayText) ? string.Empty : task.DisplayText.Trim(),
                OrderBy = string.IsNullOrEmpty(task.OrderBy) ? string.Empty : task.OrderBy.Trim(),
                Setting = string.IsNullOrEmpty(task.Setting) ? string.Empty : task.Setting.Trim(),
                Description = string.IsNullOrEmpty(task.Description) ? string.Empty : task.Description.Trim(),
            };
        }
    }
}
