﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;


namespace SIMTech.APS.Operation.API.Repository
{
    using SIMTech.APS.Operation.API.Models;
    using SIMTech.APS.Repository;
    public interface IOperationRepository : IRepository<Operation>
    {
      
        Task<IEnumerable<Operation>> GetOperationsbyResource(int resourceId);

        Task<IEnumerable<Operation>> GetOperations(int operationId = 0, bool template = true);

        Task<IEnumerable<Operation>> GetOperations(string operationIds);

        Task<IEnumerable<Operation>> GetOperations(int[] operationIds);

        Task<int> CopyOperation(int operationId, int routeOperationId, string instruction = null, string remarks = null, string pictureId = null);
    }

}
