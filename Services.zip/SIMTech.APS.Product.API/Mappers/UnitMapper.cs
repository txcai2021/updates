﻿using System.Collections.Generic;
using System.Linq;
using SIMTech.APS.Product.Business;
using SIMTech.APS.Product.Web.PresentationModel;

namespace SIMTech.APS.Product.Web.Mappers
{
    public class UnitMapper
    {
        public static IEnumerable<UnitPM> ToPresentationModels(IEnumerable<Location> locations)
        {
            if (locations == null) return null;
            return locations.Select(ToPresentationModel);
        }

        public static UnitPM ToPresentationModel(Location location)
        {
            if (location == null) return null;

            return new UnitPM
            {
                Description = string.IsNullOrEmpty(location.Description) ? string.Empty : location.Description,
                Id = location.LocationId,
                Name = string.IsNullOrEmpty(location.LocationName) ? string.Empty : location.LocationName,
                NoOfProductionLines = location.Location1.Count,
                CalendarId =location.CalendarId ,
                CustomerId = string.IsNullOrEmpty(location.Subcategory) ? 0 : int.Parse(location.Subcategory)
            };
        }

        public static IEnumerable<Location> FromPresentationModels(IEnumerable<UnitPM> unitPms)
        {
            if (unitPms == null) return null;
            return unitPms.Select(FromPresentationModel);
        }

        public static Location FromPresentationModel(UnitPM unitPM)
        {
            if (unitPM == null) return null;

            return new Location
            {
                Description = unitPM.Description,
                LocationId = unitPM.Id,
                LocationName = unitPM.Name,
                Subcategory = unitPM.CustomerId.ToString (),
                CalendarId =unitPM.CalendarId ,
            };
        }

        public static void UpdatePresentationModel(UnitPM unitPM, Location location)
        {
            if (unitPM == null || location == null) return;

            unitPM.Description = string.IsNullOrEmpty(location.Description) ? string.Empty : location.Description;
            unitPM.Id = location.LocationId;
            unitPM.Name = string.IsNullOrEmpty(location.LocationName) ? string.Empty : location.LocationName;
            unitPM.NoOfProductionLines = location.Location1.Count;
            unitPM.CustomerId = string.IsNullOrEmpty(location.Subcategory) ? 0 : int.Parse(location.Subcategory);
            unitPM.CalendarId = location.CalendarId;
        }
    }
}
