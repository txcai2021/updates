﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;


namespace SIMTech.APS.Operation.API.Repository
{
    using SIMTech.APS.Operation.API.Models;
    using SIMTech.APS.Repository;
    public interface IOperationRateRepository : IRepository<OperationRate>
    {
        Task<int> CopyOperationRate(int routeId, int routeOperationId, int newRouteId, int newRouteOperationId);
    }

}
