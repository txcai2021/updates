﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SIMTech.APS.Routing.API.Mappers
{
    using SIMTech.APS.Routing.API.Models;
    using SIMTech.APS.Routing.API.PresentationModels;


    /// <summary>
    /// Maps  PMs (Presentation Models) to  BOs (Business Objects) and vice versa.
    /// </summary>
    public static class ProductRouteStatusMapper
    {

        /// <summary>
        /// Transforms list of prStatus BOs list of prStatus PMs.
        /// </summary>
        /// <param name="productroutes">List of prStatus BOs.</param>
        /// <returns>List of prStatus PMs.</returns>
        public static IList<ProductRouteStatusPM> ToPresentationModels(IEnumerable<ProductRouteStatus> productroutes)
        {
            if (productroutes == null) return null;
            return productroutes.Select(pr => ToPresentationModel(pr)).ToList();
        }

        /// <summary>
        /// Transforms prStatus BO to prStatus PM.
        /// </summary>
        /// <param name="prStatus">prStatus BO.</param>
        /// <returns>prStatus PM.</returns>
        public static ProductRouteStatusPM ToPresentationModel(ProductRouteStatus prStatus)
        {
            if (prStatus == null) return null;

            return new ProductRouteStatusPM
            {
                Id = prStatus.Id,

                ProductRouteId = prStatus.ProductRouteId,
                StepNo = prStatus.StepNo,
                IsApproved = prStatus.IsApproved,
                ApprovedBy = prStatus.ApprovedBy,
                Remarks = prStatus.Remarks,

                CreatedDate = prStatus.CreatedOn,
                ModifiedDate = prStatus.ModifiedOn.Value

                //OperationOperations = ToPresentationModels(prStatus.OperationOperations),
            };
        }


        /// <summary>
        /// Transforms list of prStatus PMs list of prStatus BOs.
        /// </summary>
        /// <param name="resourceoperationPMs">List of prStatus PMs.</param>
        /// <returns>List of prStatus BOs.</returns>
        public static IList<ProductRouteStatus> FromPresentationModels(IEnumerable<ProductRouteStatusPM> productroutePMs)
        {
            if (productroutePMs == null) return null;
            return productroutePMs.Select(pr => FromPresentationModel(pr)).ToList();
        }

        /// <summary>
        /// Transforms prStatus PM to prStatus BO.
        /// </summary>
        /// <param name="resourceoperationPM">prStatus PM.</param>
        /// <returns>prStatus BO.</returns>
        public static ProductRouteStatus FromPresentationModel(ProductRouteStatusPM prStatusPM)
        {
            if (prStatusPM == null) return null;

            return new ProductRouteStatus
            {
                Id = prStatusPM.Id,

                ProductRouteId = prStatusPM.ProductRouteId,
                StepNo = prStatusPM.StepNo,
                IsApproved = prStatusPM.IsApproved,
                ApprovedBy = prStatusPM.ApprovedBy,
                Remarks = prStatusPM.Remarks,

                CreatedOn = prStatusPM.CreatedDate,
                ModifiedOn = prStatusPM.ModifiedDate

                //ProductRoute = FromPresentationModels(resourceoperationPM.OperationOperations)
                
            };
        }

      
    }
}
