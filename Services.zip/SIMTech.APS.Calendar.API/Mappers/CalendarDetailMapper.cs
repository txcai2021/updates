﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;

namespace SIMTech.APS.Calendar.API.Mappers
{
    using SIMTech.APS.Calendar.API.PresentationModels;
    using SIMTech.APS.Calendar.API.Models;

    public static class CalendarDetailMapper
    {
        public static IList<CalendarDetailPM> ToPresentationModels(IEnumerable<CalendarDetail> calendarDetails)
        {
            if (calendarDetails == null) return null;
            return calendarDetails.Select(u => ToPresentationModel(u)).ToList();
        }

        public static CalendarDetailPM ToPresentationModel(CalendarDetail calendarDetail)
        {
            if (calendarDetail == null) return null;

            return new CalendarDetailPM
            {
                Id = calendarDetail.Id,
                Name = calendarDetail.CalendarDetailName,
                ParentCalendarId = calendarDetail.ParentCalendarId,
                CalendarId = calendarDetail.CalendarId,
                Sequence = calendarDetail.Sequence,
                Priority = calendarDetail.Priority,
                Interval = calendarDetail.Interval??0,
                Value = calendarDetail.Value,
                CreatedDate = calendarDetail.CreatedOn,
                //ModifiedDate = calendarDetail.ModifiedOn.Value
            };
        }

        public static IList<CalendarDetail> FromPresentationModels(IEnumerable<CalendarDetailPM> calendarDetailPMs)
        {
            if (calendarDetailPMs == null) return null;
            return calendarDetailPMs.Select(u => FromPresentationModel(u)).ToList();
        }

        public static CalendarDetail FromPresentationModel(CalendarDetailPM calendarDetailPM)
        {
            if (calendarDetailPM == null) return null;

            return new CalendarDetail
            {
                Id=calendarDetailPM.Id,
                CalendarDetailName = calendarDetailPM.Name,
                ParentCalendarId = calendarDetailPM.ParentCalendarId,
                CalendarId = calendarDetailPM.CalendarId,
                Sequence = calendarDetailPM.Sequence,
                Priority = calendarDetailPM.Priority,
                Interval = calendarDetailPM.Interval,
                Value = calendarDetailPM.Value,
                CreatedOn = calendarDetailPM.CreatedDate,
                ModifiedOn = calendarDetailPM.ModifiedDate
            };
        }
    }
}
