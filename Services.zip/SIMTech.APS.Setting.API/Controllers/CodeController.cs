﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Transactions;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using Microsoft.EntityFrameworkCore;


namespace SIMTech.APS.Setting.API.Controllers
{
    using SIMTech.APS.Setting.API.Repository;
    using SIMTech.APS.Setting.API.Models;
    using SIMTech.APS.PresentationModels;


    [Route("api/[controller]")]
    [ApiController]
    public class CodeController : ControllerBase
    {
        private readonly ICodeRepository _codeRepository;
        private readonly ExceptionManager _exceptionManager;


        public CodeController(ICodeRepository codeRepository)
        {
            _codeRepository = codeRepository;
            _exceptionManager = new ExceptionManager();
        }


        [HttpGet]
        public IEnumerable<CodeType> GetAllCodes()
        {
            //var codes = _codeRepository.GetQuery(x => x.Id > 0).ToList();

            var codes = _codeRepository.GetCodes();

            return codes;

        }

        [HttpGet]
        [Route("{id}")]
        public CodeType GetCodeById(int id) 
        {
            //var code = _codeRepository.GetById(id);
            var code = _codeRepository.GetCodes(id).FirstOrDefault();
            return code;
        }

        [HttpGet]
        [Route("Name/{name}")]
        public CodeType GetCodeByName(string name)
        {
            //var code = _codeRepository.GetQuery(x => x.CodeTypeName==name).FirstOrDefault();
            var code = _codeRepository.GetCodesbyName(name).FirstOrDefault();
            return code;
        }


        [HttpPost]
        public int AddCode([FromBody] CodeType code)
        {
           
            
            _exceptionManager.Process(() =>
            {
                _codeRepository.Insert(code);
            }, "ExceptionShielding");


            return code.Id;
           
        }

        [HttpPut]
        public void UpdateOption([FromBody] CodeType code)
        {
            _exceptionManager.Process(() =>
            {
                _codeRepository.Update(code);              
            }, "ExceptionShielding");
        }
       


    }
}
