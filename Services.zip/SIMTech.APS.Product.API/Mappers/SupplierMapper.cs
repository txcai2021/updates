﻿using System.Collections.Generic;
using System.Linq;
using SIMTech.APS.Order.Business;
using SIMTech.APS.Product.Web.PresentationModel;

namespace SIMTech.APS.Product.Web.Mappers
{
    public class SupplierMapper
    {
        public static IEnumerable<SupplierPM> ToPresentationModels(IEnumerable<Customer> customers)
        {
            if (customers == null) return null;
            return customers.Select(ToPresentationModel);
        }

        public static SupplierPM ToPresentationModel(Customer customer)
        {
            if (customer == null) return null;

            return new SupplierPM
            {
                BillingAddress = string.IsNullOrEmpty(customer.BillingAddress) ? string.Empty : customer.BillingAddress,
                Category = string .IsNullOrEmpty (customer .Category )? string.Empty  :customer .Category ,
                Address = string.IsNullOrEmpty(customer.Address) ? string.Empty : customer.Address,
                Code = string.IsNullOrEmpty(customer.CustomerName) ? string.Empty : customer.CustomerName,
                ContactPerson = string.IsNullOrEmpty(customer.ContactPerson) ? string.Empty : customer.ContactPerson,
                Department = string.IsNullOrEmpty(customer.String2) ? string.Empty : customer.String2,
                Description = string.IsNullOrEmpty(customer.MaxString1) ? string.Empty : customer.MaxString1,
                Email = string.IsNullOrEmpty(customer.Email) ? string.Empty : customer.Email,
                Fax = string.IsNullOrEmpty(customer.String3) ? string.Empty : customer.String3,
                Id = customer.CustomerID,
                Name = string.IsNullOrEmpty(customer.CustomerName) ? string.Empty : customer.CustomerName,
                Phone = string.IsNullOrEmpty(customer.Phone) ? string.Empty : customer.Phone,
                Site = string.IsNullOrEmpty(customer.String1) ? string.Empty : customer.String1,
                SupplierCode = string.IsNullOrEmpty(customer.String4) ? string.Empty : customer.String4,
                CreditTerm = string.IsNullOrEmpty(customer.String5) ? string.Empty : customer.String5,
                PictureId = customer.PictureID,                
            };
        }

        public static IEnumerable<Customer> FromPresentationModels(IEnumerable<SupplierPM> customerPMs)
        {
            if (customerPMs == null) return null;
            return customerPMs.Select(FromPresentationModel);
        }

        public static Customer FromPresentationModel(SupplierPM customerPM)
        {
            if (customerPM == null) return null;

            return new Customer
            {
                //comment
                BillingAddress = customerPM .BillingAddress ,
                Category = customerPM .Category ,
                Address = customerPM.Address,
                CompanyName = customerPM.Name,
                ContactPerson = customerPM.ContactPerson,
                CustomerID = customerPM.Id,
                CustomerName = customerPM.Name,
                Email = customerPM.Email,
                MaxString1 = customerPM.Description,
                Phone = customerPM.Phone,
                String1 = customerPM.Site,
                String2 = customerPM.Department,
                String3 = customerPM.Fax,
                String4 = customerPM.SupplierCode,
                String5 = customerPM.CreditTerm,
                PictureID = customerPM .PictureId ,
            };
        }

        public static void UpdatePresentationModel(SupplierPM customerPM, Customer customer)
        {
            if (customerPM == null || customer == null) return;
            //comment
            customerPM.BillingAddress = string.IsNullOrEmpty(customer.BillingAddress) ? string.Empty : customer.BillingAddress;
            customerPM.Category = string.IsNullOrEmpty(customer.Category ) ? string.Empty : customer.Category ;
            customerPM.Address = string.IsNullOrEmpty(customer.Address) ? string.Empty : customer.Address;
            customerPM.Code = string.IsNullOrEmpty(customer.CustomerName) ? string.Empty : customer.CustomerName;
            customerPM.ContactPerson = string.IsNullOrEmpty(customer.ContactPerson) ? string.Empty : customer.ContactPerson;
            customerPM.Department = string.IsNullOrEmpty(customer.String2) ? string.Empty : customer.String2;
            customerPM.Description = string.IsNullOrEmpty(customer.MaxString1) ? string.Empty : customer.MaxString1;
            customerPM.Email = string.IsNullOrEmpty(customer.Email) ? string.Empty : customer.Email;
            customerPM.Fax = string.IsNullOrEmpty(customer.String3) ? string.Empty : customer.String3;
            customerPM.Id = customer.CustomerID;
            customerPM.Name = string.IsNullOrEmpty(customer.CustomerName) ? string.Empty : customer.CustomerName;
            customerPM.Phone = string.IsNullOrEmpty(customer.Phone) ? string.Empty : customer.Phone;
            customerPM.Site = string.IsNullOrEmpty(customer.String1) ? string.Empty : customer.String1;
            customerPM.SupplierCode = string.IsNullOrEmpty(customer.String4) ? string.Empty : customer.String4;
            customerPM.CreditTerm = string.IsNullOrEmpty(customer.String5) ? string.Empty : customer.String5;
            //Signature ID is Priorty Column
            customerPM.PictureId  = customer.PictureID ;
        }
    }
}
