﻿using System.Collections.Generic;
using System.Linq;


namespace SIMTech.APS.Inventory.API.Mappers
{
    using SIMTech.APS.Inventory.API.Models;
    using SIMTech.APS.Inventory.API.PresentationModels;

    public static class InventoryMapper
    {
        public static IEnumerable<InventoryPM> ToPresentationModels(IEnumerable<Inventory> items)
        {
            if (items == null) return null;
            return items.Select(ToPresentationModel);
        }

        public static InventoryPM ToPresentationModel(Inventory item)
        {
            if (item == null) return null;

            InventoryPM itemPM = new InventoryPM();
            itemPM.Update(item); 
            return itemPM;
        }

        public static IEnumerable<Inventory> FromPresentationModels(IEnumerable<InventoryPM> itemPMs)
        {
            if (itemPMs == null) return null;
            return itemPMs.Select(FromPresentationModel);
        }

        public static Inventory FromPresentationModel(InventoryPM itemPM)
        {
            if (itemPM == null) return null;

            var item = new Inventory();
            item.Update(itemPM);
            return item;
        }

        public static void Update(this InventoryPM itemPM,Inventory item)
        {
            itemPM.Id = item.Id;
            itemPM.Type = item.Type.Trim();
            itemPM.PartId = item.ProductId;
            itemPM.CustomerId = item.CustomerId;
            itemPM.LocationId = item.LocationId;
            itemPM.DateIn = item.DateIn;

            itemPM.WorkOrderId = item.WorkOrderId;
            itemPM.CompletedQty = item.Quantity;
            itemPM.Cost = (decimal?)item.Float1;     
            //itemPM.BalancedQty = item.BalanceQuantity; 
            itemPM.Remarks = item.Remarks;
            itemPM.CreatedBy = item.CreatedBy;

            itemPM.Status = item.Status;
            itemPM.OperationName = item.OperationName;
            itemPM.SeqNo = item.SequenceNo;
            itemPM.AssemblyId = item.Int1;
            itemPM.BalancedQty = itemPM.CompletedQty;
            if (item.InventoryUsages != null && item.InventoryUsages.Count() > 0)
            {
                itemPM.BalancedQty -= item.InventoryUsages.Sum(x => x.Quantity);
            }
        }

        public static void Update(this Inventory item, InventoryPM itemPM)
        {
            //item.InventoryID=itemPM.Id ;
            item.Type= itemPM.Type ;
            item.ProductId =itemPM.PartId;
            item.CustomerId = itemPM.CustomerId;
            item.LocationId = itemPM.LocationId;
            item.DateIn=itemPM.DateIn;

            item.WorkOrderId = itemPM.WorkOrderId;
            item.Quantity = (decimal)itemPM.CompletedQty;
            //item.BalanceQuantity = itemPM.BalancedQty;
            item.Remarks = itemPM.Remarks;
            item.CreatedBy = itemPM.CreatedBy;

            item.Status = itemPM.Status;
            item.OperationName = itemPM.OperationName;
            item.SequenceNo = itemPM.SeqNo ;
            item.Int1 = itemPM.AssemblyId;
            item.Float1 = (double?)itemPM.Cost;   
        }  
        
    }
}
