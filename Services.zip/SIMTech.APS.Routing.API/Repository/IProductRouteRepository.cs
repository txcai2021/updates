﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace SIMTech.APS.Routing.API.Repository
{
    using SIMTech.APS.Routing.API.Models;
    using SIMTech.APS.Repository;
    public interface IProductRouteRepository : IRepository<ProductRoute>
    {
        Task<IEnumerable<ProductRoute>> GetProductRoutes(int productId);

    }
}
