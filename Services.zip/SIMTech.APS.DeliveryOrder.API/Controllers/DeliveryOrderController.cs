﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Transactions;
using System.Threading.Tasks;
using System.Linq;


namespace SIMTech.APS.DeliveryOrder.API.Controllers
{
    using SIMTech.APS.DeliveryOrder.API.Repository;
    using SIMTech.APS.DeliveryOrder.API.Mappers;
    using SIMTech.APS.DeliveryOrder.API.Models;
    using SIMTech.APS.DeliveryOrder.API.PresentationModels;
   
    [Route("api/[controller]")]
    [ApiController]
    public class DeliveryOrderController : ControllerBase
    {
        private readonly IDeliveryOrderRepository _DeliveryOrderRepository;

        public DeliveryOrderController(IDeliveryOrderRepository DeliveryOrderRepository)
        {
            _DeliveryOrderRepository = DeliveryOrderRepository;
        }


        //GET: api/Role
        [HttpGet]
        public async Task<IEnumerable<DeliveryOrder>> GetAllDeliveryOrders() => await _DeliveryOrderRepository.GetAll();
       

        [HttpGet]
        [Route("{id}")]
        public DeliveryOrder GetDeliveryOrderById(int id) => _DeliveryOrderRepository.GetById(id);
       

        [HttpPost]
        public void AddDeliveryOrder([FromBody] DeliveryOrder DeliveryOrder) => _DeliveryOrderRepository.Insert(DeliveryOrder);
       

        [HttpPut]
        public void UpdateDeliveryOrder([FromBody] DeliveryOrder DeliveryOrder) => _DeliveryOrderRepository.Update(DeliveryOrder);
       


        // DELETE api/<DeliveryOrderController>/5
        [HttpDelete("{id}")]
        public void DeleteUser(int id) => _DeliveryOrderRepository.Delete(id);






    }
}
