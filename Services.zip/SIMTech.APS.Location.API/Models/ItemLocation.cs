﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.Location.API.Models
{
    using SIMTech.APS.Models;
    public  class ItemLocation : BaseEntity
    {
        
        public int ProductLineId { get; set; }
        public int ItemId { get; set; }
        
        public virtual Location ProductLine { get; set; }
    }
}
