﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SIMTech.APS.Resource.API.Models
{

    using SIMTech.APS.Models;

    public class FixtureSetting : BaseEntity
    {
        public int FixtureId { get; set; }

		public int Category { get; set; }

		public int? PartId { get; set; }

        public int? OperationId { get; set; }

        public int? EquipmentId { get; set; }

        public string ProductFamily { get; set; }

        public int? Quantity { get; set; }

		//public virtual Equipment Equipment { get; set; }

  //      public virtual Equipment Fixture { get; set; }
    }
}
