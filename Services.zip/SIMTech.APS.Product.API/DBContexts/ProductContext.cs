﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace SIMTech.APS.Product.API.DBContext
{
    using SIMTech.APS.Product.API.Models;
    public partial class ProductContext : DbContext
    {
        public ProductContext()
        {
        }

        public ProductContext(DbContextOptions<ProductContext> options)
            : base(options)
        {
        }

        public virtual DbSet<BillOfMaterial> BillOfMaterials { get; set; }
        public virtual DbSet<CustomerItem> CustomerItems { get; set; }
        public virtual DbSet<Item> Items { get; set; }       

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<BillOfMaterial>(entity =>
            {
                entity.ToTable("BillOfMaterial");

                entity.HasIndex(e => new { e.ProductAssemblyId, e.ComponentId }, "IX_BillofMaterial_AssemblyID")
                    .IsUnique();

                entity.Property(e => e.Bomlevel).HasColumnName("BOMLevel");

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EndDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn).HasColumnType("datetime");
                   
                entity.Property(e => e.StartDate).HasColumnType("datetime");

                entity.Property(e => e.Uomcode)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .HasColumnName("UOMCode")
                    .IsFixedLength(true);

                //entity.Property(e => e.VersionStamp)
                //    .IsRequired()
                //    .IsRowVersion()
                //    .IsConcurrencyToken();

                entity.HasOne(d => d.Component)
                    .WithMany(p => p.BillOfMaterialComponents)
                    .HasForeignKey(d => d.ComponentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__BillOfMat__Compo__395884C4");

                entity.HasOne(d => d.ProductAssembly)
                    .WithMany(p => p.BillOfMaterialProductAssemblies)
                    .HasForeignKey(d => d.ProductAssemblyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__BillOfMat__Produ__3864608B");
            });

            modelBuilder.Entity<CustomerItem>(entity =>
            {
                entity.ToTable("CustomerItem");

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.CustomerId).HasColumnName("CustomerID");

                entity.Property(e => e.CustomerItemName).HasMaxLength(50);

                entity.Property(e => e.ExternalTat).HasColumnName("ExternalTAT");

                entity.Property(e => e.Int3).HasColumnType("decimal(10, 2)");

                entity.Property(e => e.InternalTat).HasColumnName("InternalTAT");

                entity.Property(e => e.ItemId).HasColumnName("ItemID");

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn)
                    .HasColumnType("datetime");


                entity.Property(e => e.ParentItemId).HasColumnName("ParentItemID");

                entity.Property(e => e.PriceUomId).HasColumnName("PriceUomID");

                entity.Property(e => e.String1).HasMaxLength(50);

                entity.Property(e => e.String2).HasMaxLength(50);

                entity.Property(e => e.String3).HasMaxLength(50);

                entity.Property(e => e.String4).HasMaxLength(50);

                entity.Property(e => e.String5).HasMaxLength(100);

                entity.Property(e => e.String6).HasMaxLength(100);

                entity.Property(e => e.String7).HasMaxLength(100);

                entity.Property(e => e.String8).HasMaxLength(100);

                entity.Property(e => e.UnitPrice).HasColumnType("money");

                //entity.Property(e => e.VersionStamp)
                //    .IsRequired()
                //    .IsRowVersion()
                //    .IsConcurrencyToken();

                entity.HasOne(d => d.Item)
                    .WithMany(p => p.CustomerItems)
                    .HasForeignKey(d => d.ItemId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CustomerItem_Item");
            });

            modelBuilder.Entity<Item>(entity =>
            {
                entity.ToTable("Item");

                entity.HasIndex(e => new { e.ItemName, e.Category, e.Int1, e.String8, e.String9 }, "IX_ItemNameCategory")
                    .IsUnique();

                entity.Property(e => e.Category).HasMaxLength(50);

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Date1).HasColumnType("datetime");

                entity.Property(e => e.Date2).HasColumnType("datetime");

                entity.Property(e => e.Date3).HasColumnType("datetime");

                entity.Property(e => e.Date4).HasColumnType("datetime");

                entity.Property(e => e.Date5).HasColumnType("datetime");

                entity.Property(e => e.Description).HasMaxLength(250);

                entity.Property(e => e.Group1).HasMaxLength(50);

                entity.Property(e => e.Group2).HasMaxLength(50);

                entity.Property(e => e.Group3).HasMaxLength(50);

                entity.Property(e => e.Group4).HasMaxLength(50);

                entity.Property(e => e.Group5).HasMaxLength(250);

                entity.Property(e => e.Group6).HasMaxLength(250);

                entity.Property(e => e.Int3).HasColumnType("decimal(10, 2)");

                entity.Property(e => e.ItemName)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn)
                    .HasColumnType("datetime");

                entity.Property(e => e.ParentItemId).HasColumnName("ParentItemID");

                entity.Property(e => e.PictureId).HasColumnName("PictureID");

                entity.Property(e => e.StandardCost).HasColumnType("money");

                entity.Property(e => e.String1).HasMaxLength(50);

                entity.Property(e => e.String2).HasMaxLength(50);

                entity.Property(e => e.String3).HasMaxLength(50);

                entity.Property(e => e.String4).HasMaxLength(50);

                entity.Property(e => e.String5).HasMaxLength(50);

                entity.Property(e => e.String6).HasMaxLength(50);

                entity.Property(e => e.String7).HasMaxLength(50);

                entity.Property(e => e.String8).HasMaxLength(50);

                entity.Property(e => e.String9).HasMaxLength(50);

                entity.Property(e => e.Subcategory).HasMaxLength(50);

                entity.Property(e => e.UnitPrice).HasColumnType("money");

                //entity.Property(e => e.VersionStamp)
                //    .IsRequired()
                //    .IsRowVersion()
                //    .IsConcurrencyToken();

                entity.HasOne(d => d.ParentItem)
                    .WithMany(p => p.InverseParentItem)
                    .HasForeignKey(d => d.ParentItemId)
                    .HasConstraintName("FK__Item__ParentItem__0C85DE4D");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
