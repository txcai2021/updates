﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.Calendar.API.Models
{
    using SIMTech.APS.Models;
    public  class Calendar :BaseEntity
    {
        public Calendar()
        {
            CalendarDetailCalendars = new HashSet<CalendarDetail>();
            CalendarDetailParentCalendars = new HashSet<CalendarDetail>();
        }

        public string CalendarName { get; set; }
        public byte Type { get; set; }
        public string Category { get; set; }
        public string Description { get; set; }
        public string DefaultValue { get; set; }
        public int? StartTime { get; set; }
        public int? EndTime { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        

        public virtual ICollection<CalendarDetail> CalendarDetailCalendars { get; set; }
        public virtual ICollection<CalendarDetail> CalendarDetailParentCalendars { get; set; }
    }
}
