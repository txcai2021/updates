﻿using System.Collections.Generic;
using System.Linq;


namespace SIMTech.APS.Customer.API.Mappers
{
    using SIMTech.APS.Customer.API.Models;
    using SIMTech.APS.Customer.API.PresentationModels;

    public class CustomerMapper
    {
        public static IEnumerable<CustomerPM> ToPresentationModels(IEnumerable<Customer> customers)
        {
            if (customers == null) return null;
            return customers.Select(ToPresentationModel);
        }

        public static CustomerPM ToPresentationModel(Customer customer)
        {
            if (customer == null) return null;

           
            return new CustomerPM
            {                               
                RegNo = customer.Category == "Unit"?customer.String4:"",
                GstRegno= customer.Category == "Unit"?customer.String5:"",
                Currency = customer.Category != "Unit"? customer.String4:"",
                CreditTerm = customer.Category != "Unit" ? customer.String5 : "",

                MaxString3 =customer.MaxString3,
                MaxString2=customer.MaxString2,

                BillingAddress = string.IsNullOrEmpty(customer.BillingAddress) ? string.Empty : customer.BillingAddress,
                Category = string.IsNullOrEmpty(customer.Category) ? string.Empty : customer.Category,
                Address = string.IsNullOrEmpty(customer.Address) ? string.Empty : customer.Address,
                Code = string.IsNullOrEmpty(customer.CustomerName) ? string.Empty : customer.CustomerName,
                Name = string.IsNullOrEmpty(customer.CompanyName) ? string.Empty : customer.CompanyName,
                ContactPerson = string.IsNullOrEmpty(customer.ContactPerson) ? string.Empty : customer.ContactPerson,
                Department = string.IsNullOrEmpty(customer.String2) ? string.Empty : customer.String2,
                Description = string.IsNullOrEmpty(customer.MaxString1) ? string.Empty : customer.MaxString1,
                Email = string.IsNullOrEmpty(customer.Email) ? string.Empty : customer.Email,
                Fax = string.IsNullOrEmpty(customer.String3) ? string.Empty : customer.String3,
                Id = customer.Id,

                Phone = string.IsNullOrEmpty(customer.Phone) ? string.Empty : customer.Phone,
                Site = string.IsNullOrEmpty(customer.String1) ? string.Empty : customer.String1,
              
                PictureId = customer.PictureId,
                Priority = customer.Priority,
            };
        }

        public static IEnumerable<Customer> FromPresentationModels(IEnumerable<CustomerPM> customerPMs)
        {
            if (customerPMs == null) return null;
            return customerPMs.Select(FromPresentationModel);
        }

        public static Customer FromPresentationModel(CustomerPM customerPM)
        {
            if (customerPM == null) return null;

            return new Customer
            {
                Id = customerPM.Id,
                CustomerName = customerPM.Code,
                CompanyName = customerPM.Name,
                Priority = customerPM.Priority,
                Address = customerPM.Address,
                MaxString1 = customerPM.Description,
                String1 = customerPM.Site,
                String2 = customerPM.Department,
                Category= customerPM.Category,
                ContactPerson = customerPM.ContactPerson,
               
                Phone = customerPM.Phone,
                Email = customerPM.Email,
                String3 =  customerPM.Fax,
                String4 = (customerPM.Category!=null && customerPM.Category=="Unit")? customerPM.RegNo : customerPM.Currency,
                String5 = (customerPM.Category != null && customerPM.Category == "Unit") ? customerPM.GstRegno : customerPM.CreditTerm,               
                PictureId = customerPM.PictureId,
                MaxString2 = customerPM.MaxString2,
                MaxString3 = customerPM.MaxString3,
                BillingAddress = customerPM.BillingAddress, 
            };
        }

        public static void UpdatePresentationModel(CustomerPM customerPM, Customer customer)
        {
            if (customerPM == null || customer == null) return;

            customerPM.Address = customer.Address;
            customerPM.Code = customer.CustomerName;
            customerPM.Department = customer.String2;
            customerPM.Description = customer.MaxString1;
            customerPM.Id = customer.Id;
            customerPM.Name = customer.CompanyName;
            customerPM.Priority = customer.Priority;
            customerPM.Site = customer.String1;

            customerPM.Phone = customer.Phone;
            customerPM.Email = customer.Email;
            customerPM.Fax = customer.String3;
            customerPM.RegNo = customer.Category == "Unit" ? customer.String4 : "";
            customerPM.GstRegno = customer.Category == "Unit" ? customer.String5 : "";
            customerPM.PictureId = customer.PictureId;
            customerPM.MaxString2 = customer.MaxString2;
            customerPM.MaxString3 = customer.MaxString3;
            customerPM.Currency = customer.Category != "Unit" ? customer.String4 : "";
            customerPM.CreditTerm = customer.Category != "Unit" ? customer.String5 : "";
            customerPM.BillingAddress = customer.BillingAddress;
        }
    }
}
