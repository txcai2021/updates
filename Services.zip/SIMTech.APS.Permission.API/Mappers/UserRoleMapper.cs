﻿using System.Collections.Generic;
using System.Linq;


namespace SIMTech.APS.Permission.API.Mappers
{
    using SIMTech.APS.Permission.API.Models;
    using SIMTech.APS.Permission.API.PresentationModels;
    public class UserRoleMapper
    {
        public static IEnumerable<UserRolePM> ToPresentationModels(IEnumerable<UserRole> userRoles)
        {
            if (userRoles == null) return null;
            return userRoles.Select(ToPresentationModel);
        }

        public static UserRolePM ToPresentationModel(UserRole userRole)
        {
            if (userRole == null) return null;

            return new UserRolePM
            {
                UserRoleId = userRole.Id,
                RoleId = userRole.RoleId,
                UserId = userRole.UserId,
            };
        }

        public static UserRole FromPresentationModel(UserRolePM userRolePM)
        {
            if (userRolePM == null) return null;

            return new UserRole
            {
                Id = userRolePM.UserRoleId,
                RoleId = userRolePM.RoleId,
                UserId = userRolePM.UserId,
            };
        }

        public static void UpdatePresentationModel(UserRolePM userRolePM, UserRole userRole)
        {
            if (userRolePM == null || userRole == null) return;

            userRolePM.UserRoleId = userRole.Id;
            userRolePM.RoleId = userRole.RoleId;
            userRolePM.UserId = userRole.UserId;
        }
    }
}
