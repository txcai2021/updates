﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

#nullable disable

namespace SIMTech.APS.DeliveryOrder.API.Models
{
    using SIMTech.APS.Models;

    [Table("DeliveryOrder")]
    public  class DeliveryOrder :BaseEntity
    {
        public DeliveryOrder()
        {
            DeliveryOrderDetails = new HashSet<DeliveryOrderDetail>();
        }

        [Required]
        [StringLength(50)]
        public string DeliveryOrderNumber { get; set; }
        public byte Type { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ShipDate { get; set; }
        public byte Status { get; set; }
        [Column("CustomerID")]
        public int? CustomerId { get; set; }
        [StringLength(250)]
        public string InvoiceAddress { get; set; }
        [StringLength(250)]
        public string ShipAddress { get; set; }
        [StringLength(10)]
        public string Currency { get; set; }
        public string Comment { get; set; }
        public int? Int1 { get; set; }
        public int? Int2 { get; set; }
        public int? Int3 { get; set; }
        public int? Int4 { get; set; }
        public bool? Flag1 { get; set; }
        public bool? Flag2 { get; set; }
        public bool? Flag3 { get; set; }
        public bool? Flag4 { get; set; }
        [StringLength(50)]
        public string String1 { get; set; }
        [StringLength(50)]
        public string String2 { get; set; }
        [StringLength(50)]
        public string String3 { get; set; }
        [StringLength(50)]
        public string String4 { get; set; }
        [StringLength(50)]
        public string String5 { get; set; }
        [StringLength(250)]
        public string String6 { get; set; }
        [StringLength(250)]
        public string String7 { get; set; }
        [StringLength(250)]
        public string String8 { get; set; }
        [StringLength(250)]
        public string String9 { get; set; }
        [StringLength(250)]
        public string String10 { get; set; }
        [StringLength(250)]
        public string String11 { get; set; }
        [StringLength(250)]
        public string String12 { get; set; }
        public string MaxString1 { get; set; }
        public string MaxString2 { get; set; }     

        [InverseProperty(nameof(DeliveryOrderDetail.DeliveryOrder))]
        public virtual ICollection<DeliveryOrderDetail> DeliveryOrderDetails { get; set; }
    }
}
