﻿using System.ComponentModel.DataAnnotations;
using SIMTech.APS.Resources;

namespace SIMTech.APS.Product.API.PresentationModels
{
    public class KitPM
    {
        [Key]
        public int Id { get; set; }

        [StringLength(100, ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ValidationErrorBadKitName")]
        [Required(ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ValidationErrorRequiredField")]
        [Display(ShortName = "KitName", ResourceType = typeof(SharedResources), Name = "KitName")]
        public string Name { get; set; }

        [StringLength(250, ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ValidationErrorBadKitDescription")]
        [Display(ShortName = "KitDescription", ResourceType = typeof(SharedResources), Name = "KitDescription")]
        public string Description { get; set; }

        [Display(ShortName = "KitCategory", ResourceType = typeof(SharedResources), Name = "KitCategory")]
        public string Category { get; set; }

        //Nitharshan
        [Display(ShortName = "IsActive", ResourceType = typeof(SharedResources), Name = "IsActive")]
        public bool? IsActive { get; set; }

        [Display(ShortName = "NoOfItems", ResourceType = typeof(SharedResources), Name = "NoOfItems")]
        public int NoOfItems { get; set; }

        [Required(ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ValidationErrorRequiredField")]
        [Display(ShortName = "KitKitTypeId", ResourceType = typeof(SharedResources), Name = "KitKitTypeId")]
        public int KitTypeId { get; set; }

        [Required(ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ValidationErrorRequiredField")]
        [Display(ShortName = "KitKitTypeName", ResourceType = typeof(SharedResources), Name = "KitKitTypeName")]
        public string KitTypeName { get; set; }

        [Required(ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ValidationErrorRequiredField")]
        [Display(ShortName = "KitCustomerId", ResourceType = typeof(SharedResources), Name = "KitCustomerId")]
        public int CustomerId { get; set; }

        [Required(ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ValidationErrorRequiredField")]
        [Display(ShortName = "KitCustomerCode", ResourceType = typeof(SharedResources), Name = "KitCustomerCode")]
        public string CustomerCode { get; set; }
    }
}
