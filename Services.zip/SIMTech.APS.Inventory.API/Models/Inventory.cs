﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

#nullable disable

namespace SIMTech.APS.Inventory.API.Models
{
    using SIMTech.APS.Models;

    [Table("Inventory")]
    public  class Inventory : BaseEntity
    {
        public Inventory()
        {
            InventoryUsages = new HashSet<InventoryUsage>();
        }
        [Column("LocationID")]
        public int? LocationId { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime DateIn { get; set; }
        [Required]
        [StringLength(5)]
        public string Type { get; set; }
        [Column("ProductID")]
        public int ProductId { get; set; }
        [Column("WorkOrderID")]
        public int? WorkOrderId { get; set; }
        public int? SequenceNo { get; set; }
        [StringLength(50)]
        public string OperationName { get; set; }
        [Column("CustomerID")]
        public int? CustomerId { get; set; }
        [Column(TypeName = "decimal(18, 3)")]
        public decimal? Quantity { get; set; }
        [Column(TypeName = "decimal(18, 2)")]
        public decimal? BalanceQuantity { get; set; }
        [StringLength(250)]
        public string Remarks { get; set; }
        [StringLength(50)]
        public string Status { get; set; }
        [StringLength(250)]
        public string String1 { get; set; }
        [StringLength(250)]
        public string String2 { get; set; }
        public string String3 { get; set; }
        public string String4 { get; set; }
        public int? Int1 { get; set; }
        public int? Int2 { get; set; }
        public double? Float1 { get; set; }
        public double? Float2 { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? Date1 { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? Date2 { get; set; }

        [InverseProperty(nameof(InventoryUsage.Inventory))]
        public virtual ICollection<InventoryUsage> InventoryUsages { get; set; }
    }
}
