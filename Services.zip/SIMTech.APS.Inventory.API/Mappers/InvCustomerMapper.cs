﻿using System.Collections.Generic;
using System.Linq;


namespace SIMTech.APS.Inventory.API.Mappers
{
    using SIMTech.APS.Inventory.API.Models;
    using SIMTech.APS.Inventory.API.PresentationModels;
    using SIMTech.APS.PresentationModels;
    public class InvCustomerMapper
    {
        public static IEnumerable<InvCustomerPM> ToPresentationModels(IList<IdNamePM> customers)
        {
            if (customers == null) return null;
            return customers.Select(ToPresentationModel);
        }

        public static InvCustomerPM ToPresentationModel(IdNamePM customer)
        {
            if (customer == null) return null;

            return new InvCustomerPM
            {
                Code = string.IsNullOrEmpty(customer.Name) ? string.Empty : customer.Name,
                Name = string.IsNullOrEmpty(customer.Description) ? string.Empty : customer.Description,
                Id = customer.Id,
                Site = string.IsNullOrEmpty(customer.String1) ? string.Empty : customer.String1
              
            };
        }
    }
}
