﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
//using SIMTech.APS.Resource.Services.Web;
using SIMTech.APS.Resources;



namespace SIMTech.APS.Operation.API.PresentationModels
{
    using SIMTech.APS.PresentationModels;
    
    /// <summary>
    /// </summary>
    public class OperationRatePM
    {
        public OperationRatePM()
        {
            UOMList = new List<UoMPM>();
        }

        [Key]
        [Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
        public int Id { get; set; }

        public int? RouteId { get; set; }

        public int? RouteOperationId { get; set; }

        [Display(ShortName = "OperationId", ResourceType = typeof(SharedResources), Name = "OperationId", Order = 0)]
        public int? OperationId { get; set; }

        [Display(ShortName = "ResourceId", ResourceType = typeof(SharedResources), Name = "ResourceId", Order = 1)]
        public int? ResourceId { get; set; }

        public int? ItemId { get; set; }

        public int? AssemblyId { get; set; }
        

        //[Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
        //[Display(ShortName = "Default", ResourceType = typeof(SharedResources), Name = "Default", Order = 3)]
        public bool isDefault { get; set; }

        //[Display(ShortName = "Cost", ResourceType = typeof(SharedResources), Name = "Cost", Order = 4)]
        public double? Cost { get; set; }

        //[Display(ShortName = "Pretime", ResourceType = typeof(SharedResources), Name = "Pretime", Order = 5)]
        public double? Pretime { get; set; }

        //[Display(ShortName = "Posttime", ResourceType = typeof(SharedResources), Name = "Posttime", Order = 6)]
        public double? Posttime { get; set; }

        //[Display(ShortName = "ProductionRate", ResourceType = typeof(SharedResources), Name = "ProductionRate", Order = 7)]
        public double? ProductionRate { get; set; }

        //[Display(ShortName = "ProdRateUoM", ResourceType = typeof(SharedResources), Name = "ProdRateUoM", Order = 8)]
        public int? ProdRateUoM { get; set; }

        public string UoMName { get; set; }

        [Display(ShortName = "Description", ResourceType = typeof(SharedResources), Name = "Description", Order = 9)]
        public string Description { get; set; }

        //[Display(ShortName = "Comments", ResourceType = typeof(SharedResources), Name = "Comments", Order = 10)]
        public string Comment { get; set; }

        [Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
        //[Display(ShortName = "CreatedDate", ResourceType = typeof(SharedResources), Name = "CreatedDate", Order = 11)]
        public DateTime CreatedDate { get; set; }

        //[Association("FK_Operation_OperationResources", "OperationId", "Id", IsForeignKey = true)]
        public OperationPM operationPM { get; set; }

        public BasePM resourcePM { get; set; }

        public string OperationName { get; set; }
        public string ResourceName { get; set; }
        public string AssemblyName { get; set; }
        public string ItemName { get; set; }
        public string Setting { get; set; }

        public int ResourceType { get; set; }
      
        public double?  ResourceCost { get; set; }

        public string rpNameValue { get; set; }

        public string LocationName { get; set; }

        //public bool IsSubCon{ get; set; }

        public bool IsInhouse { get; set; }


         
        public IEnumerable<UoMPM> UOMList { get; set; }


        //  [ExternalReference]
        //[Association("FK_Item_SalesOrderLine", "ProductId", "Id", IsForeignKey = true)]
    }
}
