﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using SIMTech.APS.Resources;

namespace SIMTech.APS.Calendar.API.PresentationModels
{

    public class CalendarPM
    {
        public CalendarPM()
        {
            CalendarDetails = new List<CalendarDetailPM>();
        }

        [Key]
        [Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
        public int Id { get; set; }

        [Display(ShortName = "CalendarName", ResourceType = typeof(SharedResources), Name = "CalendarName")]
        [Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
        [StringLength(100)]
        //[RegularExpression("^[a-zA-Z0-9_]*$", ErrorMessageResourceName = "ValidationErrorInvalidName", ErrorMessageResourceType = typeof(ErrorResources))]
        public string Name { get; set; }

       // [Display(ShortName = "Type", ResourceType = typeof(SharedResources), Name = "Type")]
        [Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
        //[CustomValidation(typeof(UserRules), "IsValidEmail")]
        public byte Type { get; set; }

       // [Display(ShortName = "Category", ResourceType = typeof(SharedResources), Name = "Category")]
        [Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
        //[CustomValidation(typeof(UserRules), "IsValidEmail")]
        public string Category { get; set; }

        [Display(ShortName = "Description", ResourceType = typeof(SharedResources), Name = "Description")]
        public string Description { get; set; }

        //[Display(ShortName = "DefaultValue", ResourceType = typeof(SharedResources), Name = "DefaultValue")]
        public string DefaultValue { get; set; }

        [Display(ShortName = "StartTime", ResourceType = typeof(SharedResources), Name = "StartTime")]
        [RegularExpression("^(?:0?[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$", ErrorMessageResourceName = "ValidationErrorInvalidName", ErrorMessageResourceType = typeof(ErrorResources))]
        public string StartTime { get; set; }

        [Display(ShortName = "EndTime", ResourceType = typeof(SharedResources), Name = "EndTime")]
        [RegularExpression("^(?:0?[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$", ErrorMessageResourceName = "ValidationErrorInvalidName", ErrorMessageResourceType = typeof(ErrorResources))]
        public string EndTime { get; set; }

        //[Display(ShortName = "StartDate", ResourceType = typeof(SharedResources), Name = "StartDate")]
        public DateTime? StartDate { get; set; }

       // [Display(ShortName = "EndDate", ResourceType = typeof(SharedResources), Name = "EndDate")]
        public DateTime? EndDate { get; set; }

        [Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
       // [Display(ShortName = "CreatedDate", ResourceType = typeof(SharedResources), Name = "CreatedDate")]
        public DateTime CreatedDate { get; set; }

        public DateTime ModifiedDate { get; set; }

       // [Display(ShortName = "IsStaggered", ResourceType = typeof(SharedResources), Name = "IsStaggered")]
        public bool? IsStaggered { get; set; }

        //[Include]
        //[Composition]
        //[Association("FK_CalendarDetail_Calendar", "Id", "ParentCalendarId")]
        //[Display(ShortName = "CalendarDetails", ResourceType = typeof(SharedResources), Name = "CalendarDetails")]
        public IEnumerable<CalendarDetailPM> CalendarDetails { get; set; }
        public IEnumerable<CalendarDetailPM> CalendarChilds{ get; set; }




        //[Include]
        //[Composition]
        //[Association("FK_Resource_ResourceOperations", "Id", "ResourceId")]
        //public List<ResourceOperationPM> resourceOperationPMs { get; set; }
        //public string OperationNames { get; set; }

        //[Include]
        //[Association("FK_ParentResource", "ParentResourceId", "Id", IsForeignKey = true)]
        //[Display(ShortName = "ParentResource", ResourceType = typeof(SharedResources), Name = "ParentResource")]
        //public ResourcePM ParentResource { get; set; }



    }
}
