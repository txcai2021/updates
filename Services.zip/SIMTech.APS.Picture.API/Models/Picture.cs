﻿using System;
using System.Collections.Generic;


namespace SIMTech.APS.Picture.API.Models
{
    using SIMTech.APS.Models;
    public partial class Picture : BaseEntity
    {
        
        public byte[] ThumbNailImage { get; set; }
        public string ThumbnailImageFileName { get; set; }
        public byte[] LargeImage { get; set; }
        public string LargeImageFileName { get; set; }
       
    }
}
