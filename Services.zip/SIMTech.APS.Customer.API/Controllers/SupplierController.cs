﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Transactions;
using System.Threading.Tasks;
using System.Linq;


namespace SIMTech.APS.Supplier.API.Controllers
{
    using SIMTech.APS.Customer.API.Repository;
    using SIMTech.APS.Customer.API.Mappers;
    using SIMTech.APS.Customer.API.Models;
    using SIMTech.APS.Customer.API.PresentationModels;
    //using SIMTech.APS.Customer.API.PresentationModels;

    [Route("api/[controller]")]
    [ApiController]
    public class SupplierController : ControllerBase
    {
        private readonly ICustomerRepository _supplierRepository;

        public SupplierController(ICustomerRepository supplierRepository)
        {
            _supplierRepository = supplierRepository;
        }


        //GET: api/Role
        [HttpGet]
        //public async Task<IEnumerable<Customer>> GetAllCustomers() => await _CustomerRepository.GetAll();
        public  IEnumerable<SupplierPM> GetAllSuppliers()
        {
           var customers = _supplierRepository.GetQuery(x => x.Category == "Supplier").OrderBy(x=>x.CustomerName).ToList();

            return SupplierMapper.ToPresentationModels(customers).OrderBy(cus => cus.Code).AsQueryable();
        }

      

        [HttpGet]
        [Route("{id}")]
        //public Customer GetCustomerById(int id) => _customerRepository.GetById(id);
        public SupplierPM GetSupplierById(int id)
        {
            var a = _supplierRepository.GetById(id);
            return SupplierMapper.ToPresentationModel(a);
        }
        


        [HttpPost]
        public IActionResult AddSupplier([FromBody]  SupplierPM supplierPM)
        {
            var supplier = SupplierMapper.FromPresentationModel(supplierPM);
            supplier.CreatedOn = DateTime.Today;
            supplier.Category = "Supplier";      
            _supplierRepository.Insert(supplier);

            SupplierMapper.UpdatePresentationModel(supplierPM, supplier);
            return new OkObjectResult(supplierPM);
        }

        [HttpPut]
        public void UpdateSupplier([FromBody] SupplierPM supplierPM)
        {
            var supplier = SupplierMapper.FromPresentationModel(supplierPM);
            var existingsupplier = _supplierRepository.GetById(supplier.Id);

            existingsupplier.CustomerName = supplier.CustomerName;
            existingsupplier.Address = supplier.Address;
            existingsupplier.CompanyName = supplier.CompanyName;
            existingsupplier.ContactPerson = supplier.ContactPerson;

            existingsupplier.Email = supplier.Email;
            existingsupplier.MaxString1 = supplier.MaxString1;
            existingsupplier.Phone = supplier.Phone;
            existingsupplier.String1 = supplier.String1;
            existingsupplier.String2 = supplier.String2;
            existingsupplier.String3 = supplier.String3;
            existingsupplier.String4 = supplier.String4;
            existingsupplier.String5 = supplier.String5;
            existingsupplier.BillingAddress = supplier.BillingAddress;
            existingsupplier.Category = "Supplier";

            _supplierRepository.Update(existingsupplier);
        }




        // DELETE api/<RoleController>/5
        [HttpDelete("{id}")]
        public void DeleteSupplier(int id)
        {
            try
            {
                _supplierRepository.Delete(id);
            }
            catch (Exception exception)
            {
                if (exception.InnerException == null) throw;
                var sqlException = exception.InnerException as Microsoft.Data.SqlClient.SqlException;
                if (sqlException == null) throw;

                if (sqlException.Number != 547) throw;
                throw new Exception("Record cannot be deleted due related records.");
            }


        }

    }
}
