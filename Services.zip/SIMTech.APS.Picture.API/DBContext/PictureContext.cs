﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;


#nullable disable

namespace SIMTech.APS.Picture.API.DBContext
{
    using SIMTech.APS.Picture.API.Models;

    public partial class PictureContext : DbContext
    {

        public PictureContext()
        {
        }

        public PictureContext(DbContextOptions<PictureContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Picture> Pictures { get; set; }

        

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<Picture>(entity =>
            {
                entity.ToTable("Picture");

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LargeImageFileName).HasMaxLength(50);

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                //entity.Property(e => e.ModifiedOn)
                //    .HasColumnType("datetime")
                //    .HasComputedColumnSql("(getdate())", false);

                entity.Property(e => e.ThumbnailImageFileName).HasMaxLength(50);

                //entity.Property(e => e.VersionStamp)
                //    .IsRequired()
                //    .IsRowVersion()
                //    .IsConcurrencyToken();
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
