﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace SIMTech.APS.Permission.API.DBContext
{
    using SIMTech.APS.Permission.API.Models;
    
    public partial class PermissionContext : DbContext
    {
     

        public PermissionContext(DbContextOptions<PermissionContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Button> Buttons { get; set; }
        public virtual DbSet<Menu> Menus { get; set; }
        public virtual DbSet<Role> Roles { get; set; }
        public virtual DbSet<RoleTask> RoleTasks { get; set; }
        public virtual DbSet<Task> Tasks { get; set; }
        public virtual DbSet<UserRole> UserRoles { get; set; }

       
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<Button>(entity =>
            {
                entity.ToTable("Button");

                entity.HasIndex(e => e.ButtonName, "IX_Button_ButtonName")
                    .IsUnique();

                entity.Property(e => e.ButtonName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Description).HasMaxLength(250);

                entity.Property(e => e.DisplayText)
                    .HasMaxLength(50)
                    .IsFixedLength(true);

                entity.Property(e => e.Image).HasColumnType("image");

                entity.Property(e => e.ImageFileName)
                    .HasMaxLength(250)
                    .IsFixedLength(true);

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn).HasColumnType("datetime");


                entity.Property(e => e.Type)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                //entity.Property(e => e.VersionStamp)
                //    .IsRequired()
                //    .IsRowVersion()
                //    .IsConcurrencyToken();
            });

            modelBuilder.Entity<Menu>(entity =>
            {
                entity.ToTable("Menu");

                entity.HasIndex(e => new { e.ParentTaskId, e.TaskId }, "IX_Menu_TaskId")
                    .IsUnique();

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn).HasColumnType("datetime");

                //entity.Property(e => e.VersionStamp)
                //    .IsRequired()
                //    .IsRowVersion()
                //    .IsConcurrencyToken();

                entity.HasOne(d => d.ParentTask)
                    .WithMany(p => p.MenuParentTasks)
                    .HasForeignKey(d => d.ParentTaskId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Menu__ParentTask__6A30C649");

                entity.HasOne(d => d.Task)
                    .WithMany(p => p.MenuTasks)
                    .HasForeignKey(d => d.TaskId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Menu__TaskId__6B24EA82");
            });

            modelBuilder.Entity<Role>(entity =>
            {
                entity.ToTable("Role");

                entity.HasIndex(e => e.RoleName, "IX_Role_RoleName")
                    .IsUnique();

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Description).HasMaxLength(250);

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn).HasColumnType("datetime");

                entity.Property(e => e.RoleName)
                    .IsRequired()
                    .HasMaxLength(50);

                //entity.Property(e => e.VersionStamp)
                //    .IsRequired()
                //    .IsRowVersion()
                //    .IsConcurrencyToken();
            });

            modelBuilder.Entity<RoleTask>(entity =>
            {
                entity.ToTable("RoleTask");

                entity.HasIndex(e => new { e.RoleId, e.TaskId }, "IX_RoleTask_RoleTaskId")
                    .IsUnique();

                entity.Property(e => e.AccessMode)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn).HasColumnType("datetime");

                //entity.Property(e => e.VersionStamp)
                //    .IsRequired()
                //    .IsRowVersion()
                //    .IsConcurrencyToken();

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.RoleTasks)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__RoleTask__RoleId__778AC167");

                entity.HasOne(d => d.Task)
                    .WithMany(p => p.RoleTasks)
                    .HasForeignKey(d => d.TaskId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__RoleTask__TaskId__787EE5A0");
            });

            modelBuilder.Entity<Task>(entity =>
            {
                entity.ToTable("Task");

                entity.HasIndex(e => new { e.ModuleName, e.TaskName }, "IX_Task_TaskName")
                    .IsUnique();

                entity.Property(e => e.ActionName)
                    .HasMaxLength(50)
                    .IsFixedLength(true);

                entity.Property(e => e.ButtonId).HasColumnName("ButtonID");

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Description).HasMaxLength(250);

                entity.Property(e => e.DisplayText)
                    .HasMaxLength(50)
                    .IsFixedLength(true);

                entity.Property(e => e.Group).HasMaxLength(50);

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn).HasColumnType("datetime");

                entity.Property(e => e.ModuleName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.OrderBy)
                    .HasMaxLength(250)
                    .IsFixedLength(true);

                entity.Property(e => e.Selection)
                    .HasMaxLength(250)
                    .IsFixedLength(true);

                entity.Property(e => e.Setting)
                    .HasMaxLength(250)
                    .IsFixedLength(true);

                entity.Property(e => e.TaskName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Type)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                //entity.Property(e => e.VersionStamp)
                //    .IsRequired()
                //    .IsRowVersion()
                //    .IsConcurrencyToken();

                entity.HasOne(d => d.Button)
                    .WithMany(p => p.Tasks)
                    .HasForeignKey(d => d.ButtonId)
                    .HasConstraintName("FK__Task__ButtonID__5FB337D6");
            });

            modelBuilder.Entity<UserRole>(entity =>
            {
                entity.ToTable("UserRole");

                entity.HasIndex(e => new { e.UserId, e.RoleId }, "IX_UserRole_UserRoleId")
                    .IsUnique();

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn).HasColumnType("datetime");

                //entity.Property(e => e.VersionStamp)
                //    .IsRequired()
                //    .IsRowVersion()
                //    .IsConcurrencyToken();

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.UserRoles)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__UserRole__RoleId__70DDC3D8");
            });

            OnModelCreatingPartial(modelBuilder);
        }
     

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
      

        
    }
}
