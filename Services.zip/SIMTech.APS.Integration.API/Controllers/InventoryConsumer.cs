﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text;
using System.Threading;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using Newtonsoft.Json;

namespace SIMTech.APS.Integration.RabbitMQ
{
    using Models;
    using SIMTech.APS.Utilities;
    using SIMTech.APS.PresentationModels;
    using SIMTech.APS.Customer.API.PresentationModels;
    public class InventoryConsumer : BackgroundService
    {
        private readonly ILogger _logger;
        private IConnection _connection;
        private IModel _channel;
        private string _queueName;
        private string _exchangeName;
        private bool _enableRabbitMQ = false;
        

        public InventoryConsumer(ILoggerFactory loggerFactory)
        {
            this._logger = loggerFactory.CreateLogger<InventoryConsumer>();
            InitRabbitMQ();
        }

        private void InitRabbitMQ()
        {
            var rabbit_enable = Environment.GetEnvironmentVariable("RABBITMQ_ENABLE");

            _enableRabbitMQ = rabbit_enable != null && rabbit_enable == "100" ;

            if (!_enableRabbitMQ) 
                Console.WriteLine("InitRabbitMQ for Customer: RabbitMQ is disabled");
            else
                Console.WriteLine("InitRabbitMQ for Inventory");

            var factory = new ConnectionFactory
            {
                HostName = Environment.GetEnvironmentVariable("RABBITMQ_HOST"),
                Port = Convert.ToInt32(Environment.GetEnvironmentVariable("RABBITMQ_PORT")),                
                UserName = Environment.GetEnvironmentVariable("RABBITMQ_USERNAME")??"guest",
                Password = Environment.GetEnvironmentVariable("RABBITMQ_PASSWORD")??"guest"

            };

            var vHost = Environment.GetEnvironmentVariable("RABBITMQ_VHOST") ?? string.Empty;
            if (vHost != string.Empty) factory.VirtualHost = vHost;

            Console.WriteLine(factory.HostName + ":" + factory.Port + "/" + factory.VirtualHost);

            // create connection  
            _connection = factory.CreateConnection();

            // create channel  
            _channel = _connection.CreateModel();

            //_channel.ExchangeDeclare("demo.exchange", ExchangeType.Topic);
            _queueName = Environment.GetEnvironmentVariable("RABBITMQ_QUEUE_INVENTORY") ?? "rps-inventory";
            _exchangeName = Environment.GetEnvironmentVariable("RABBITMQ_EXCHANGE") ?? "cpps-rps";          
            _channel.QueueDeclare(_queueName, true, false, false, null);
            //_channel.QueueDeclare(_queueName, true, false, false, null);
            //_channel.QueueBind(_queueName, _exchangeName, "rps-customer", null);
            //_channel.BasicQos(0, 1, false);

            _connection.ConnectionShutdown += RabbitMQ_ConnectionShutdown;
        }

        protected override Task ExecuteAsync(CancellationToken stoppingToken)
        {
            if (!_enableRabbitMQ) Console.WriteLine("ExecuteAsync:RabbitMQ is disabled");

            stoppingToken.ThrowIfCancellationRequested();

            var consumer = new EventingBasicConsumer(_channel);
            consumer.Received += (ch, ea) =>
            {
            // received message  
            var content = System.Text.Encoding.UTF8.GetString(ea.Body.ToArray());

            // handle the received message  
            HandleMessageAsync(content);
                _channel.BasicAck(ea.DeliveryTag, false);
            };

            consumer.Shutdown += OnConsumerShutdown;
            consumer.Registered += OnConsumerRegistered;
            consumer.Unregistered += OnConsumerUnregistered;
            consumer.ConsumerCancelled += OnConsumerConsumerCancelled;

            _channel.BasicConsume(_queueName, false, consumer);
            return Task.CompletedTask;
        }

        private async Task HandleMessageAsync(string content)
        {
            // we just print this message   
            _logger.LogInformation($"consumer received {content}");

            var inventoryPlan = new InventoryPlan();
            try
            {
                inventoryPlan = JsonConvert.DeserializeObject<InventoryPlan>(content);
            }
            catch (Exception e) { 
                Console.WriteLine(e.Message);  
            }
            
            if (inventoryPlan !=null)
            {
                _logger.LogInformation($"after received inventory plan: {inventoryPlan.FromWarehouse}/{inventoryPlan.ToWarehouse}/{inventoryPlan.SalesOrderNo}");


                //await Task.Delay(3000);
                if (inventoryPlan.RawMaterialRebalacingPlan!=null)
                {
                    foreach (var invPlan in inventoryPlan.RawMaterialRebalacingPlan)
                    {
                        var material = new Material()
                        {
                            LocationId = 0,
                            LocationName = inventoryPlan.RequestedByFactoryID,
                            DateIn = inventoryPlan.RebalancingPlanGenerationDate,
                            Remarks = "From warehouse:" + inventoryPlan.FromWarehouse + "To warehouse:" + inventoryPlan.ToWarehouse,
                            PartId = invPlan.RawMaterialId,
                            PartNo = invPlan.RawMaterialNo,
                            CompletedQty = (decimal)invPlan.QuantityToTransfer
                        };

                        var result = ApiAddInventory(material);

                        if (result > 0)
                        {
                            _logger.LogInformation("The material:" + material.PartNo + " has been added succesfully");
                            //result = ApiUpdateWorkOrderMaterial(material);

                            //if (result > 0)
                            //    _logger.LogInformation("The material:" + material.PartNo + " has been allocated work orders succesfully");
                        }
                    }
   
                }


                
            }
           

        }

        private void OnConsumerConsumerCancelled(object sender, ConsumerEventArgs e) { }
        private void OnConsumerUnregistered(object sender, ConsumerEventArgs e) { }
        private void OnConsumerRegistered(object sender, ConsumerEventArgs e) { }
        private void OnConsumerShutdown(object sender, ShutdownEventArgs e) { }
        private void RabbitMQ_ConnectionShutdown(object sender, ShutdownEventArgs e) { }

        public override void Dispose()
        {
            _channel.Close();
            _connection.Close();
            base.Dispose();
        }

        private int ApiAddInventory(Material material)
        {
            int inventoryId = 0;

            var apiBaseUrl = Environment.GetEnvironmentVariable("RPS_INVENTORY_URL");

            if (!string.IsNullOrWhiteSpace(apiBaseUrl))
            {
                try
                {
                    var result = HttpHelper.PostAsync<Material, Material>(apiBaseUrl, "RM", material).Result;
                    if (result != null) inventoryId = result.Id;
                }
                catch (Exception e)
                {
                    _logger.LogInformation($"{ e.Message}");
                    if (e.InnerException!=null) _logger.LogInformation($"{ e.InnerException.Message}");
                }
            }

            return inventoryId;
        }

        private int ApiUpdateWorkOrderMaterial(Material material)
        {

            int result = 0;
           
            var apiBaseUrl = Environment.GetEnvironmentVariable("RPS_WORKORDER_URL");

            var a = new IdNamePM() { Id = material.PartId, Name = material.PartNo, Float1 = (float)material.CompletedQty };

            if (!string.IsNullOrWhiteSpace(apiBaseUrl))
            {
                try
                {
                     result = HttpHelper.PostAsync<IdNamePM,int>(apiBaseUrl, "Material", a).Result;
                    
                }
                catch (Exception e)
                {
                    _logger.LogInformation($"{ e.Message}");
                }
            }

            return result;
        }
    }
}