﻿using System.Collections.Generic;
using System.Linq;


namespace SIMTech.APS.Location.API.Mappers
{

    using SIMTech.APS.Location.API.Models;
    using SIMTech.APS.Location.API.PresentationModels;

    public class LocationMapper
    {
        public static IEnumerable<LocationPM> ToPresentationModels(IEnumerable<Location> locations)
        {
            if (locations == null) return null;
            return locations.Select(ToPresentationModel);
        }

        public static LocationPM ToPresentationModel(Location location)
        {
            if (location == null) return null;

            return new LocationPM
            {
                Category = location.Category,
                Description = location.Description == null ? location.LocationName : location.Description,
                Id = location.Id,
                Name = location.LocationName,
                SubCategory = location.Subcategory,
                CalenderID = location.CalendarId
                
            };
        }

        public static Location FromPresentationModel(LocationPM locationPM)
        {
            if (locationPM == null) return null;

            return new Location
            {

                Category = locationPM.Category,
                Description = locationPM.Description,
                Id = locationPM.Id,
                LocationName = locationPM.Name,
                Subcategory = locationPM.SubCategory,
                CalendarId = locationPM.CalenderID
                
                //CreatedOn = locationPM.cre,

            };
        }

    }
}
