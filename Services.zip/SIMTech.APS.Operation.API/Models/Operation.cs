﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.Operation.API.Models
{
    using SIMTech.APS.Models;
    public  class Operation : BaseEntity
    {
        public Operation()
        {
            OperationParameters = new HashSet<OperationParameter>();
            OperationResources = new HashSet<OperationResource>();
        }
        public string OperationName { get; set; }
        public byte Type { get; set; }
        public string Categroy { get; set; }
        public string Description { get; set; }
        public string Instruction { get; set; }
        public int? Version { get; set; }
        public int? LocationId { get; set; }
        public double? SizeMin { get; set; }
        public double? SizeMultiple { get; set; }
        public double? Cost { get; set; }
        public double? Pretime { get; set; }
        public double? Posttime { get; set; }
        public double? Duration { get; set; }
        public double? DurationPer { get; set; }
        public int? Uom { get; set; }
        public bool IsActive { get; set; }
         
        public virtual ICollection<OperationParameter> OperationParameters { get; set; }
        public virtual ICollection<OperationResource> OperationResources { get; set; }
    }
}
