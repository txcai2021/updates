﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.Setting.API.Models
{
    using SIMTech.APS.Models;
    public partial class UserPreference :BaseEntity
    {
        public int UserId { get; set; }
        public int OptionId { get; set; }
        public string Setting { get; set; }
        public virtual Option Option { get; set; }
    }
}
