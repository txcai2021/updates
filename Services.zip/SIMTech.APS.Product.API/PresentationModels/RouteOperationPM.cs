﻿using System.ComponentModel.DataAnnotations;
using SIMTech.APS.Resources;

namespace SIMTech.APS.Product.API.PresentationModels
{
    public class RouteOperationPM
    {
        [Key]
        [Display(ShortName = "RoutingOperationId", ResourceType = typeof(SharedResources), Name = "RoutingOperationId", Order = 0)]
        public int Id { get; set; }

        [Display(ShortName = "RoutingId", ResourceType = typeof(SharedResources), Name = "RoutingId", Order = 1)]
        public int RouteId { get; set; }

        [Display(ShortName = "OperationId", ResourceType = typeof(SharedResources), Name = "OperationId", Order = 2)]
        public int OperationId { get; set; }

      
        [Display(ShortName = "Sequence", ResourceType = typeof(SharedResources), Name = "Sequence", Order = 3)]
        public int Sequence { get; set; }


        [Display(ShortName = "OperationName", ResourceType = typeof(SharedResources), Name = "OperationName", Order = 4)]
        public string OperationName { get; set; }

    }
}
