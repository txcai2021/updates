﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace SIMTech.APS.Setting.API.Repository
{
    using SIMTech.APS.Setting.API.Models;
    using SIMTech.APS.Setting.API.DBContext;
    using SIMTech.APS.Repository;

    public class OptionRepository : Repository<Option>,  IOptionRepository
    {
        private readonly SettingContext _dbContext;
        public OptionRepository(SettingContext context) : base(context) { _dbContext = context; }
       
    }
}
