﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;

namespace SIMTech.APS.Operation.API.Mappers
{
    using SIMTech.APS.Operation.API.Models;
    using SIMTech.APS.Operation.API.PresentationModels;

    /// <summary>
    /// Maps  PMs (Presentation Models) to  BOs (Business Objects) and vice versa.
    /// </summary>
    public static class OperationMapper
    {

        /// <summary>
        /// Transforms list of operation BOs list of operation PMs.
        /// </summary>
        /// <param name="operations">List of operation BOs.</param>
        /// <returns>List of operation PMs.</returns>
        public static IEnumerable<OperationPM> ToPresentationModels(IEnumerable<Operation> operations)
        {
            if (operations == null) return null;
            return operations.Select(u => ToPresentationModel(u)).ToList();
        }

        /// <summary>
        /// Transforms operation BO to operation PM.
        /// </summary>
        /// <param name="operation">operation BO.</param>
        /// <returns>operation PM.</returns>
        public static OperationPM ToPresentationModel(Operation operation)
        {
            if (operation == null) return null;

            return new OperationPM
            {

                Id = operation.Id,
                Name = operation.OperationName,
                Type = operation.Type,
                Category = operation.Categroy,
                LocationId = operation.LocationId,
                Description = operation.Description,
                Instruction = operation.Instruction,
                Remarks = operation.CreatedBy ,
                Active = operation.IsActive,
                PictureId = (String.IsNullOrWhiteSpace(operation.ModifiedBy) ? 0 : Convert.ToInt32(operation.ModifiedBy)),
                CreatedDate = operation.CreatedOn,
                Version = operation.Version,
                MinSize =operation.SizeMin ,
                SizeMultiple = operation.SizeMultiple,
                MaxSize  = operation.DurationPer,
                Resources = operation.OperationResources==null?0:operation.OperationResources.Count(),
                operationResourcePMs = OperationResourceMapper.ToPresentationModels(operation.OperationResources).ToList()
            //Routes = operation.RouteOperations == null ? 0 : operation.RouteOperations.Count(), 

        };
        }

        /// <summary>
        /// Transforms list of operation PMs list of operation BOs.
        /// </summary>
        /// <param name="operationPMs">List of operation PMs.</param>
        /// <returns>List of operation BOs.</returns>
        public static IList<Operation> FromPresentationModels(IEnumerable<OperationPM> operationPMs)
        {
            if (operationPMs == null) return null;
            return operationPMs.Select(u => FromPresentationModel(u)).ToList();
        }

        /// <summary>
        /// Transforms operation PM to operation BO.
        /// </summary>
        /// <param name="operationPM">operation PM.</param>
        /// <returns>operation BO.</returns>
        public static Operation FromPresentationModel(OperationPM operationPM)
        {
            if (operationPM == null) return null;

            return new Operation
            {

                Id = operationPM.Id,
                OperationName = operationPM.Name,
                CreatedOn = operationPM.CreatedDate,
                ModifiedBy = operationPM.PictureId != null ? operationPM.PictureId.ToString() : null,
                LocationId = operationPM.LocationId,
                Type = operationPM.Type,
                Categroy = operationPM.Category,
                IsActive = operationPM.Active,
                Description = operationPM.Description,
                Version = operationPM.Version,
                Instruction = operationPM.Instruction,
                CreatedBy = operationPM.Remarks ,
                SizeMin=operationPM.MinSize,
                SizeMultiple=operationPM.SizeMultiple,
                DurationPer=operationPM.MaxSize ,

                OperationResources = OperationResourceMapper.FromPresentationModels(operationPM.operationResourcePMs),

            };
        }


    }
}
