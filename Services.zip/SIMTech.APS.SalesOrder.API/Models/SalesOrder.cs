﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.SalesOrder.API.Models
{
    using SIMTech.APS.Models;
    public partial class SalesOrder :BaseEntity
    {
        public SalesOrder()
        {
            SalesOrderDetails = new HashSet<SalesOrderDetail>();
        }

        public string SalesOrderNumber { get; set; }
        public byte OrderType { get; set; }
        public string PurchaseOrderNumber { get; set; }
        public DateTime OrderDate { get; set; }
        public DateTime DueDate { get; set; }
        public DateTime? ShipDate { get; set; }
        public byte Status { get; set; }
        public int? CustomerId { get; set; }
        public string SalesPersonName { get; set; }
        public string ContactPersonName { get; set; }
        public string ContactNo { get; set; }
        public int? LocationId { get; set; }
        public int? TotalItems { get; set; }
        public decimal? TotalAmount { get; set; }
        public double? TotalQuantity { get; set; }
        public decimal? BalanceAmount { get; set; }
        public double? BalanceQuantity { get; set; }
        public string Comment { get; set; }
        public string String1 { get; set; }
        public string String2 { get; set; }
        public string String3 { get; set; }
        public string String4 { get; set; }
        public string String5 { get; set; }
        public string MaxString1 { get; set; }
        public string MaxString2 { get; set; }
        public double? Float1 { get; set; }
        public double? Float2 { get; set; }

        public virtual ICollection<SalesOrderDetail> SalesOrderDetails { get; set; }
    }
}
