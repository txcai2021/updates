﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.SalesOrder.API.Models
{
    using SIMTech.APS.Models;
    public partial class SalesOrderAdjustment :BaseEntity
    {
        public int SalesOrderDetailId { get; set; }
        public double? OrigianlQty { get; set; }
        public double? PlannedQty { get; set; }
        public double? ReducedQty { get; set; }
        public double? BalanceQty { get; set; }
        public string Remark { get; set; }
        public int? Status { get; set; }
        
        public virtual SalesOrderDetail SalesOrderDetail { get; set; }
    }
}
