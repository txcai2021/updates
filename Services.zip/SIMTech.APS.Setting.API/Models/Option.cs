﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.Setting.API.Models
{

    using SIMTech.APS.Models;
    public partial class Option :BaseEntity
    {
        public Option()
        {
            UserPreferences = new HashSet<UserPreference>();
        }

        public string OptionName { get; set; }
        public string Description { get; set; }
        public string ModuleName { get; set; }
        public string Category { get; set; }
        public string DataType { get; set; }
        public string DefaultSetting { get; set; }
         
        public virtual ICollection<UserPreference> UserPreferences { get; set; }
    }
}
