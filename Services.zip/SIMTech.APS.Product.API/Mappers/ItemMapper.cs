﻿using System.Collections.Generic;
using System.Linq;


namespace SIMTech.APS.Product.Web.Mappers
{
    using SIMTech.APS.Product.API.Models;
    using SIMTech.APS.Product.API.PresentationModels;
    public class ItemMapper
    {
        public static IEnumerable<ItemPM> ToPresentationModels(IEnumerable<Item> items)
        {
            if (items == null) return null;
            return items.Select(ToPresentationModel);
        }

        public static ItemPM ToPresentationModel(Item item)
        {
            if (item == null) return null;

            ItemPM itemPM = new ItemPM
            {                
                Category = string.IsNullOrEmpty(item.Category) ? string.Empty : item.Category,
                CurrentRecycleCount = item.Int1,
                CurrentRefurbishmentCount = item.Int2,
                CurrentRfHour = item.Int3,
                CurrentWaferCount = item.Int4,
                LotSize = item.Int7??0,
                Description = string.IsNullOrEmpty(item.Description) ? string.Empty : item.Description,
                ExternalSerial = string.IsNullOrEmpty(item.String2) ? string.Empty : item.String2,
                InternalSerial = string.IsNullOrEmpty(item.String3) ? string.Empty : item.String3,
                Id = item.Id,
                Name = string.IsNullOrEmpty(item.ItemName) ? string.Empty : item.ItemName,
                ParentItemId= item.ParentItemId ?? 0,
                ParentItemName = item.ParentItem != null ? item.ParentItem.ItemName : string.Empty,
                CustomerId = item.Int10 ?? 0,              
                SubCategory = item.Subcategory,
                Type = item.Type,
                PictureId = item.PictureId.HasValue ? item.PictureId.Value : 0,

                //RouteId = item.Int5,
                ProductType = item.Category == "ProductHierarchyLevelR" ? "Assembly" : "Part",
                PartFamily = item.Group1,
                Revision = item.String9,
                //RouteName = item.Group5,
                //FamilyRouteName = item.Group6,
            };

            return itemPM;
        }

        public static IEnumerable<ItemPM> ToPartTypes(IEnumerable<Item> items)
        {
            return items == null ? null : items.Select(ToPartType);
        }

        public static ItemPM ToPartType(Item item)
        {
            if (item == null) return null;

            return new ItemPM
            {                                        
                Id = item.Id,
                Name = item.ItemName,
                Description = item.Description,
                Category = item.Category,
                //RouteId = item.Int5,
                PartFamily = item.Group1,
                UnitPrice = item.UnitPrice,
                CustomerKitCode = item.String1,
                ParentItemId = item.ParentItemId,
                PartGrpType = item.Flag2,              
                BuyFlag = string.IsNullOrEmpty(item.Group2) ? false : (item.Group2 == "B" ? true : false),
                NoActionFlag = string.IsNullOrEmpty(item.Group2) ? false : (item.Group2 == "N" ? true : false),
                LotSize = item.Int7 ?? 0,
                FGDimension = item.String4,
                Revision = item.String9,
                ProductionYield = (decimal?)item.Float1,
                Uom = item.String8,
                ProductType = item.Category == "ProductHierarchyLevelR" ? "Assembly" : "Part",
            };
        }
    }
}
