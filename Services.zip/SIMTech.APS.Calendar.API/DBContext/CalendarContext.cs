﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace SIMTech.APS.Calendar.API.DBContext
{
    using SIMTech.APS.Calendar.API.Models;
    public  class CalendarContext : DbContext
    {
        public CalendarContext()
        {
        }

        public CalendarContext(DbContextOptions<CalendarContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Calendar> Calendars { get; set; }
        public virtual DbSet<CalendarDetail> CalendarDetails { get; set; }

        
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<Calendar>(entity =>
            {
                entity.ToTable("Calendar");

                entity.Property(e => e.CalendarName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Category).HasMaxLength(50);

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DefaultValue).HasMaxLength(50);

                entity.Property(e => e.Description).HasMaxLength(250);

                entity.Property(e => e.EndDate).HasColumnType("date");

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn)
                    .HasColumnType("datetime");


                entity.Property(e => e.StartDate).HasColumnType("date");

 
            });

            modelBuilder.Entity<CalendarDetail>(entity =>
            {
                entity.ToTable("CalendarDetail");

                entity.Property(e => e.CalendarDetailName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn)
                    .HasColumnType("datetime");


                entity.Property(e => e.Value).HasMaxLength(50);



                entity.HasOne(d => d.Calendar)
                    .WithMany(p => p.CalendarDetailCalendars)
                    .HasForeignKey(d => d.CalendarId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__CalendarDetail_Calendar");

                entity.HasOne(d => d.ParentCalendar)
                    .WithMany(p => p.CalendarDetailParentCalendars)
                    .HasForeignKey(d => d.ParentCalendarId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CalendarDetail_Calendar");
            });

             
        }

    }
}
