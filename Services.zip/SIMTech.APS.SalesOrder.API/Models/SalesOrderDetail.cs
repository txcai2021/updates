﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.SalesOrder.API.Models
{
    using SIMTech.APS.Models;
    public partial class SalesOrderDetail :BaseEntity
    {
        public SalesOrderDetail()
        {
            SalesOrderAdjustments = new HashSet<SalesOrderAdjustment>();
        }

        public int SalesOrderId { get; set; }
        public double? OrderQty { get; set; }
        public int? ProductId { get; set; }
        public int LineNumber { get; set; }
        public decimal? UnitPrice { get; set; }
        public decimal? Amount { get; set; }
        public DateTime? DueDate { get; set; }
        public byte Status { get; set; }
        public string Description { get; set; }
        public string Remark { get; set; }
        public string String1 { get; set; }
        public string String2 { get; set; }
        public string String3 { get; set; }
        public string String4 { get; set; }
        public string String5 { get; set; }
        public string String6 { get; set; }
        public string String7 { get; set; }
        public string String8 { get; set; }
        public string MaxString1 { get; set; }
        public string MaxString2 { get; set; }
        public int? Int1 { get; set; }
        public int? Int2 { get; set; }
        public double? Float1 { get; set; }
        public double? Float2 { get; set; }
        public DateTime? Date1 { get; set; }
        public DateTime? Date2 { get; set; }
         
        public virtual SalesOrder SalesOrder { get; set; }
        public virtual ICollection<SalesOrderAdjustment> SalesOrderAdjustments { get; set; }
    }
}
