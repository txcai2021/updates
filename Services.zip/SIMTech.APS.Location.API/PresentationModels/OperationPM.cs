﻿using System.ComponentModel.DataAnnotations;
using SIMTech.APS.Resources;

namespace SIMTech.APS.Location.API.PresentationModels
{
    public class OperationPM
    {
        [Key]
        public int Id { get; set; }


        public int TypeId { get; set; }
        public string Name { get; set; }

        public string Category { get; set; }

        public string Description { get; set; }

        public int? CalenderID { get; set; }
    }
}
