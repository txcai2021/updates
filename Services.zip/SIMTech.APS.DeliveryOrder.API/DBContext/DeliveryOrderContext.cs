﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace SIMTech.APS.DeliveryOrder.API.DBContext
{
    using SIMTech.APS.DeliveryOrder.API.Models;
    public  class DeliveryOrderContext : DbContext
    {
        public DeliveryOrderContext()
        {
        }

        public DeliveryOrderContext(DbContextOptions<DeliveryOrderContext> options)
            : base(options)
        {
        }

        public virtual DbSet<DeliveryOrder> DeliveryOrders { get; set; }
        public virtual DbSet<DeliveryOrderDetail> DeliveryOrderDetails { get; set; }      

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<DeliveryOrder>(entity =>
            {
                entity.Property(e => e.CreatedOn).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Currency)
                    .IsUnicode(false)
                    .IsFixedLength(true);
            });

            modelBuilder.Entity<DeliveryOrderDetail>(entity =>
            {
                entity.Property(e => e.CreatedOn).HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.DeliveryOrder)
                    .WithMany(p => p.DeliveryOrderDetails)
                    .HasForeignKey(d => d.DeliveryOrderId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DeliveryOrderDetail_DeliveryOrder");
            });

        }

    }
}
