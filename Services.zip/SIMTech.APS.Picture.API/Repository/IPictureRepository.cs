﻿using System.Collections.Generic;

namespace SIMTech.APS.Picture.API.Repository
{
    using SIMTech.APS.Picture.API.Models;
    using SIMTech.APS.Repository;
    public interface IPictureRepository : IRepository<Picture>
    {     
                   
    }
}
