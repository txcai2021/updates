﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;

using SIMTech.APS.Resources;

namespace SIMTech.APS.Calendar.API.PresentationModels
{

    public class CalendarDetailPM
    {
        public CalendarDetailPM()
        {
        }

        [Key]
        [Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
        public int Id { get; set; }

        //[Display(ShortName = "CalendarDetailName", ResourceType = typeof(SharedResources), Name = "CalendarDetailName")]
        [Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
        [StringLength(100)]
        public string Name { get; set; }

        [Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
        public int ParentCalendarId { get; set; }

        [Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
        public int CalendarId { get; set; }

       // [Display(ShortName = "CalendarSequence", ResourceType = typeof(SharedResources), Name = "CalendarSequence")]
        [Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
        public int Sequence { get; set; }

       // [Display(ShortName = "CalendarPriority", ResourceType = typeof(SharedResources), Name = "CalendarPriority")]
        //[Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
        public int? Priority { get; set; }

       // [Display(ShortName = "CalendarInterval", ResourceType = typeof(SharedResources), Name = "CalendarInterval")]
        //[Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
        public int Interval { get; set; }

        //[Display(ShortName = "Value", ResourceType = typeof(SharedResources), Name = "Value")]
        public string Value { get; set; }

        [Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
       // [Display(ShortName = "CreatedDate", ResourceType = typeof(SharedResources), Name = "CreatedDate")]
        public DateTime CreatedDate { get; set; }

        public DateTime ModifiedDate { get; set; }

        //[Include]
        //[Association("FK_CalendarDetail_Calendar", "ParentCalendarId", "Id", IsForeignKey = true)]
        //[Display(ShortName = "Calendar", ResourceType = typeof(SharedResources), Name = "Calendar")]
        public CalendarPM ParentCalendar { get; set; }

        //[Association("FK__CalendarDetail_Calendar", "CalendarId", "Id", IsForeignKey = true)]
        //[Display(ShortName = "Calendar", ResourceType = typeof(SharedResources), Name = "Calendar")]
        public CalendarPM Calendar { get; set; }

        //[Include]
        //[Composition]
        //[Association("FK_Resource_ResourceOperations", "Id", "ResourceId")]
        //public List<ResourceOperationPM> resourceOperationPMs { get; set; }
        //public string OperationNames { get; set; }

        //[Include]
        //[Association("FK_ParentResource", "ParentResourceId", "Id", IsForeignKey = true)]
        //[Display(ShortName = "ParentResource", ResourceType = typeof(SharedResources), Name = "ParentResource")]
        //public ResourcePM ParentResource { get; set; }


       

    }
}
