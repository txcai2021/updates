﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.Permission.API.Models
{
    using SIMTech.APS.Models;
    public partial class Task:BaseEntity
    {
        public Task()
        {
            MenuParentTasks = new HashSet<Menu>();
            MenuTasks = new HashSet<Menu>();
            RoleTasks = new HashSet<RoleTask>();
        }

        public string TaskName { get; set; }
        public string Type { get; set; }
        public string ModuleName { get; set; }
        public string Group { get; set; }
        public string DisplayText { get; set; }
        public string ActionName { get; set; }
        public string Description { get; set; }
        public int? ButtonId { get; set; }
        public string Setting { get; set; }
        public string Selection { get; set; }
        public string OrderBy { get; set; }
        public int? MaxExecutionTime { get; set; }

        public virtual Button Button { get; set; }
        public virtual ICollection<Menu> MenuParentTasks { get; set; }
        public virtual ICollection<Menu> MenuTasks { get; set; }
        public virtual ICollection<RoleTask> RoleTasks { get; set; }
    }
}
