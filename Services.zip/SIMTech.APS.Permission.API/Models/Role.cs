﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.Permission.API.Models
{
    using SIMTech.APS.Models;
    public partial class Role : BaseEntity
    {
        public Role()
        {
            RoleTasks = new HashSet<RoleTask>();
            UserRoles = new HashSet<UserRole>();
        }

        public string RoleName { get; set; }
        public string Description { get; set; }
        public int? StartTaskId { get; set; }
        public bool GlobalAccess { get; set; }

        public virtual ICollection<RoleTask> RoleTasks { get; set; }
        public virtual ICollection<UserRole> UserRoles { get; set; }
    }
}
