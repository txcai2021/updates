﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace SIMTech.APS.Location.API.DBContext
{

    using SIMTech.APS.Location.API.Models;
    public class LocationContext : DbContext
    {
        public LocationContext()
        {
        }

        public LocationContext(DbContextOptions<LocationContext> options)
            : base(options)
        {
        }

        public virtual DbSet<ItemLocation> ItemLocations { get; set; }
        public virtual DbSet<Location> Locations { get; set; }
        public virtual DbSet<UserProductLine> UserProductLines { get; set; }

       

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<ItemLocation>(entity =>
            {
                entity.ToTable("ItemLocation");

                entity.HasIndex(e => new { e.ProductLineId, e.ItemId }, "IX_ItemLocation_ProductLineId")
                    .IsUnique();

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn).HasColumnType("datetime");
                   


                entity.HasOne(d => d.ProductLine)
                    .WithMany(p => p.ItemLocations)
                    .HasForeignKey(d => d.ProductLineId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__ItemLocat__Produ__1F98B2C1");
            });

            modelBuilder.Entity<Location>(entity =>
            {
                entity.ToTable("Location");

                entity.HasIndex(e => new { e.Category, e.LocationName }, "IX_Location_LocationName")
                    .IsUnique();

                entity.Property(e => e.Category)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Description).HasMaxLength(250);

                entity.Property(e => e.LocationName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn).HasColumnType("datetime");
                  

                entity.Property(e => e.Subcategory).HasMaxLength(50);

                
                entity.HasOne(d => d.ParentLocation)
                    .WithMany(p => p.InverseParentLocation)
                    .HasForeignKey(d => d.ParentLocationId)
                    .HasConstraintName("FK__Location__Parent__2739D489");
            });

            modelBuilder.Entity<UserProductLine>(entity =>
            {
                entity.ToTable("UserProductLine");

                entity.HasIndex(e => new { e.UserId, e.ProductLineId }, "IX_UserProductLine_UserProductLineId")
                    .IsUnique();

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn).HasColumnType("datetime");
                   

                entity.Property(e => e.ProductLineId).HasColumnName("ProductLineID");

                entity.Property(e => e.UserId).HasColumnName("UserID");

               

                entity.HasOne(d => d.ProductLine)
                    .WithMany(p => p.UserProductLines)
                    .HasForeignKey(d => d.ProductLineId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__UserProdu__Produ__245D67DE");
            });

        }

    }
}
