﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SIMTech.APS.Operation.API.Mappers
{
    using SIMTech.APS.Operation.API.Models;
    using SIMTech.APS.Operation.API.PresentationModels;

    /// <summary>
    /// Maps  PMs (Presentation Models) to  BOs (Business Objects) and vice versa.
    /// </summary>
    public static class OperationParameterMapper
    {

        /// <summary>
        /// Transforms list of operationparameter BOs list of operationparameter PMs.
        /// </summary>
        /// <param name="resourceparameters">List of operationparameter BOs.</param>
        /// <returns>List of operationparameter PMs.</returns>
        public static IList<OperationParameterPM> ToPresentationModels(IEnumerable<OperationParameter> resourceparameters)
        {
            if (resourceparameters == null) return null;
            return resourceparameters.Select(u => ToPresentationModel(u)).ToList();
        }

        /// <summary>
        /// Transforms operationparameter BO to operationparameter PM.
        /// </summary>
        /// <param name="operationparameter">operationparameter BO.</param>
        /// <returns>operationparameter PM.</returns>
        public static OperationParameterPM ToPresentationModel(OperationParameter operationparameter)
        {
            if (operationparameter == null) return null;

            return new OperationParameterPM
            {
                Id = operationparameter.Id,

                OperationId = operationparameter.OperationId,
                ParameterId = operationparameter.ParamterId,

                ParameterDefaultValue = operationparameter.Value,
                ParameterMinValue = operationparameter.MinValue,
                ParameterMaxValue = operationparameter.MaxValue,

                NoofReading = operationparameter.NoofReading,
                Int1 = operationparameter.Int1,
                Int2 = operationparameter.Int2,
                Int3 = operationparameter.Int3,
                Int4 = operationparameter.Int4,
                
                CreatedDate = operationparameter.CreatedOn,
                ModifiedDate = operationparameter.ModifiedOn.Value

                //OperationOperations = ToPresentationModels(operationparameter.OperationOperations),
            };
        }


        /// <summary>
        /// Transforms list of operationparameter PMs list of operationparameter BOs.
        /// </summary>
        /// <param name="resourceoperationPMs">List of operationparameter PMs.</param>
        /// <returns>List of operationparameter BOs.</returns>
        public static IList<OperationParameter> FromPresentationModels(IEnumerable<OperationParameterPM> resourceOperationPMs)
        {
            if (resourceOperationPMs == null) return null;
            return resourceOperationPMs.Select(u => FromPresentationModel(u)).ToList();
        }

        /// <summary>
        /// Transforms operationparameter PM to operationparameter BO.
        /// </summary>
        /// <param name="resourceoperationPM">operationparameter PM.</param>
        /// <returns>operationparameter BO.</returns>
        public static OperationParameter FromPresentationModel(OperationParameterPM operationParameterPM)
        {
            if (operationParameterPM == null) return null;

            return new OperationParameter
            {
                Id = operationParameterPM.Id,
                
                ParamterId = operationParameterPM.ParameterId,
                OperationId = operationParameterPM.OperationId,

                Value = operationParameterPM.ParameterDefaultValue,
                MinValue = operationParameterPM.ParameterMinValue,
                MaxValue = operationParameterPM.ParameterMaxValue,

                NoofReading = operationParameterPM.NoofReading,
                Int1 = operationParameterPM.Int1,
                Int2 = operationParameterPM.Int2,
                Int3 = operationParameterPM.Int3,
                Int4 = operationParameterPM.Int4,

                CreatedOn = operationParameterPM.CreatedDate,
                ModifiedOn = operationParameterPM.ModifiedDate

                //OperationParameter = FromPresentationModels(resourceoperationPM.OperationOperations)
                
            };
        }

      
    }
}
