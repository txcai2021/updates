﻿using System.Collections.Generic;

namespace SIMTech.APS.WorkOrder.API.Models
{
    using SIMTech.APS.WorkOrder.API.PresentationModels;
    public class TelerikReportWorkOrder
    {
        public WorkOrderPM WorkOrderDetails { get; set; }
        public List<RouteOperationPM> RouteOperations { get; set; } = new List<RouteOperationPM>();
    }
}
