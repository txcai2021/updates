﻿using System.Collections.Generic;
using System.Linq;


namespace SIMTech.APS.Inventory.API.Mappers
{
    using SIMTech.APS.Inventory.API.Models;
    using SIMTech.APS.Inventory.API.PresentationModels;
    public static class InventoryUsageMapper
    {
        public static IEnumerable<InventoryUsagePM> ToPresentationModels(IEnumerable<InventoryUsage> items)
        {
            if (items == null) return null;
            return items.Select(ToPresentationModel);
        }

        public static InventoryUsagePM ToPresentationModel(InventoryUsage item)
        {
            if (item == null) return null;

            InventoryUsagePM itemPM = new InventoryUsagePM();
            itemPM.Update(item); 
            return itemPM;
        }

        public static IEnumerable<InventoryUsage> FromPresentationModels(IEnumerable<InventoryUsagePM> itemPMs)
        {
            if (itemPMs == null) return null;
            return itemPMs.Select(FromPresentationModel);
        }

        public static InventoryUsage FromPresentationModel(InventoryUsagePM itemPM)
        {
            if (itemPM == null) return null;

            var item = new InventoryUsage();
            item.Update(itemPM);
            return item;
        }

        public static void Update(this InventoryUsagePM itemPM,InventoryUsage item)
        {

            itemPM.Id = item.Id;
            itemPM.Type = item.UsageType;
            itemPM.UsedByOrderId = item.UsedByOrderId;
            itemPM.Quantity  = item.Quantity??0;
            itemPM.DateOut = item.DateOut;
            itemPM.Status = item.Status;
            itemPM.Remarks = item.Remarks;
            itemPM.InventoryId=item.InventoryId;
            itemPM.PartId = item.Inventory.ProductId;
            if (!string.IsNullOrEmpty (item.Remarks) )
            {
                	try 
                    {
		                 itemPM.Cost = System.Convert.ToDecimal(item.Remarks);		 
	                } 
	                catch (System.OverflowException)
                    {		 
	                }
            }
         
 
        }

        public static void Update(this InventoryUsage item, InventoryUsagePM itemPM)
        {
            //item.InventoryUsageID=  itemPM.Id;
            item.UsageType=itemPM.Type;
            item.UsedByOrderId=itemPM.UsedByOrderId ;
            item.Quantity=itemPM.Quantity;
            item.DateOut=itemPM.DateOut;
            item.Status=itemPM.Status;
            item.Remarks=itemPM.Remarks;
            item.InventoryId = itemPM.InventoryId;     
        }  
        
    }
}
