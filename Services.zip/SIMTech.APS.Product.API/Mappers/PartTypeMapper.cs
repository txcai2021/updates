﻿using System.Collections.Generic;
using System.Linq;


namespace SIMTech.APS.Product.Web.Mappers
{
    using SIMTech.APS.Product.API.Models;
    using SIMTech.APS.Product.API.PresentationModels;
    using SIMTech.APS.PresentationModels;
    public class PartTypeMapper
    {
        public static IEnumerable<PartTypePM> ToPresentationModels(IEnumerable<Item> partTypes)
        {
            if (partTypes == null) return null;
            return partTypes.Select(ToPresentationModel);
        }

        public static IEnumerable<PartTypePM> ToPresentationModels1(IEnumerable<Item> partTypes)
        {
            if (partTypes == null) return null;
            return partTypes.Select(ToPresentationModel1);
        }
        public static PartTypePM ToPresentationModel1(Item partType)
        {
            if (partType == null) return null;

            PartTypePM partTypePM = new PartTypePM
            {

                Id = partType.Id,
                Name = string.IsNullOrEmpty(partType.ItemName) ? string.Empty : partType.ItemName,
                Description = string.IsNullOrEmpty(partType.Description) ? string.Empty : partType.Description,
                Category = string.IsNullOrEmpty(partType.Category) ? string.Empty : partType.Category,
                UnitPrice = partType.UnitPrice,
                Revision = partType.String9,
                Remarks = partType.MaxString1,
                PartFamily = partType.Group1,
            };

            
            return partTypePM;
        }

        public static IEnumerable<IdNamePM> ToPresentationModels2(IEnumerable<Item> entities)
        {
            if (entities == null) return null;
            return entities.Select(ToPresentationModel2);
        }

        public static IdNamePM ToPresentationModel2(Item entity)
        {
            if (entity == null) return null;

            return new IdNamePM
            {
                Id = entity.Id,
                Name = entity.ItemName,
                Description = entity.Description,
                String1 = string.IsNullOrEmpty(entity.String8) ? string.Empty : entity.String8, //raw material grade
                Category = string.IsNullOrEmpty(entity.String9) ? string.Empty : entity.String9,// raw material type   
                String2 = string.IsNullOrEmpty(entity.Group1) ? string.Empty : entity.Group1,
                String3 = string.IsNullOrEmpty(entity.Category) ? string.Empty : entity.Category,
            };
        }

        public static PartTypePM ToPresentationModel(Item partType)
        {
            if (partType == null) return null;

            PartTypePM partTypePM = new PartTypePM
            {
              
                Id = partType.Id,
                Name = string.IsNullOrEmpty(partType.ItemName) ? string.Empty : partType.ItemName,
                Description = string.IsNullOrEmpty(partType.Description) ? string.Empty : partType.Description,
                Category = string.IsNullOrEmpty(partType.Category) ? string.Empty : partType.Category,
                UnitPrice = partType.UnitPrice,
                NoOfItems = partType.BillOfMaterialComponents.Count,


                FGDimension = string.IsNullOrEmpty(partType.String4) ? string.Empty : partType.String4,
                Revision = partType.String9, 
                Remarks = partType.MaxString1,

                //int5--routeid
                Priority = partType.Int6,
                QtyPerLot = partType.Int7,
                MinQty = partType.Int8,
                MaxQty = partType.Int9,
                CustomerId = partType.Int10,

                //Customers = partType.String9,
                // String8 is assigned to UOM for Parts
                //Assemblies = partType.String8,
                PartFamily = partType.Group1,
                BuyFlag = string.IsNullOrEmpty(partType.Group2) ? false : (partType.Group2=="B"? true: false),
                NoActionFlag = string.IsNullOrEmpty(partType.Group2) ? false : (partType.Group2 == "N" ? true : false),
                Inactive = string.IsNullOrEmpty(partType.Group3) ? false : (partType.Group3 == "T" ? true : false),

               
                ProductionYield = (decimal?)partType.Float1 ,
                // UOM string8 for Parts,Rawmaterials assigned as Grade
                UnitofMeasure = partType.String8
            };

            if (partType.PictureId != null && partType.PictureId>0)
            {
                //partTypePM.ThumbnailImage = partType.Picture.ThumbNailImage;
                //partTypePM.ThumbnailImageFileName = partType.Picture.ThumbnailImageFileName;
            }

            return partTypePM;
        }

        public static IEnumerable<Item> FromPresentationModels(IEnumerable<PartTypePM> partTypePms)
        {
            if (partTypePms == null) return null;
            return partTypePms.Select(FromPresentationModel);
        }

        public static Item FromPresentationModel(PartTypePM partTypePM)
        {
            if (partTypePM == null) return null;

            return new Item
            {               
                Id = partTypePM.Id,
                ItemName = partTypePM.Name,
                Description = partTypePM.Description,
                Category = partTypePM.Category,
                UnitPrice = partTypePM.UnitPrice,

                String4 = partTypePM.FGDimension,
                String9 = partTypePM.Revision,

                MaxString1 = partTypePM.Remarks,

                Int6 = partTypePM.Priority,
                Int7 = partTypePM.QtyPerLot,
                Int8 = partTypePM.MinQty,
                Int9 = partTypePM.MaxQty,                           
                Int10 = partTypePM.CustomerId,

                Group1 = partTypePM.PartFamily,
                Group2 = partTypePM.BuyFlag ? "B" : partTypePM.NoActionFlag ? "N":"M",
                //Group2 = partTypePM.BuyFlag ? "B" : "M",
                Group3 = partTypePM.Inactive ? "T" : "F", 

                Float1 = (double?)partTypePM.ProductionYield ,

                String8 = partTypePM.UnitofMeasure
            };
        }

        public static void UpdatePresentationModel(PartTypePM partTypePM, Item partType)
        {
            if (partTypePM == null || partType == null) return;

            partTypePM.Id = partType.Id;
            partTypePM.Name = string.IsNullOrEmpty(partType.ItemName) ? string.Empty : partType.ItemName;
            partTypePM.Category = string.IsNullOrEmpty(partType.Category) ? string.Empty : partType.Category;
            partTypePM.Description = string.IsNullOrEmpty(partType.Description) ? string.Empty : partType.Description;
            partTypePM.UnitPrice = partType.UnitPrice;

            partTypePM.FGDimension = string.IsNullOrEmpty(partType.String4) ? string.Empty : partType.String4;
            partTypePM.Revision = partType.String9;
            partTypePM.Remarks = partType.MaxString1;


            partTypePM.Priority = partType.Int6;
            partTypePM.QtyPerLot = partType.Int7;
            partTypePM.MinQty = partType.Int8;
            partTypePM.MaxQty = partType.Int9;
            partTypePM.CustomerId = partType.Int10;

          
            partTypePM.PartFamily = partType.Group1;
            partTypePM.BuyFlag = string.IsNullOrEmpty(partType.Group2) ? false : (partType.Group2 == "B" ? true : false);
            partTypePM.NoActionFlag = string.IsNullOrEmpty(partType.Group2) ? false : (partType.Group2 == "N" ? true : false);
            partTypePM.Inactive = string.IsNullOrEmpty(partType.Group3) ? false : (partType.Group3 == "T" ? true : false);
           
            partTypePM.ProductionYield = (decimal?)partType.Float1;
            partTypePM.UnitofMeasure = partType.String8;


        }
    }
}
