﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.Operation.API.Models
{
    using SIMTech.APS.Models;
    public partial class OperationRate : BaseEntity
    {
        public int? RouteId { get; set; }
        public int? RouteOperationId { get; set; }
        public int? OperationId { get; set; }
        public int? ResourceId { get; set; }
        public int? ItemId { get; set; }
        public string Instruction { get; set; }
        public double? Cost { get; set; }
        public double? Pretime { get; set; }
        public double? Posttime { get; set; }
        public double? RunTime { get; set; }
        public int? Uom { get; set; }
        public bool? IsDefault { get; set; }
       
    }
}
