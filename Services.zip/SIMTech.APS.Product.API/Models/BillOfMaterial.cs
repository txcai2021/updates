﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.Product.API.Models
{

    using SIMTech.APS.Models;
    public partial class BillOfMaterial : BaseEntity
    {
        public int ProductAssemblyId { get; set; }
        public int ComponentId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string Uomcode { get; set; }
        public short Bomlevel { get; set; }
        public double PerAssemblyQty { get; set; }
        
        public virtual Item Component { get; set; }
        public virtual Item ProductAssembly { get; set; }
    }
}
