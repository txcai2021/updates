﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
//using SIMTech.APS.Process.Services.Web;
using SIMTech.APS.Resources;


namespace SIMTech.APS.Operation.API.PresentationModels
{

    using SIMTech.APS.PresentationModels;

    /// <summary>
    /// Operation class exposes the following data members to the client:
    /// UserName, FirstName, LastName, Mobile, Email, IsLockedOut, Comment, 
    /// LastLoginDate, LastPasswordChangedDate, LastLockoutDate, FailedPasswordAttemptCount,
    /// and CreatedDate
    /// </summary>
    public class OperationDataCollectionPM
    {      
        public OperationDataCollectionPM()
        {
            //Picture = new ParameterPicturePM();
            Measurement1 = new List<string>();
            Measurement2 = new List<string>();
            Measurement3 = new List<string>();
            Measurement4 = new List<string>();
            Measurement5 = new List<string>();
            Measurement6 = new List<string>();
            Measurement7 = new List<string>();
            Measurement8 = new List<string>();
            Measurement9 = new List<string>();
            Measurement10 = new List<string>();
        }

        [Key]
        [Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
        public int Id { get; set; }


        [Display(ShortName = "OperationId", ResourceType = typeof(SharedResources), Name = "OperationId", Order = 0)]
        public int OperationId { get; set; }
        [Display(ShortName = "DataCollectionId", ResourceType = typeof(SharedResources), Name = "DataCollectionId", Order = 1)]
        public int? DataCollectionId { get; set; }


        [Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
        [Display(ShortName = "CreatedDate", ResourceType = typeof(SharedResources), Name = "CreatedDate", Order = 2)]
        public DateTime CreatedDate { get; set; }

        public DateTime ModifiedDate { get; set; }

        
        public OperationPM operationParameterPM { get; set; }

        //[Association("FK_Resource_ParameterResources", "ResourceId", "Id", IsForeignKey = true)]
        public DataCollectionPM dataCollectionPM { get; set; }

        public string DataCollectionName { get; set; }

        public string DataCollectionDefaultValue { get; set; }

        public string DataCollectionMinValue { get; set; }

        public string DataCollectionMaxValue { get; set; }

        public short? NoofReading { get; set; }

        public int? PictureId { get; set; }

        public int? MinSign { get; set; }

        public int? MaxSign { get; set; }

        public int? Criteria { get; set; }

        public string DataCollectionExtMinValue { get; set; }

        public string DataCollectionExtMaxValue { get; set; }

        [StringLength(3, ErrorMessageResourceType = typeof(ErrorResources), ErrorMessageResourceName = "ValidationErrorBadDataCollectionUoM")]
        public string DataCollectionUoM { get; set; }

        public string DataCollectionUoMDescription { get; set; }

        //[Include]
        //[Display(ShortName = "ParameterImage", ResourceType = typeof(SharedResources), Name = "ParameterImage")]
        //[Association("FK_OperationDataCollections_Picture", "Int1", "PictureID")]
        //public ParameterPicturePM Picture { get; set; }

        public bool isThumbNailImage { get; set; }

        public bool isLargeImage { get; set; }

        public byte[] ThumbNailImage { get; set; }

        public byte[] LargeImage { get; set; }

        public string ThumbnailImageFileName { get; set; }

        public string LargeImageFileName { get; set; }

        public List<string> Measurement1 { get; set; }
        public List<string> Measurement2 { get; set; }
        public List<string> Measurement3 { get; set; }
        public List<string> Measurement4 { get; set; }
        public List<string> Measurement5 { get; set; }
        public List<string> Measurement6 { get; set; }
        public List<string> Measurement7 { get; set; }
        public List<string> Measurement8 { get; set; }
        public List<string> Measurement9 { get; set; }
        public List<string> Measurement10 { get; set; }

        public string A { get; set; }
        public string B { get; set; }
        public string C { get; set; }
        public string D { get; set; }
        public string E { get; set; }

        public string F { get; set; }
        public string G { get; set; }
        public string H { get; set; }
        public string I { get; set; }
        public string J { get; set; }

        public string K { get; set; }
        public string L { get; set; }
        public string M { get; set; }
        public string N { get; set; }
        public string O { get; set; }

        public string P { get; set; }
        public string Q { get; set; }
        public string R { get; set; }
        public string S { get; set; }
        public string T { get; set; }

        public string U { get; set; }
        public string V { get; set; }
        public string W { get; set; }
        public string X { get; set; }
        public string Y { get; set; }

        public string Z { get; set; }
        public string AA { get; set; }
        public string AB { get; set; }
        public string AC { get; set; }
        public string AD { get; set; }

        public string AE { get; set; }
        public string AF { get; set; }
        public string AG { get; set; }
        public string AH { get; set; }
        public string AI { get; set; }

        public string AJ { get; set; }
        public string AK { get; set; }
        public string AL { get; set; }
        public string AM { get; set; }
        public string AN { get; set; }

        #region Auxiliary routines
        
        /// <summary>
        /// Validates the given property.
        /// </summary>
        /// <param name="propertyName">Property to validate.</param>
        /// <returns>Validation result.</returns>
        private bool Validate(string propertyName, object value)
        {
            bool flag = false;

            var context = new ValidationContext(this, null, null) { MemberName = propertyName };
            var validationResults = new Collection<System.ComponentModel.DataAnnotations.ValidationResult>();
            if (propertyName == "Password")
                {
                //flag = System.ComponentModel.DataAnnotations.Validator.TryValidateProperty(Password, context, validationResults);
                if (!flag)
                    ShowValidationResults(validationResults);
                }
            else
                flag = true;

            return flag;
        }

        static void ShowValidationResults(Collection<System.ComponentModel.DataAnnotations.ValidationResult> results)
        {
            // Check if the ValidationResults detected any validation errors.
            if (results.Count()==0)
            {
                Console.WriteLine("There were no validation errors.");
            }
            else
            {
                Console.WriteLine("The following {0} validation errors were detected:", results.Count);
                // Iterate through the collection of validation results.
                foreach (ValidationResult item in results)
                {
                    // Show the target member name and current value.
                    //Console.WriteLine("+ Target object: {0}, Member: {1}", GetTypeNameOnly(item.Target), item.Key);
                    // Display details of this validation error.
                    Console.WriteLine("{0}- Message: '{1}'", "  ", item.ErrorMessage);
                }
            }
            Console.WriteLine();
        }

        #endregion Auxiliary routines

    }
}
