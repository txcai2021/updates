﻿namespace SIMTech.APS.Permission.API.PresentationModels
{
    public class ToolbarActionPM : TaskPM
    {

    }
}
