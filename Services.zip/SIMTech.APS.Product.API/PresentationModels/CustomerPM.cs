﻿using System.ComponentModel.DataAnnotations;
using SIMTech.APS.Resources;

namespace SIMTech.APS.Product.API.PresentationModels
{
    public class CustomerPM
    {
        [Key]
        [Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
        [Display(ShortName = "CustomerId", ResourceType = typeof(SharedResources), Name = "CustomerId", Order = 0)]
        public int Id { get; set; }

        [StringLength(32, ErrorMessageResourceName = "ValidationErrorBadCustomerCode", ErrorMessageResourceType = typeof(ErrorResources))]
        [Display(ShortName = "CustomerCode", ResourceType = typeof(SharedResources), Name = "CustomerCode", Order = 1)]
        public string Code { get; set; }

        [StringLength(32, ErrorMessageResourceName = "ValidationErrorBadCustomerName", ErrorMessageResourceType = typeof(ErrorResources))]
        [Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
        [RegularExpression("^[a-zA-Z0-9_ ]*$", ErrorMessageResourceName = "ValidationErrorInvalidName", ErrorMessageResourceType = typeof(ErrorResources))]
        [Display(ShortName = "CustomerName", ResourceType = typeof(SharedResources), Name = "CustomerName", Order = 2)]
        public string Name { get; set; }

        [StringLength(32, ErrorMessageResourceName = "ValidationErrorBadCustomerSite", ErrorMessageResourceType = typeof(ErrorResources))]
        [Display(ShortName = "CustomerSite", ResourceType = typeof(SharedResources), Name = "CustomerSite", Order = 3)]
        public string Site { get; set; }

        [StringLength(32, ErrorMessageResourceName = "ValidationErrorBadCustomerDepartment", ErrorMessageResourceType = typeof(ErrorResources))]
        [Display(ShortName = "CustomerDepartment", ResourceType = typeof(SharedResources), Name = "CustomerDepartment", Order = 4)]
        public string Department { get; set; }

        [StringLength(32, ErrorMessageResourceName = "ValidationErrorBadCustomerGroupName", ErrorMessageResourceType = typeof(ErrorResources))]
        [RegularExpression("^[a-zA-Z0-9_ ]*$", ErrorMessageResourceName = "ValidationErrorInvalidCustomerGroupName", ErrorMessageResourceType = typeof(ErrorResources))]
        [Display(ShortName = "CustomerGroup", ResourceType = typeof(SharedResources), Name = "CustomerGroup", Order = 5)]
        public string Group { get; set; }

        [Display(ShortName = "CustomerPriority", ResourceType = typeof(SharedResources), Name = "CustomerPriority", Order = 6)]
        public int? Priority { get; set; }

        [RegularExpression("^[a-zA-Z0-9_ #/]*$", ErrorMessageResourceName = "ValidatonErrorInvalidAddress", ErrorMessageResourceType = typeof(ErrorResources))]
        [Display(ShortName = "Address", ResourceType = typeof(SharedResources), Name = "Address", Order = 7)]
        public string Address { get; set; }

        [Display(ShortName = "Description", ResourceType = typeof(SharedResources), Name = "Description", Order = 8)]
        public string Description { get; set; }
    }
}
