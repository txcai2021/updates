﻿using System;
using System.ComponentModel.DataAnnotations;
using SIMTech.APS.Resources;

namespace SIMTech.APS.Product.API.PresentationModels
{
    public class UserPM
    {
        [Key]
        [Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
        public int UserId { get; set; }

        [Display(ShortName = "UserName", ResourceType = typeof(SharedResources), Name = "UserName", Order = 0)]
        [Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
        [StringLength(32)]
        [RegularExpression("^[a-zA-Z0-9_]*$", ErrorMessageResourceName = "ValidationErrorInvalidName", ErrorMessageResourceType = typeof(ErrorResources))]
        public string Name { get; set; }

        [Display(ShortName = "FirstName", ResourceType = typeof(SharedResources), Name = "FirstName", Order = 1)]
        public string FirstName { get; set; }

        [Display(ShortName = "LastName", ResourceType = typeof(SharedResources), Name = "LastName", Order = 2)]
        public string LastName { get; set; }

        [Display(ShortName = "Email", ResourceType = typeof(SharedResources), Name = "Email", Order = 3)]
        public string Email { get; set; }

        [Display(ShortName = "Mobile", ResourceType = typeof(SharedResources), Name = "Mobile", Order = 4)]
        public string Mobile { get; set; }
        
        [Display(ShortName = "IsLockedOut", ResourceType = typeof(SharedResources), Name = "IsLockedOut", Order = 5)]
        public bool? IsLockedOut { get; set; }

        [Required(ErrorMessageResourceName = "ValidationErrorRequiredField", ErrorMessageResourceType = typeof(ErrorResources))]
        [Display(ShortName = "CreatedDate", ResourceType = typeof(SharedResources), Name = "CreatedDate", Order = 6)]
        public DateTime CreatedDate { get; set; }

        [Display(ShortName = "LastLockoutDate", ResourceType = typeof(SharedResources), Name = "LastLockoutDate", Order = 7)]
        public DateTime? LastLockoutDate { get; set; }
        
        [Display(ShortName = "LastLoginDate", ResourceType = typeof(SharedResources), Name = "LastLoginDate", Order = 8)]
        public DateTime? LastLoginDate { get; set; }

        [Display(ShortName = "LastPasswordChangedDate", ResourceType = typeof(SharedResources), Name = "LastPasswordChangedDate", Order = 9)]
        public DateTime? LastPasswordChangedDate { get; set; }

        [Display(ShortName = "FailedPasswordAttemptCount", ResourceType = typeof(SharedResources), Name = "FailedPasswordAttemptCount", Order = 10)]
        public int? FailedPasswordAttemptCount { get; set; }

        [Display(ShortName = "Comment", ResourceType = typeof(SharedResources), Name = "Comment", Order = 11)]
        public string Comment { get; set; }
    }
}
