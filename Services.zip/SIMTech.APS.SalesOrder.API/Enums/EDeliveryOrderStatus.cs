﻿namespace SIMTech.APS.SalesOrder.API.Enums
{ 
    public enum EDeliveryOrderStatus : byte
    {
        ProductCode = 0,
        CustomerProductCode = 1,
       
    }
}
