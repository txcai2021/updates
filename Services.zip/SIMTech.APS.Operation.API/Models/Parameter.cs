﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SIMTech.APS.Operation.API.Models
{
    using SIMTech.APS.Models;
    public partial class Parameter:BaseEntity
    {
        public Parameter()
        {
            OperationParameters = new HashSet<OperationParameter>();
        }

        public string ParameterName { get; set; }
        public byte Type { get; set; }
        public string DataType { get; set; }
        public string DefaultValue { get; set; }
        public string MinValue { get; set; }
        public string MaxValue { get; set; }
        public string Uom { get; set; }

        public virtual ICollection<OperationParameter> OperationParameters { get; set; }
    }
}
