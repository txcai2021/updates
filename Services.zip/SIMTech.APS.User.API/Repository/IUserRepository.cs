﻿using System.Collections.Generic;

namespace SIMTech.APS.User.API.Repository
{
    using SIMTech.APS.User.API.Models;
    using SIMTech.APS.Repository;
    public interface IUserRepository : IRepository<User>
    {     
        User GetUserByName(string UserName);       
        int CountConcurrentUser(string userName);             
    }
}
