﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SIMTech.APS.Product.Services.Web;
using SIMTech.APS.Product.Business;
using SIMTech.APS.Resources;


namespace SIMTech.APS.Product.Services.Web
{
   public class UnitofMeasureMapper
    {

        public static UnitofMeasurePM ToPresentationModel(UnitofMeasure parm)
        {
            if (parm == null) return null;
            try
            {
                var productLineA = new UnitofMeasurePM
                {
                   
                    CreatedBy = parm.CreatedBy,
                    CreatedOn = parm.CreatedOn,
                    ModifiedBy = parm.ModifiedBy,
                    ModifiedOn = parm.ModifiedOn,
                     Desciption=parm.Desciption,
                      UOMCode=parm.UOMCode,
                       UOMId=parm.UOMId
                 
                };

                return productLineA;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static UnitofMeasure FromPresentationModel(UnitofMeasurePM parm)
        {
            if (parm == null) return null;

            try
            {
                return new UnitofMeasure
                {

                    CreatedBy = parm.CreatedBy,
                    CreatedOn = parm.CreatedOn,
                    ModifiedBy = parm.ModifiedBy,
                    ModifiedOn = parm.ModifiedOn,
                    Desciption = parm.Desciption,
                    UOMCode = parm.UOMCode,
                    UOMId = parm.UOMId
               

                };
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static IList<UnitofMeasurePM> ToPresentationModels(IEnumerable<UnitofMeasure> parms)
        {
            if (parms == null) return null;
            return parms.Select(u => ToPresentationModel(u)).ToList();
        }

        public static IList<UnitofMeasure> FromPresentationModels(IEnumerable<UnitofMeasurePM> parms)
        {
            if (parms == null) return null;
            return parms.Select(u => FromPresentationModel(u)).ToList();
        }
    }
}
